from cryspy_editor.cl_main_window import main_w
main_w([])