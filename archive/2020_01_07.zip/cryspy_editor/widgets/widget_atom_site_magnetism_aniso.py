from PyQt5 import QtWidgets

def temp_func(qt_table, i_row, i_col, cryspy_loop):
    table_item = qt_table.item(i_row, i_col)
    val = str(table_item.text())
    if i_col == 0:
        pass
    elif i_col == 1:
        pass
    elif i_col == 2:
        cryspy_loop.chi_11[i_row].take_it(val)
    elif i_col == 3:
        cryspy_loop.chi_22[i_row].take_it(val)
    elif i_col == 4:
        cryspy_loop.chi_33[i_row].take_it(val)
    elif i_col == 5:
        cryspy_loop.chi_12[i_row].take_it(val)
    elif i_col == 6:
        cryspy_loop.chi_13[i_row].take_it(val)
    elif i_col == 7:
        cryspy_loop.chi_23[i_row].take_it(val)
    elif i_col == 8:
        pass
    elif i_col == 9:
        cryspy_loop.moment_11[i_row].take_it(val)
    elif i_col == 10:
        cryspy_loop.moment_22[i_row].take_it(val)
    elif i_col == 11:
        cryspy_loop.moment_33[i_row].take_it(val)
    elif i_col == 12:
        cryspy_loop.moment_12[i_row].take_it(val)
    elif i_col == 13:
        cryspy_loop.moment_13[i_row].take_it(val)
    elif i_col == 14:
        cryspy_loop.moment_23[i_row].take_it(val)
    else:
        pass
    return

def widget_for_atom_site_magnetism_aniso(atom_site_magnetism_aniso):
    lay_to_fill = QtWidgets.QVBoxLayout()
    n_row, n_col = len(atom_site_magnetism_aniso.label), 15
    w_t = QtWidgets.QTableWidget(n_row, n_col)
    l_name = ["label", "chi_type", "chi_11", "chi_22", "chi_33", "chi_12", "chi_13", "chi_23",
    "moment_type", "moment_11", "moment_22", "moment_33", "moment_12", "moment_13", "moment_23"]
    w_t.setHorizontalHeaderLabels(l_name)
    _i_row = 0
    for _label, _chi_type, _11, _22, _33, _12, _13, _23, _moment_type, _m_11, _m_22, _m_33, _m_12, _m_13, _m_23 in zip(atom_site_magnetism_aniso.label, atom_site_magnetism_aniso.chi_type, 
        atom_site_magnetism_aniso.chi_11, atom_site_magnetism_aniso.chi_22, atom_site_magnetism_aniso.chi_33, 
        atom_site_magnetism_aniso.chi_12, atom_site_magnetism_aniso.chi_13, atom_site_magnetism_aniso.chi_23,
        atom_site_magnetism_aniso.moment_type, 
        atom_site_magnetism_aniso.moment_11, atom_site_magnetism_aniso.moment_22, atom_site_magnetism_aniso.moment_33, 
        atom_site_magnetism_aniso.moment_12, atom_site_magnetism_aniso.moment_13, atom_site_magnetism_aniso.moment_23): 
        _w_ti_0 = QtWidgets.QTableWidgetItem()
        _w_ti_0.setText(_label)
        _w_ti_1 = QtWidgets.QTableWidgetItem()
        _w_ti_1.setText(_chi_type)
        _w_ti_2 = QtWidgets.QTableWidgetItem()
        _w_ti_2.setText(_11.print_with_sigma)
        _w_ti_3 = QtWidgets.QTableWidgetItem()
        _w_ti_3.setText(_22.print_with_sigma)
        _w_ti_4 = QtWidgets.QTableWidgetItem()
        _w_ti_4.setText(_33.print_with_sigma)
        _w_ti_5 = QtWidgets.QTableWidgetItem()
        _w_ti_5.setText(_12.print_with_sigma)
        _w_ti_6 = QtWidgets.QTableWidgetItem()
        _w_ti_6.setText(_13.print_with_sigma)
        _w_ti_7 = QtWidgets.QTableWidgetItem()
        _w_ti_7.setText(_23.print_with_sigma)
        _w_ti_8 = QtWidgets.QTableWidgetItem()
        _w_ti_8.setText(_moment_type)
        _w_ti_9 = QtWidgets.QTableWidgetItem()
        _w_ti_9.setText(_m_11.print_with_sigma)
        _w_ti_10 = QtWidgets.QTableWidgetItem()
        _w_ti_10.setText(_m_22.print_with_sigma)
        _w_ti_11 = QtWidgets.QTableWidgetItem()
        _w_ti_11.setText(_m_33.print_with_sigma)
        _w_ti_12 = QtWidgets.QTableWidgetItem()
        _w_ti_12.setText(_m_12.print_with_sigma)
        _w_ti_13 = QtWidgets.QTableWidgetItem()
        _w_ti_13.setText(_m_13.print_with_sigma)
        _w_ti_14 = QtWidgets.QTableWidgetItem()
        _w_ti_14.setText(_m_23.print_with_sigma)
        w_t.setItem(_i_row, 0, _w_ti_0)
        w_t.setItem(_i_row, 1, _w_ti_1)
        w_t.setItem(_i_row, 2, _w_ti_2)
        w_t.setItem(_i_row, 3, _w_ti_3)
        w_t.setItem(_i_row, 4, _w_ti_4)
        w_t.setItem(_i_row, 5, _w_ti_5)
        w_t.setItem(_i_row, 6, _w_ti_6)
        w_t.setItem(_i_row, 7, _w_ti_7)
        w_t.setItem(_i_row, 8, _w_ti_8)
        w_t.setItem(_i_row, 9, _w_ti_9)
        w_t.setItem(_i_row, 10, _w_ti_10)
        w_t.setItem(_i_row, 11, _w_ti_11)
        w_t.setItem(_i_row, 12, _w_ti_12)
        w_t.setItem(_i_row, 13, _w_ti_13)
        w_t.setItem(_i_row, 14, _w_ti_14)
        _i_row += 1
    w_t.cellChanged.connect(lambda _1, _2: temp_func(w_t, _1, _2, atom_site_magnetism_aniso))
    lay_to_fill.addWidget(w_t)

    #lay_to_fill.addStretch(1)
    widg_out = QtWidgets.QWidget()
    widg_out.setLayout(lay_to_fill)
    return widg_out

