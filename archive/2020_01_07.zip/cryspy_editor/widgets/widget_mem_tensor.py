import os
import os.path
from PyQt5 import QtWidgets, QtGui, QtCore

def temp_func(state, label, mem_tensor):
    if label == "clambda":
        mem_tensor.clambda = float(state)
    elif label == "n_iteration":
        mem_tensor.n_iteration = int(state)
    return


def widget_for_mem_tensor(mem_tensor):
    lay_to_fill = QtWidgets.QHBoxLayout()

    lay_right = QtWidgets.QVBoxLayout()
    size_pol_2 =  QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)
    label_out = QtWidgets.QLabel()
    label_out.setSizePolicy(size_pol_2)
    label_out.setFont(QtGui.QFont("Courier", 8, QtGui.QFont.Normal))
    label_out.setTextInteractionFlags(QtCore.Qt.TextSelectableByMouse)
    area = QtWidgets.QScrollArea()
    area.setWidgetResizable(True)
    area.setWidget(label_out)
    lay_right.addWidget(area)

    lay_left = QtWidgets.QVBoxLayout()

    _l_1 = QtWidgets.QLabel("clambda:")
    _l_e_1 = QtWidgets.QLineEdit(str(mem_tensor.clambda))
    _l_e_1.editingFinished.connect(lambda: temp_func(str(_l_e_1.text()), "clambda", mem_tensor))
    lay_left.addWidget(_l_1)
    lay_left.addWidget(_l_e_1)

    _l_2 = QtWidgets.QLabel("n_iteration:")
    _l_e_2 = QtWidgets.QLineEdit(str(mem_tensor.n_iteration))
    _l_e_2.editingFinished.connect(lambda: temp_func(str(_l_e_2.text()), "n_iteration", mem_tensor))
    lay_left.addWidget(_l_2)
    lay_left.addWidget(_l_e_2)

    lay_left.addStretch(1)

    lay_h = QtWidgets.QHBoxLayout()
    _l_e_3 = QtWidgets.QLineEdit("full")
    _l_3 = QtWidgets.QLabel("is a prefix of file to save an atom ")

    _combo = QtWidgets.QComboBox()
    for _ in mem_tensor.density.density_points:
        _combo.addItem(_.atom_label)

    _b_to_file_den = QtWidgets.QPushButton("in density file")
    _b_to_file_den.clicked.connect(lambda :  to_file_den(mem_tensor, str(_l_e_3.text()), str(_combo.currentText()), label_out))
    lay_h.addWidget(_l_e_3)
    lay_h.addWidget(_l_3)
    lay_h.addWidget(_combo)
    lay_h.addWidget(_b_to_file_den)
    lay_left.addLayout(lay_h)

    _b_calc_fr_mod = QtWidgets.QPushButton("calc fr_mod")
    _b_calc_fr_mod.clicked.connect(lambda :  calc_fr_mod(mem_tensor, label_out))
    lay_left.addWidget(_b_calc_fr_mod)

    _b_calc_total_electrons = QtWidgets.QPushButton("calc total_electrons")
    _b_calc_total_electrons.clicked.connect(lambda :  calc_total_electrons(mem_tensor, label_out))
    lay_left.addWidget(_b_calc_total_electrons)

    _b_renorm_susceptibility = QtWidgets.QPushButton("Renorm susceptibility")
    _b_renorm_susceptibility.clicked.connect(lambda :  renorm_susceptibility(mem_tensor, label_out))
    lay_left.addWidget(_b_renorm_susceptibility)



    _b_create_flat_density = QtWidgets.QPushButton("create flat density")
    _b_create_flat_density.clicked.connect(lambda :  create_flat_density(mem_tensor, label_out))
    lay_left.addWidget(_b_create_flat_density)


    _b_info = QtWidgets.QPushButton("info")
    _b_info.clicked.connect(lambda : show_info(mem_tensor, label_out))
    lay_left.addWidget(_b_info)

    
    lay_to_fill.addLayout(lay_left)
    lay_to_fill.addLayout(lay_right)
    widg_out = QtWidgets.QWidget()
    widg_out.setLayout(lay_to_fill)
    return widg_out


def show_info(mem_tensor, label):
    label.setText(str(mem_tensor))

def calc_fr_mod(mem_tensor, label):
    ls_out = []
    mem_tensor.calc_fr_mod()
    ls_out.append("Calculations done.")
    label.setText("\n".join(ls_out))
    

def calc_total_electrons(mem_tensor, label):
    ls_out = []
    ls_out.append("Total electron number for atoms in an unit cell.")
    mem_tensor.calc_total_electrons()
    for _ in mem_tensor.density.density_points:
        ls_out.append(f"{_.total_electrons:.5f} for '{_.atom_label:}'")
    label.setText("\n".join(ls_out))    

def create_flat_density(mem_tensor, label):
    ls_out = []
    mem_tensor.create_flat_density()
    ls_out.append("Density was created.")
    label.setText("\n".join(ls_out))

def renorm_susceptibility(mem_tensor, label):
    ls_out = []
    mem_tensor.renorm_susceptibility()
    ls_out.append("Susceptibility was renormed.")
    label.setText("\n".join(ls_out))


def to_file_den(mem_tensor, file_prefix, atom_label, label):
    file_name = f"{file_prefix.strip():}_{atom_label.strip():}.den"
    if mem_tensor.file_input is not None:
        _file_name = os.path.join(os.path.dirname(mem_tensor.file_input), file_name)
    else:
        _file_name = file_name
    mem_tensor.to_file_den(_file_name, atom_label=atom_label)
    ls_out = []
    ls_out.append(f"The density was saved to file '{file_name:}'.")
    label.setText("\n".join(ls_out))
