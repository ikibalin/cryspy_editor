import numpy
from PyQt5 import QtWidgets

def temp_func(state, label, widg):
    pd2d = widg.pd2d
    if label == "chi2_sum":
        pd2d.chi2_sum = state == 2
    elif label == "chi2_diff":
        pd2d.chi2_diff = state == 2
    elif label == "chi2_up":
        pd2d.chi2_up = state == 2
    elif label == "chi2_down":
        pd2d.chi2_down = state == 2
    elif label == "ttheta_min":
        pd2d.ttheta_min = float(state)
    elif label == "ttheta_max":
        pd2d.ttheta_max = float(state)
    elif label == "phi_min":
        pd2d.phi_min = float(state)
    elif label == "phi_max":
        pd2d.phi_max = float(state)
    elif label == "field":
        pd2d.field = float(state)
    return


def widget_for_pd2d(pd2d):
    
    widg_out = QtWidgets.QWidget()
    widg_out.pd2d = pd2d
    
    lay_to_fill = QtWidgets.QVBoxLayout()

    _cb = QtWidgets.QCheckBox(" chi2_sum")
    if pd2d.chi2_sum:
        _cb.setCheckState(2)
    else:
        _cb.setCheckState(0)
    _cb.stateChanged.connect(lambda _1: temp_func(_1, "chi2_sum", widg_out))
    lay_to_fill.addWidget(_cb)

    _cb = QtWidgets.QCheckBox(" chi2_diff")
    if pd2d.chi2_diff:
        _cb.setCheckState(2)
    else:
        _cb.setCheckState(0)
    _cb.stateChanged.connect(lambda _1: temp_func(_1, "chi2_diff", widg_out))
    lay_to_fill.addWidget(_cb)

    _cb = QtWidgets.QCheckBox(" chi2_up")
    if pd2d.chi2_up:
        _cb.setCheckState(2)
    else:
        _cb.setCheckState(0)
    _cb.stateChanged.connect(lambda _1: temp_func(_1, "chi2_up", widg_out))
    lay_to_fill.addWidget(_cb)

    _cb = QtWidgets.QCheckBox(" chi2_down")
    if pd2d.chi2_down:
        _cb.setCheckState(2)
    else:
        _cb.setCheckState(0)
    _cb.stateChanged.connect(lambda _1: temp_func(_1, "chi2_down", widg_out))
    lay_to_fill.addWidget(_cb)


    _l = QtWidgets.QLabel("ttheta_offset:")
    _l_e_6 = QtWidgets.QLineEdit(pd2d.ttheta_offset.print_with_sigma)
    _l_e_6.editingFinished.connect(lambda: pd2d.ttheta_offset.take_it(str(_l_e_6.text())))
    lay_to_fill.addWidget(_l)
    lay_to_fill.addWidget(_l_e_6)

    #_l = QtWidgets.QLabel("phi_offset:")
    #_l_e_7 = QtWidgets.QLineEdit(pd2d.phi_offset.print_with_sigma)
    #_l_e_7.editingFinished.connect(lambda: pd2d.phi_offset.take_it(str(_l_e_7.text())))
    #lay_to_fill.addWidget(_l)
    #lay_to_fill.addWidget(_l_e_7)

    _l = QtWidgets.QLabel("ttheta_range_min:")
    _l_e_8 = QtWidgets.QLineEdit(str(pd2d.ttheta_min))
    _l_e_8.editingFinished.connect(lambda: temp_func(str(_l_e_8.text()), "ttheta_min", widg_out))
    lay_to_fill.addWidget(_l)
    lay_to_fill.addWidget(_l_e_8)

    _l = QtWidgets.QLabel("ttheta_range_max:")
    _l_e_9 = QtWidgets.QLineEdit(str(pd2d.ttheta_max))
    _l_e_9.editingFinished.connect(lambda: temp_func(str(_l_e_9.text()), "ttheta_max", widg_out))
    lay_to_fill.addWidget(_l)
    lay_to_fill.addWidget(_l_e_9)

    _l = QtWidgets.QLabel("phi_range_min:")
    _l_e_10 = QtWidgets.QLineEdit(str(pd2d.phi_min))
    _l_e_10.editingFinished.connect(lambda: temp_func(str(_l_e_10.text()), "phi_min", widg_out))
    lay_to_fill.addWidget(_l)
    lay_to_fill.addWidget(_l_e_10)

    _l = QtWidgets.QLabel("phi_range_max:")
    _l_e_11 = QtWidgets.QLineEdit(str(pd2d.phi_max))
    _l_e_11.editingFinished.connect(lambda: temp_func(str(_l_e_11.text()), "phi_max", widg_out))
    lay_to_fill.addWidget(_l)
    lay_to_fill.addWidget(_l_e_11)

    _l = QtWidgets.QLabel("wavelength:")
    _l_e_12 = QtWidgets.QLineEdit(pd2d.wavelength.print_with_sigma)
    _l_e_12.editingFinished.connect(lambda: pd2d.wavelength.take_it(str(_l_e_12.text())))
    lay_to_fill.addWidget(_l)
    lay_to_fill.addWidget(_l_e_12)

    _l = QtWidgets.QLabel("field:")
    _l_e_13 = QtWidgets.QLineEdit(str(pd2d.field))
    _l_e_13.editingFinished.connect(lambda: temp_func(str(_l_e_13.text()), "field", widg_out))
    lay_to_fill.addWidget(_l)
    lay_to_fill.addWidget(_l_e_13)

    lay_to_fill.addStretch(1)
    widg_out.setLayout(lay_to_fill)
    return widg_out
