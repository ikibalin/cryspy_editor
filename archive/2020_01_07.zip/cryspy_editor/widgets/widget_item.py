from PyQt5 import QtWidgets, QtGui, QtCore

def func_item_value(line_edit, item):
    item.value = str(line_edit.text())
    return

def is_matrix(s_val):
    _1 = s_val.strip().split("\n")
    if len(_1) > 1:
        ll_mat = numpy.array([[_3 if _3!="None" else None for _3 in _2.strip().split()] for _2 in _1], dtype=float)
        return True, ll_mat
    else:
        return False, s_val
        
def widget_for_item(item):
    lay_to_fill = QtWidgets.QHBoxLayout()

    lay_right = QtWidgets.QVBoxLayout()
    size_pol_2 =  QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)
    label_out = QtWidgets.QLabel()
    label_out.setSizePolicy(size_pol_2)
    label_out.setFont(QtGui.QFont("Courier", 8, QtGui.QFont.Normal))
    label_out.setTextInteractionFlags(QtCore.Qt.TextSelectableByMouse)
    area = QtWidgets.QScrollArea()
    area.setWidgetResizable(True)
    area.setWidget(label_out)
    lay_right.addWidget(area)

    lay_left = QtWidgets.QVBoxLayout()

    flag, s_val = is_matrix(item.value)
    if flag:
        np_mat = s_val
        x = np_mat[0, 1:]
        y = np_mat[1:, 0]
        z = np_mat[1:, 1:]
        _z_1 = numpy.where(numpy.isnan(z), 0., z).sum(axis=0)
        _n_1 = numpy.where(numpy.isnan(z), 0., 1.).sum(axis=0)
        z_1 = _z_1/_n_1
        """
        i_s_e_1d = numpy.where(numpy.isnan(int_s_e), 0., int_s_e).sum(axis=1)
        i_s_m_1d = numpy.where(numpy.isnan(int_s_e), 0., int_s_m).sum(axis=1)
        si_s_e_1d = ((numpy.where(numpy.isnan(int_s_e), 0., sint_s)**2).sum(axis=1))**0.5
        i_d_e_1d = numpy.where(numpy.isnan(int_d_e), 0., int_d_e).sum(axis=1)
        i_d_m_1d = numpy.where(numpy.isnan(int_d_e), 0., int_d_m).sum(axis=1)
        si_d_e_1d = ((numpy.where(numpy.isnan(int_d_e), 0., sint_d)**2).sum(axis=1))**0.5    
        """
        stack_widget = QtWidgets.QStackedWidget()
        #stack_widg.setMinimumSize(width_m_3, 1)
        #sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)
        #stack_widg.setSizePolicy(sizePolicy)

        _rb_1 = QtWidgets.QRadioButton("matrix")
        _rb_1.toggled.connect(lambda: stack_widget.setCurrentIndex(0))
        _rb_2 = QtWidgets.QRadioButton("projection")
        _rb_2.toggled.connect(lambda: stack_widget.setCurrentIndex(1))
        _rb_2.setChecked(True)
        lay_left.addWidget(_rb_1)
        lay_left.addWidget(_rb_2)

        widg_matrix = interactive_matrix.cwidg_central()
        widg_matrix.plot_matrix(x, y, z)
        widg_proj = interactive_graph_mod_mono.cwidg_central()
        widg_proj.plot_file(x, z_1)

        stack_widget.addWidget(widg_matrix)
        stack_widget.addWidget(widg_proj)
        stack_widget.setCurrentIndex(1)
        lay_left.addWidget(stack_widget)
    else:
        _l = QtWidgets.QLabel(f"{item.name:}:")
        _l_e = QtWidgets.QLineEdit(item.value)
        _l_e.editingFinished.connect(lambda : func_item_value(_l_e, item))
        lay_left.addWidget(_l)
        lay_left.addWidget(_l_e)
        lay_left.addStretch(1)
        

    lay_to_fill.addLayout(lay_left)
    lay_to_fill.addLayout(lay_right)

    widg_out = QtWidgets.QWidget()
    widg_out.setLayout(lay_to_fill)
    return widg_out

