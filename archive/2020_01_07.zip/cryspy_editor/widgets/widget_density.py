from PyQt5 import QtWidgets, QtGui, QtCore

def temp_func(state, label, density):
    if label == "choice":
        density.spgr_choice = state
    elif label == "name":
        density.spgr_given_name = state
    return


def widget_for_density(density):
    lay_to_fill = QtWidgets.QHBoxLayout()

    lay_right = QtWidgets.QVBoxLayout()
    size_pol_2 =  QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)
    label_out = QtWidgets.QLabel()
    label_out.setSizePolicy(size_pol_2)
    label_out.setFont(QtGui.QFont("Courier", 8, QtGui.QFont.Normal))
    label_out.setTextInteractionFlags(QtCore.Qt.TextSelectableByMouse)
    area = QtWidgets.QScrollArea()
    area.setWidgetResizable(True)
    area.setWidget(label_out)
    lay_right.addWidget(area)

    lay_left = QtWidgets.QVBoxLayout()


    _l_x = QtWidgets.QLabel("points_x:")
    _l_e_x = QtWidgets.QLineEdit(str(density.points_x))
    #_l_e_b.editingFinished.connect(lambda: temp_func(str(_l_e_b.text()), "name", density))
    lay_left.addWidget(_l_x)
    lay_left.addWidget(_l_e_x)

    _l_y = QtWidgets.QLabel("points_y:")
    _l_e_y = QtWidgets.QLineEdit(str(density.points_y))
    #_l_e_b.editingFinished.connect(lambda: temp_func(str(_l_e_b.text()), "name", density))
    lay_left.addWidget(_l_y)
    lay_left.addWidget(_l_e_y)

    _l_z = QtWidgets.QLabel("points_z:")
    _l_e_z = QtWidgets.QLineEdit(str(density.points_z))
    #_l_e_b.editingFinished.connect(lambda: temp_func(str(_l_e_b.text()), "name", density))
    lay_left.addWidget(_l_z)
    lay_left.addWidget(_l_e_z)


    lay_left.addStretch(1)


    _b_info = QtWidgets.QPushButton("info")
    _b_info.clicked.connect(lambda : show_info(density, label_out))
    lay_left.addWidget(_b_info)

    
    lay_to_fill.addLayout(lay_left)
    lay_to_fill.addLayout(lay_right)
    widg_out = QtWidgets.QWidget()
    widg_out.setLayout(lay_to_fill)
    return widg_out


def show_info(density, label):
    label.setText(str(density))

def create_new_density(density, n_x, n_y, n_z, label):
    s_out = density.create_new_density(n_x, n_y, n_z)
    label.setText(s_out)

