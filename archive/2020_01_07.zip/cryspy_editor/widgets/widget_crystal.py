import numpy

from PyQt5 import QtWidgets, QtGui, QtCore

def temp_func(state, label, crystal):
    if label == "choice":
        crystal.spgr_choice = state
    elif label == "name":
        crystal.spgr_given_name = state
    return


def widget_for_crystal(crystal):
    lay_to_fill = QtWidgets.QHBoxLayout()

    lay_right = QtWidgets.QVBoxLayout()
    size_pol_2 =  QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)
    label_out = QtWidgets.QLabel()
    label_out.setSizePolicy(size_pol_2)
    label_out.setFont(QtGui.QFont("Courier", 8, QtGui.QFont.Normal))
    label_out.setTextInteractionFlags(QtCore.Qt.TextSelectableByMouse)
    area = QtWidgets.QScrollArea()
    area.setWidgetResizable(True)
    area.setWidget(label_out)
    lay_right.addWidget(area)



    lay_left = QtWidgets.QVBoxLayout()


    _l_b = QtWidgets.QLabel("label:")
    _l_e_b = QtWidgets.QLineEdit(crystal.label)
    _l_e_b.editingFinished.connect(lambda: temp_func(str(_l_e_b.text()), "label", crystal))
    lay_left.addWidget(_l_b)
    lay_left.addWidget(_l_e_b)

    lay_left.addStretch(1)



    _lay_atoms = QtWidgets.QHBoxLayout()
    _l = QtWidgets.QLabel("Position of atom in unit cell:")
    l_atom_label = crystal.atom_site.label
    _combo_a = QtWidgets.QComboBox()
    for _ in l_atom_label:
        _combo_a.addItem(_)
    _b_xyz = QtWidgets.QPushButton("show")
    _lay_atoms.addWidget(_l)
    _lay_atoms.addWidget(_combo_a)
    _lay_atoms.addWidget(_b_xyz)
    _b_xyz.clicked.connect(lambda : show_xyz(crystal, str(_combo_a.currentText()), label_out))
    lay_left.addLayout(_lay_atoms)


    _lay_mag_atoms = QtWidgets.QHBoxLayout()
    _l = QtWidgets.QLabel("Chi for magnetic atom")
    l_magnetism_atom_label = crystal.atom_site_magnetism_aniso.label
    _combo_m_a = QtWidgets.QComboBox()
    for _ in l_magnetism_atom_label:
        _combo_m_a.addItem(_)
    _b_chi = QtWidgets.QPushButton("show")
    _lay_mag_atoms.addWidget(_l)
    _lay_mag_atoms.addWidget(_combo_m_a)
    _lay_mag_atoms.addWidget(_b_chi)
    _b_chi.clicked.connect(lambda : show_chi(crystal, str(_combo_m_a.currentText()), label_out))
    lay_left.addLayout(_lay_mag_atoms)

    _b_ellipsoids = QtWidgets.QPushButton("Magnetic ellipsoids")
    _b_ellipsoids.clicked.connect(lambda : show_ellipsoids(crystal, label_out))
    lay_left.addWidget(_b_ellipsoids)

    _lay_moments = QtWidgets.QHBoxLayout()
    _l = QtWidgets.QLabel("Magnetic moments for field (in a, b, c)")
    _l_e_moments = QtWidgets.QLineEdit()
    _l_e_moments.setText("0. 0. 1.")
    _b_moments = QtWidgets.QPushButton("show")
    _lay_moments.addWidget(_l)
    _lay_moments.addWidget(_l_e_moments)
    _lay_moments.addWidget(_b_moments)
    _b_moments.clicked.connect(lambda : show_moments(crystal, str(_l_e_moments.text()), label_out))
    lay_left.addLayout(_lay_moments)

    _b_info = QtWidgets.QPushButton("info")
    _b_info.clicked.connect(lambda : show_info(crystal, label_out))
    lay_left.addWidget(_b_info)

    lay_to_fill.addLayout(lay_left)
    lay_to_fill.addLayout(lay_right)
    widg_out = QtWidgets.QWidget()
    widg_out.setLayout(lay_to_fill)
    return widg_out


def show_info(crystal, label):
    label.setText(str(crystal))

def show_el_symm(crystal, label):
    s_out = crystal._trans_el_symm_to_str()
    label.setText(s_out)

def show_names(crystal, label):
    ls_out = crystal.names 
    ls_out_print = []
    n_val = 10
    for _i, _  in enumerate(ls_out):
        if _i%n_val ==0:
            ls_out_print.append("\n")
        if _i%(5*n_val) ==0:
            ls_out_print.append("\n")
        _sval = _.strip().ljust(14, " ")
        ls_out_print.append(f"{_sval:14}")
    label.setText("Accessible names:" + "".join(ls_out_print)[:-2])


def show_choices(crystal, val, label):
    ls_out = crystal.choices(val)
    label.setText(f"List of accessible choices for {val:} is\n\n" + ", ".join(ls_out))

def show_xyz(crystal, val, label):
    spgr = crystal.space_group
    a_s = crystal.atom_site
    _ind = a_s.label.index(str(val))
    x, y, z = float(a_s.x[_ind]), float(a_s.y[_ind]), float(a_s.z[_ind])
    np_x, np_y, np_z, mult = spgr.calc_xyz_mult(x, y, z)
    
    ls_out = []
    ls_out.append(f"Number of '{val:}' in unit cell is {np_x.size:}")
    ls_out.append(f"Multiplicity is {mult:}")
    ls_out.append(f"            _x      _y      _z")
    _i = 0
    for _x, _y, _z in zip(np_x, np_y, np_z):
        _i += 1
        ls_out.append(f"({_i:3}) {_x:8.5f}{_y:8.5f}{_z:8.5f}")
    label.setText("\n".join(ls_out))

def show_chi(crystal, val, label):
    spgr = crystal.space_group
    a_s_m_a = crystal.atom_site_magnetism_aniso
    
    _ind = a_s_m_a.label.index(str(val))
    _11, _12, _13 = a_s_m_a.chi_11[_ind], a_s_m_a.chi_12[_ind], a_s_m_a.chi_13[_ind]
    _22, _23, _33 = a_s_m_a.chi_22[_ind], a_s_m_a.chi_23[_ind], a_s_m_a.chi_33[_ind]
    m_chi = numpy.array([[_11, _12, _13], [_12, _22, _23], [_13, _23, _33]], dtype=float)

    a_s = crystal.atom_site
    _ind = a_s.label.index(str(val))
    x_a, y_a, z_a = a_s.x[_ind], a_s.y[_ind], a_s.z[_ind]
    l_out = spgr.calc_rotated_matrix_for_position(m_chi, x_a, y_a, z_a)
    ls_out = []
    _m_chi_total = numpy.zeros((3,3), dtype=float)
    ls_out.append(f"Chi for '{val:}' (in mu_B)")
    ls_out.append(f"      _11      _22     _33      _12      _13     _23     _x    _y    _z")
    for _out in l_out:
        _x, _y, _z = _out[0][0], _out[0][1], _out[0][2]
        _m_chi = _out[1]
        _m_chi_total += _m_chi
        ls_out.append(f" {_m_chi[0, 0]:8.5f} {_m_chi[1, 1]:8.5f}{_m_chi[2, 2]:8.5f} {_m_chi[0, 1]:8.5f} {_m_chi[0, 2]:8.5f}{_m_chi[1, 2]:8.5f} {_x:6.3f}{_y:6.3f}{_z:6.3f}")
    ls_out.append(f"\nTotal chi for '{val:}' (in mu_B)")
    ls_out.append(f" {_m_chi_total[0, 0]:8.3f} {_m_chi_total[0, 1]:8.3f}{_m_chi_total[0, 2]:8.3f}")
    ls_out.append(f" {_m_chi_total[1, 0]:8.3f} {_m_chi_total[1, 1]:8.3f}{_m_chi_total[1, 2]:8.3f}")
    ls_out.append(f" {_m_chi_total[2, 0]:8.3f} {_m_chi_total[2, 1]:8.3f}{_m_chi_total[2, 2]:8.3f}")
    label.setText("\n".join(ls_out))

def show_ellipsoids(crystal, label):
    l_label = crystal.atom_site_magnetism_aniso.label
    l_mu = crystal.calc_magnetization_ellipsoid()
    ll_moment, ll_direction = crystal.calc_main_axes_of_magnetization_ellipsoids()
    ls_out = []
    for _label, _mu, l_moment, l_direction in zip(l_label, l_mu, ll_moment, ll_direction):
        ls_out.append(f"Ellipsoid for '{_label:}' (_11, _22, _33, _12, _13, _23) is")
        ls_out.append(f"{_mu[0, 0]:10.5f} {_mu[1, 1]:10.5f} {_mu[2, 2]:10.5f} {_mu[0, 1]:10.5f} {_mu[0, 2]:10.5f} {_mu[1, 2]:10.5f}")
        ls_out.append(f"\nmoment(mu_B) direction_u       _v       _w")
        ls_out.append(f"{l_moment[0]:12.2f}    {l_direction[0][0]:8.5f} {l_direction[0][1]:8.5f} {l_direction[0][2]:8.5f}")
        ls_out.append(f"{l_moment[1]:12.2f}    {l_direction[1][0]:8.5f} {l_direction[1][1]:8.5f} {l_direction[1][2]:8.5f}")
        ls_out.append(f"{l_moment[2]:12.2f}    {l_direction[2][0]:8.5f} {l_direction[2][1]:8.5f} {l_direction[2][2]:8.5f}")
        ls_out.append("")
    ls_out.append("Direction defined as u*a/a + v*b/b + w*c/c???")
    label.setText("\n".join(ls_out))

def show_moments(crystal, val, label):
    field_abc = numpy.array([float(_) for _ in val.strip().replace(",", " ").strip().split()[:3]], dtype=float)
    l_lab, l_xyz, l_moment = crystal.calc_magnetic_moments_with_field_loc(field_abc)
    ls_out = []
    ls_out.append("  label    _x   _y   _z     m_a    m_b    m_c (in mu_B)")
    for _1, _2, _3 in zip(l_lab, l_xyz, l_moment):
        ls_out.append(f"{_1:7} {_2[0]:5.2f}{_2[1]:5.2f}{_2[2]:5.2f} {_3[0]:7.2f}{_3[1]:7.2f}{_3[2]:7.2f}")
    ls_out.append("!!! ONLY FOR CUBIC STRUCTURES !!!")
    label.setText("\n".join(ls_out))
