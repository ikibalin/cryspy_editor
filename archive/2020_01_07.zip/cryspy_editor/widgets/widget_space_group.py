from PyQt5 import QtWidgets, QtGui, QtCore

def temp_func(state, label, space_group):
    if label == "choice":
        space_group.spgr_choice = state
    elif label == "name":
        space_group.spgr_given_name = state
    return


def widget_for_space_group(space_group):
    lay_to_fill = QtWidgets.QHBoxLayout()

    lay_right = QtWidgets.QVBoxLayout()
    size_pol_2 =  QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)
    label_out = QtWidgets.QLabel()
    label_out.setSizePolicy(size_pol_2)
    label_out.setFont(QtGui.QFont("Courier", 8, QtGui.QFont.Normal))
    label_out.setTextInteractionFlags(QtCore.Qt.TextSelectableByMouse)
    area = QtWidgets.QScrollArea()
    area.setWidgetResizable(True)
    area.setWidget(label_out)
    lay_right.addWidget(area)

    lay_left = QtWidgets.QVBoxLayout()


    _l_b = QtWidgets.QLabel("spgr_name or spgr_number:")
    _l_e_b = QtWidgets.QLineEdit(space_group.spgr_name)
    _l_e_b.editingFinished.connect(lambda: temp_func(str(_l_e_b.text()), "name", space_group))
    lay_left.addWidget(_l_b)
    lay_left.addWidget(_l_e_b)

    _l_a = QtWidgets.QLabel("spgr_choice:")
    _l_e_a = QtWidgets.QLineEdit(space_group.spgr_choice)
    _l_e_a.editingFinished.connect(lambda: temp_func(str(_l_e_a.text()), "choice", space_group))
    lay_left.addWidget(_l_a)
    lay_left.addWidget(_l_e_a)


    lay_left.addStretch(1)


    _b_el_s = QtWidgets.QPushButton("Elements of symmetry")
    _b_el_s.clicked.connect(lambda : show_el_symm(space_group, label_out))
    lay_left.addWidget(_b_el_s)

    _b_el_an = QtWidgets.QPushButton("Accessible names")
    _b_el_an.clicked.connect(lambda : show_names(space_group, label_out))
    lay_left.addWidget(_b_el_an)

    _b_el_ac = QtWidgets.QPushButton("Accessible choices")
    _b_el_ac.clicked.connect(lambda : show_choices(space_group, str(_l_e_b.text()), label_out))
    lay_left.addWidget(_b_el_ac)

    _b_info = QtWidgets.QPushButton("info")
    _b_info.clicked.connect(lambda : show_info(space_group, label_out))
    lay_left.addWidget(_b_info)

    _lay_atoms = QtWidgets.QHBoxLayout()
    _l = QtWidgets.QLabel("List of atoms in unit cell for x y z:")
    _l_e_atoms = QtWidgets.QLineEdit()
    _l_e_atoms.setText("0. 0. 0.")
    _b_atoms = QtWidgets.QPushButton("Generate")
    _lay_atoms.addWidget(_l)
    _lay_atoms.addWidget(_l_e_atoms)
    _lay_atoms.addWidget(_b_atoms)
    _b_atoms.clicked.connect(lambda : show_atoms(space_group, str(_l_e_atoms.text()), label_out))
    lay_left.addLayout(_lay_atoms)
    
    lay_to_fill.addLayout(lay_left)
    lay_to_fill.addLayout(lay_right)
    widg_out = QtWidgets.QWidget()
    widg_out.setLayout(lay_to_fill)
    return widg_out


def show_info(space_group, label):
    label.setText(str(space_group))

def show_el_symm(space_group, label):
    s_out = space_group._trans_el_symm_to_str()
    label.setText(s_out)

def show_names(space_group, label):
    ls_out = space_group.names 
    ls_out_print = []
    n_val = 10
    for _i, _  in enumerate(ls_out):
        if _i%n_val ==0:
            ls_out_print.append("\n")
        if _i%(5*n_val) ==0:
            ls_out_print.append("\n")
        _sval = _.strip().ljust(14, " ")
        ls_out_print.append(f"{_sval:14}")
    label.setText("Accessible names:" + "".join(ls_out_print)[:-2])


def show_choices(space_group, val, label):
    ls_out = space_group.choices(val)
    label.setText(f"List of accessible choices for {val:} is\n\n" + ", ".join(ls_out))

def show_atoms(space_group, val, label):
    sval = val.replace(",", " ").strip()
    [x,y,z]=[float(_) for _ in sval.split()[:3]]
    np_x, np_y, np_z, mult = space_group.calc_xyz_mult(x,y,z)
    ls_out = [f"For atom ({x:.5f}, {y:.5f}, {z:.5f})"]
    ls_out.append(f" number of atoms in unit cell is {np_x.size:}")
    ls_out.append(f" multiplicity is {mult:}")
    ls_out.append("List of atoms in unit cell:")
    ls_out.extend([f" {_1:8.5f} {_2:8.5f} {_3:8.5f}" for _1, _2, _3 in zip(np_x, np_y, np_z)])
    label.setText("\n".join(ls_out))
