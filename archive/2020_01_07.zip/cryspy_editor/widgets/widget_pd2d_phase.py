from PyQt5 import QtWidgets

def temp_func(qt_table, i_row, i_col, cryspy_loop):
    table_item = qt_table.item(i_row, i_col)
    val = str(table_item.text())
    if i_col == 0:
        pass
    elif i_col == 1:
        cryspy_loop.scale[i_row].take_it(val)
    elif i_col == 2:
        cryspy_loop.igsize[i_row].take_it(val)
    else:
        pass
    return

def widget_for_pd2d_phase(pd2d_phase):
    lay_to_fill = QtWidgets.QVBoxLayout()
    n_row, n_col = len(pd2d_phase.label), 3
    w_t = QtWidgets.QTableWidget(n_row, n_col)
    l_name = ["label", "scale", "igsize"]
    w_t.setHorizontalHeaderLabels(l_name)
    _i_row = 0
    for _label, _scale, _igsize in zip(pd2d_phase.label, pd2d_phase.scale, pd2d_phase.igsize): 
        _w_ti_0 = QtWidgets.QTableWidgetItem()
        _w_ti_0.setText(_label)
        _w_ti_1 = QtWidgets.QTableWidgetItem()
        _w_ti_1.setText(_scale.print_with_sigma)
        _w_ti_2 = QtWidgets.QTableWidgetItem()
        _w_ti_2.setText(_igsize.print_with_sigma)
        w_t.setItem(_i_row, 0, _w_ti_0)
        w_t.setItem(_i_row, 1, _w_ti_1)
        w_t.setItem(_i_row, 2, _w_ti_2)
        _i_row += 1
    w_t.cellChanged.connect(lambda _1, _2: temp_func(w_t, _1, _2, pd2d_phase))
    lay_to_fill.addWidget(w_t)

    #lay_to_fill.addStretch(1)
    widg_out = QtWidgets.QWidget()
    widg_out.setLayout(lay_to_fill)
    return widg_out

