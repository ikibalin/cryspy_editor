import pycifstar
import cryspy
import os
import copy

def is_in_rcif_block(rcif_block, cryspy_obj):
    ls_cryspy = cryspy_obj.to_cif.split("\n")
    l_name = [_.strip().split()[0] for _ in ls_cryspy if _.startswith("_")]
    l_flag = [rcif_block.is_value(_name) for _name in l_name]
    return any(l_flag), all(l_flag)
    

#f_name = os.path.join(os.getcwd(), "examples", "DyAlO3", "main.rcif")
#rcif = pycifstar.to_global(f_name)


def rcif_to_cryspy(rcif):
    l_cryst_obj_items = [cryspy.Cell(),
              cryspy.SpaceGroup(),
              cryspy.BeamPolarization(),
              cryspy.Pd2dMeas(),
              cryspy.Pd2dInstrResolution(),
              cryspy.Pd2dInstrReflexAsymmetry(),
              cryspy.Extinction(),
              cryspy.Pd2dProc(),
              cryspy.OrientMatrix()]
    #cryspy.Pd2dBackground()
    l_cryst_obj_loops = [cryspy.AtomSite(),
                     cryspy.AtomSiteAniso(),
                     cryspy.AtomSiteMagnetism(),
                     cryspy.AtomSiteMagnetismAniso(),
                     cryspy.AtomType(),
                     cryspy.Pd2dExclude(),
                     cryspy.Pd2dPhase(),
                     cryspy.Pd2dPeak(),
                     cryspy.PdMeas()]

    l_global_cryst = []
    for _data in rcif.datas:
        l_data_cryst = []
        for cryst_obj in l_cryst_obj_items:
            flag_1, flag_2 = is_in_rcif_block(_data.items, cryst_obj)
            if flag_1:
                cryst_obj_n = copy.deepcopy(cryst_obj)
                cryst_obj_n.from_cif(str(_data.items))
                l_data_cryst.append(cryst_obj_n)
        for cryst_obj in l_cryst_obj_loops:
            for _loop in _data.loops:
                flag_1, flag_2 = is_in_rcif_block(_loop, cryst_obj)
                if flag_1:
                    cryst_obj_n = copy.deepcopy(cryst_obj)
                    cryst_obj_n.from_cif(str(_loop))
                    l_data_cryst.append(cryst_obj_n)
        l_global_cryst.append(l_data_cryst)
    return l_global_cryst


