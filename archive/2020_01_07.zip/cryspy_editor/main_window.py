# -*- coding: utf-8 -*-
"""
Simple RhoChi viewer
"""
__author__ = 'ikibalin'
__version__ = "2019_10_31"

import os
import os.path
import sys
import numpy

import pycifstar
import cryspy
import lib_mem

from .b_rcif_to_cryspy import rcif_to_cryspy
from .widgets import (widget_for_cell, widget_for_space_group,
     widget_for_atom_site, widget_for_item, widget_for_loop, widget_for_atom_site_magnetism_aniso, 
    widget_for_crystal, widget_for_pd2d_proc, widget_for_pd2d_meas, widget_for_pd2d_phase, 
    widget_for_mem_tensor, widget_for_density, widget_for_diffrn_refln, widget_for_pd2d, 
    widget_for_pd2dt, widget_for_pd2d_instr_reflex_asymmetry,
    widget_for_pd2d_instr_resolution, widget_for_pd2d_exclude)

from PyQt5 import QtWidgets
from PyQt5 import QtGui
from PyQt5 import QtCore





def del_layout(layout):
    """
    delete all elements from layouts
    """
    for i in reversed(range(layout.count())):
        if layout.itemAt(i).widget() != None:
           layout.itemAt(i).widget().setParent(None)
        elif layout.itemAt(i).layout() != None:
            del_layout(layout.itemAt(i).layout())
            layout.itemAt(i).layout().setParent(None)
        else:
            layout.removeItem(layout.itemAt(i))
    return



class mythread(QtCore.QThread):
    def __init__(self, parent=None):
        QtCore.QThread.__init__(self,parent)
        self.signal = None
        self.rhochi = None
        self.mem = None

    def run(self):
        l_message = []
        if self.rhochi is not None:
            self.rhochi.refine()
        elif self.mem is not None:
            self.mem.maximize_entropy(10e-8, 251)
        #try:
        #    l_message = []
        #    if self.rhochi is not None:
        #        self.rhochi.refine()
        #    elif self.mem is not None:
        #        self.mem.maximize_entropy(10e-8, 251)
        #except:
        #    l_message = ["Undefined mistake during the refinement procedure.\nSomething wrong."]
        print("\n".join(l_message))
        print("Calculations are stopped")



        self.signal.messages = l_message
        self.signal.rename_signal.emit()


class cthread_signal(QtCore.QObject):
    rename_signal = QtCore.pyqtSignal()


class cbuilder(QtWidgets.QMainWindow):
    def __init__(self, f_dir_prog=os.path.dirname(__file__)):
        super(cbuilder, self).__init__()

        self.__f_dir_prog = f_dir_prog 
        self.__f_dir_data = f_dir_prog 
        self.__f_star_file = None
        self.__mode = "star"
        
        self.def_actions()
        self.init_widget()
        self.setWindowTitle(f'Editor')

        self.__widg_central.thread = mythread()
        self.__widg_central.signal = cthread_signal()
        self.__widg_central.thread.signal = self.__widg_central.signal
        self.__widg_central.thread.signal.rename_signal.connect(self.calc_is_finished)

        #self.setStyleSheet("background-color:lightgray;")
        self.show()

    def calc_is_finished(self):
        m_box = QtWidgets.QMessageBox()
        m_box.setIcon(QtWidgets.QMessageBox.Information)
        m_box.setText("Calculations are finished")
        m_box.setWindowTitle("Message")
        m_box.setStandardButtons(QtWidgets.QMessageBox.Ok | QtWidgets.QMessageBox.Cancel)
        m_box.exec()
        if self.__mode == "rhochi":
            self.to_rhochi()
        elif self.__mode == "mem":
            self.to_mem()

    def def_actions(self):
        f_dir_prog = self.__f_dir_prog
        f_dir_prog_icon = os.path.join(f_dir_prog, 'f_icon')
        self.setWindowIcon(QtGui.QIcon(os.path.join(f_dir_prog_icon,'icon.png'))) 

        new_action = QtWidgets.QAction(QtGui.QIcon(os.path.join(f_dir_prog_icon,'new.png')),'&New', self)
        new_action.setStatusTip('New rhochi file')
        new_action.triggered.connect(self.new_rhochi)

        open_action = QtWidgets.QAction(QtGui.QIcon(os.path.join(f_dir_prog_icon,'open.png')),'&Open', self)
        open_action.setShortcut('Ctrl+O')
        open_action.setStatusTip('Open file')
        open_action.triggered.connect(self.open)

        to_star_action = QtWidgets.QAction(QtGui.QIcon(os.path.join(f_dir_prog_icon,'to_star.png')),'S&TAR mode', self)
        to_star_action.setStatusTip('Switch on STAR mode')
        to_star_action.triggered.connect(self.to_star)

        to_cryspy_action = QtWidgets.QAction(QtGui.QIcon(os.path.join(f_dir_prog_icon,'to_cryspy.png')),'&CrysPy mode', self)
        to_cryspy_action.setStatusTip('Switch on CrysPy mode')
        to_cryspy_action.triggered.connect(self.to_cryspy)

        to_rhochi_action = QtWidgets.QAction(QtGui.QIcon(os.path.join(f_dir_prog_icon,'to_rhochi.png')),'&RhoChi mode', self)
        to_rhochi_action.setStatusTip('Switch on RhoChi mode')
        to_rhochi_action.triggered.connect(self.to_rhochi)

        to_mem_action = QtWidgets.QAction(QtGui.QIcon(os.path.join(f_dir_prog_icon,'to_mem.png')),'&MEM mode', self)
        to_mem_action.setStatusTip('Switch on MEM mode')
        to_mem_action.triggered.connect(self.to_mem)

        save_action = QtWidgets.QAction(QtGui.QIcon(os.path.join(f_dir_prog_icon,'save.png')),'&Save', self)
        save_action.setShortcut('Ctrl+S')
        save_action.setStatusTip('Save')
        save_action.triggered.connect(self.save)

        save_as_action = QtWidgets.QAction(QtGui.QIcon(os.path.join(f_dir_prog_icon,'save_as.png')),'Save &as...', self)
        save_as_action.setStatusTip('Save as ...')
        save_as_action.triggered.connect(self.save_as)

        self.statusBar()

        menubar = self.menuBar()
        fileMenu = menubar.addMenu('&File')
        fileMenu.addAction(new_action)
        fileMenu.addAction(open_action)
        fileMenu.addAction(to_star_action)
        fileMenu.addAction(to_cryspy_action)
        fileMenu.addAction(to_rhochi_action)
        fileMenu.addAction(to_mem_action)
        fileMenu.addAction(save_action)
        fileMenu.addAction(save_as_action)

        self.toolbar = self.addToolBar("Open")
        self.toolbar.addAction(new_action)
        self.toolbar.addAction(open_action)
        self.toolbar.addAction(to_star_action)
        self.toolbar.addAction(to_cryspy_action)
        self.toolbar.addAction(to_rhochi_action)
        self.toolbar.addAction(to_mem_action)
        self.toolbar.addAction(save_action)
        self.toolbar.addAction(save_as_action)

    def to_star(self):
        if self.__widg_central._star is not None:
            star_ = self.__widg_central._star
        elif self.__f_star_file is not None:
            star_ = pycifstar.to_global(self.__f_star_file)
        else:
            f_file_data_new, okPressed = QtWidgets.QFileDialog.getOpenFileName(self, 'Select a cif file:', self.__f_dir_data, "All files (*.*)")
            if not(okPressed):
                return None
            star_ = pycifstar.to_global(f_file_data_new)
            self.__f_star_file = f_file_data_new
            self.__f_dir_data = os.path.dirname(f_file_data_new) 
        self.__mode = "star"
        self.__widg_central.form_widg_cpanel_star(star_)

    def to_cryspy(self):
        if self.__widg_central._cryspy_objs is not None:
            cryspy_objs = self.__widg_central._cryspy_objs
        elif self.__widg_central._star is not None:
            star = self.__widg_central._star
            cryspy_objs = rcif_to_cryspy(star)
        else:
            self.to_star()
            star = self.__widg_central._star
            cryspy_objs = rcif_to_cryspy(star)
        self.__mode = "cryspy"
        self.__widg_central.form_widg_cpanel_cryspy(cryspy_objs)

    def to_rhochi(self):
        if self.__widg_central._rhochi_obj is not None:
            rhochi_obj = self.__widg_central._rhochi_obj
        elif self.__widg_central._star is not None:
            star = self.__widg_central._star
            rhochi_obj = cryspy.RhoChi()
            rhochi_obj.from_cif(str(star))
            rhochi_obj.file_input = self.__f_star_file
        else:
            self.to_star()
            star = self.__widg_central._star
            rhochi_obj = cryspy.RhoChi()
            rhochi_obj.from_cif(str(star))
            rhochi_obj.file_input = self.__f_star_file
        self.__mode = "rhochi"
        self.__widg_central.form_widg_cpanel_rhochi(rhochi_obj)
        
    def to_mem(self):
        if self.__widg_central._mem_obj is not None:
            mem_obj = self.__widg_central._mem_obj
        elif self.__widg_central._star is not None:
            star = self.__widg_central._star
            mem_obj = lib_mem.MemTensor()
            mem_obj.from_cif(str(star))
            mem_obj.file_input = self.__f_star_file
        else:
            self.to_star()
            star = self.__widg_central._star
            mem_obj = lib_mem.MemTensor()
            mem_obj.from_cif(str(star))
            mem_obj.file_input = self.__f_star_file
        self.__mode = "mem"
        self.__widg_central.form_widg_cpanel_mem(mem_obj)

    def init_widget(self): 
        """
        module is reloaded for cwidget
        """
        self.location_on_the_screen()
        self.__widg_central = cwidget(self.info_width)
        self.setCentralWidget(self.__widg_central)


    def location_on_the_screen(self):
        """
        position and size of main window
        """
        screen = QtWidgets.QDesktopWidget().screenGeometry()
        self.setMinimumSize(screen.width()*1/4, screen.height()*1/4)
        self.info_width = screen.width()*8/10
        self.move(screen.width()/10 , screen.height()/20)
        self.resize(screen.width()*8./10., screen.height()*14./16.)


    def save_star(self, f_name):
        star_obj = self.__widg_central._star
        with open(f_name, "w") as fid:
            fid.write(str(star_obj))
        return
        
    def save_cryspy(self, f_name):
        star_obj = self.__widg_central._cryspy_objs
        ls_out = []
        for _list in star_obj:
            for _obj in _list:
                ls_out.append(_obj.to_cif)
        with open(f_name, "w") as fid:
            fid.write("\n".join(ls_out))
        return

    def save_rhochi(self, f_name):
        rhochi_obj = self.__widg_central._rhochi_obj
        if rhochi_obj is None:
            return
        rhochi_obj.file_input = f_name
        rhochi_obj.save_to_file(f_name)
        return

    def save_mem(self, f_name):
        mem_obj = self.__widg_central._mem_obj
        if mem_obj is None:
            return
        mem_obj.file_input = f_name
        mem_obj.save_to_file(f_name)
        return

    def save(self):
        f_name = self.__f_star_file
        if f_name is None:
            f_dir_data = self.__f_dir_data
            f_name = os.path.join(f_dir_data, "main.rcif")
        if self.__mode == "star":
            self.save_star(f_name)
        elif self.__mode == "cryspy":
            self.save_cryspy(f_name)
        elif self.__mode == "rhochi":
            self.save_rhochi(f_name)
        elif self.__mode == "mem":
            self.save_mem(f_name)
        return

    def save_as(self):
        f_name, okPressed = QtWidgets.QFileDialog.getSaveFileName(self, 'Select a file:', self.__f_dir_data, "Rcif files (*.rcif)")
        if not(okPressed):
            return None
        self.__f_star_file = f_name
        self.__f_dir_data = os.path.dirname(f_name)
        self.save()

    def open(self):
        f_name, okPressed = QtWidgets.QFileDialog.getOpenFileName(self, 'Select a cif file:', self.__f_dir_data, "All files (*.*)")
        if not(okPressed):
            return None
        self.__widg_central._star = None
        self.__widg_central._cryspy_objs = None
        self.__widg_central._rhochi_obj = None
        self.__widg_central._mem_obj = None
        self.__f_star_file = f_name
        self.__f_dir_data = os.path.dirname(f_name)
        if self.__mode == "star":
            self.to_star()
        elif self.__mode == "cryspy":
            self.to_cryspy()
        elif self.__mode == "rhochi":
            self.to_rhochi()
        elif self.__mode == "mem":
            self.to_mem()

    def new_rhochi(self):
        self.__mode = "rhochi"
        f_name, okPressed = QtWidgets.QFileDialog.getSaveFileName(self, "Select a folder:", "main.rcif")
        if not okPressed:
            return
        self.__f_star_file = f_name
        self.__f_dir_data = os.path.dirname(f_name)

        i, okPressed = QtWidgets.QInputDialog.getInt(self, "Type of data","Type of experiment:\n\n 1. Single crystal\n 2. Powder 1D\n 3 .Powder 2D\n 4 .Powder 2D (one-axial texture)", 1, 1, 4, 1)
        if okPressed:
            exp_type = str(i)
            cryspy.scripts.rhochi.cl_rhochi.create_temporary(f_name, exp_type)
        self.to_rhochi()

class cwidget(QtWidgets.QSplitter):
    def __init__(self, width):
        self.info_width = width
        super(cwidget, self).__init__()
        self._star = None
        self._cryspy_objs = None
        self._rhochi_obj = None
        self._mem_obj = None
        self.init_widget()

    def init_widget(self):
        """
        make central layout
        """
        width_m_1 = self.info_width/10
        width_m_2 = (9*self.info_width)/10

        self.__width_cpanel = width_m_1
        self.__width_left = width_m_2

        self.lay_cpanel = QtWidgets.QVBoxLayout()
        self.lay_left = QtWidgets.QVBoxLayout()

        w_cpanel = QtWidgets.QWidget()
        w_cpanel.setLayout(self.lay_cpanel)

        w_left = QtWidgets.QWidget()
        w_left.setLayout(self.lay_left)

        self.addWidget(w_cpanel)
        self.addWidget(w_left)
        self.setSizes([width_m_1, width_m_2])


    def form_widg_cpanel_star(self, star=None):
        del_layout(self.lay_cpanel)
        width_m_1 = self.__width_cpanel

        if star is None:
            star = self._star

        if star is not None:
            self._star = star

            w1 = QtWidgets.QTreeWidget()
            w1.setMinimumSize(width_m_1, width_m_1)
            sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)
            w1.setSizePolicy(sizePolicy)

            w1.setColumnCount(1)
            w1.setHeaderHidden(True)

            l_data_name = [_.name for _ in star.datas]
            for _data in star.datas:
                wi = QtWidgets.QTreeWidgetItem()
                wi.setText(0, _data.name)
                for _loop in _data.loops:
                    wii = QtWidgets.QTreeWidgetItem()
                    if _loop.name != "":
                        wii.setText(0, f"loop_{_loop.name:}{_loop.prefix:}")
                    else:
                        wii.setText(0, f"loop{_loop.prefix:}")
                    wi.addChild(wii)
                for _item in _data.items:
                    wii = QtWidgets.QTreeWidgetItem()
                    wii.setText(0, _item.name)
                    wi.addChild(wii)

                w1.addTopLevelItem(wi)
            w1.itemClicked.connect(self.onItemClickedRcif)

            self.lay_cpanel.addWidget(w1)

    @QtCore.pyqtSlot(QtWidgets.QTreeWidgetItem, int)
    def onItemClickedRcif(self, it, col):
        _1 = it.text(col)
        if _1.startswith("loop_"):
            _1 = _1[len("loop_"):]
        s_name = _1
        star_ = self._star
        self.form_widg_left_star(star_[s_name])



    def form_widg_cpanel_cryspy(self, cryspy_objs=None):
        del_layout(self.lay_cpanel)
        width_m_1 = self.__width_cpanel

        if cryspy_objs is None:
            cryspy_objs = self._cryspy_objs

        if cryspy_objs is not None:
            self._cryspy_objs = cryspy_objs

            w1 = QtWidgets.QTreeWidget()
            w1.setMinimumSize(width_m_1, width_m_1)
            sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)
            w1.setSizePolicy(sizePolicy)

            w1.setColumnCount(1)
            w1.setHeaderHidden(True)

            #wi_glob = QtWidgets.QTreeWidgetItem() 
            #wi_glob.setText(0, GLOB.name)

            for _cryspy_objs in cryspy_objs:
                wi = QtWidgets.QTreeWidgetItem()
                wi.setText(0, "data")
                for _cryspy_obj in _cryspy_objs:
                    wii = QtWidgets.QTreeWidgetItem()
                    flag = True
                    if isinstance(_cryspy_obj, cryspy.Cell):
                        wii.setText(0, "Cell")
                    elif isinstance(_cryspy_obj, cryspy.SpaceGroup):
                        wii.setText(0, "SpaceGroup")
                    elif isinstance(_cryspy_obj, cryspy.BeamPolarization):
                        wii.setText(0, "BeamPolarization")
                    elif isinstance(_cryspy_obj, cryspy.Pd2dMeas):
                        wii.setText(0, "Pd2dMeas")
                    elif isinstance(_cryspy_obj, cryspy.Pd2dInstrResolution):
                        wii.setText(0, "Pd2dInstrResolution")
                    elif isinstance(_cryspy_obj, cryspy.Pd2dInstrReflexAsymmetry):
                        wii.setText(0, "Pd2dInstrReflexAsymmetry")
                    elif isinstance(_cryspy_obj, cryspy.Extinction):
                        wii.setText(0, "Extinction")
                    elif isinstance(_cryspy_obj, cryspy.OrientMatrix):
                        wii.setText(0, "OrientMatrix")
                    elif isinstance(_cryspy_obj, cryspy.DiffrnRefln):
                        wii.setText(0, "DiffrnRefln")
                    elif isinstance(_cryspy_obj, cryspy.AtomSite):
                        wii.setText(0, "AtomSite")
                    elif isinstance(_cryspy_obj, cryspy.AtomSiteAniso):
                        wii.setText(0, "AtomSiteAniso")
                    elif isinstance(_cryspy_obj, cryspy.AtomSiteMagnetism):
                        wii.setText(0, "AtomSiteMagnetism")
                    elif isinstance(_cryspy_obj, cryspy.AtomSiteMagnetismAniso):
                        wii.setText(0, "AtomSiteMagnetismAniso")
                    elif isinstance(_cryspy_obj, cryspy.AtomType):
                        wii.setText(0, "AtomType")
                    elif isinstance(_cryspy_obj, cryspy.Pd2dExclude):
                        wii.setText(0, "Pd2dExclude")
                    elif isinstance(_cryspy_obj, cryspy.Pd2dPhase):
                        wii.setText(0, "Pd2dPhase")
                    elif isinstance(_cryspy_obj, cryspy.Pd2dPeak):
                        wii.setText(0, "Pd2dPeak")
                    elif isinstance(_cryspy_obj, cryspy.Pd2dProc):
                        wii.setText(0, "Pd2dProc")
                    elif isinstance(_cryspy_obj, cryspy.PdMeas):
                        wii.setText(0, "PdMeas")
                    else:
                        flag = False
                    if flag:
                        wii.cryspy_obj = _cryspy_obj
                        wi.addChild(wii)
                w1.addTopLevelItem(wi)
            w1.itemClicked.connect(self.onItemClickedCryspy)
            self.lay_cpanel.addWidget(w1)

    @QtCore.pyqtSlot(QtWidgets.QTreeWidgetItem, int)
    def onItemClickedCryspy(self, it, col):
        self.form_widg_left_cryspy(it.cryspy_obj)
        #try:
        #    self.form_widg_left_cryspy(it.cryspy_obj)
        #except:
        #    pass



    def form_widg_cpanel_rhochi(self, rhochi_obj=None):
        del_layout(self.lay_cpanel)
        width_m_1 = self.__width_cpanel
        
        if rhochi_obj is None:
            rhochi_obj = self._rhochi_obj

        if rhochi_obj is not None:
            self._rhochi_obj = rhochi_obj

            w1 = QtWidgets.QTreeWidget()
            w1.setMinimumSize(width_m_1, width_m_1)
            sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)
            w1.setSizePolicy(sizePolicy)

            w1.setColumnCount(1)
            w1.setHeaderHidden(True)

            for _crystal in rhochi_obj.crystals:
                wi = QtWidgets.QTreeWidgetItem()
                wi.cryspy_obj = _crystal
                wi.setText(0, f"crystal: {_crystal.label:}")

                wii = QtWidgets.QTreeWidgetItem()
                wii.setText(0, "Cell")
                wii.cryspy_obj = _crystal.cell
                wi.addChild(wii)

                wii = QtWidgets.QTreeWidgetItem()
                wii.setText(0, "SpaceGroup")
                wii.cryspy_obj = _crystal.space_group
                wi.addChild(wii)

                wii = QtWidgets.QTreeWidgetItem()
                wii.setText(0, "AtomSite")
                wii.cryspy_obj = _crystal.atom_site
                wi.addChild(wii)

                wii = QtWidgets.QTreeWidgetItem()
                wii.setText(0, "AtomSiteAniso")
                wii.cryspy_obj = _crystal.atom_site_aniso
                wi.addChild(wii)

                wii = QtWidgets.QTreeWidgetItem()
                wii.setText(0, "AtomSiteMagnetism")
                wii.cryspy_obj = _crystal.atom_site_magnetism
                wi.addChild(wii)

                wii = QtWidgets.QTreeWidgetItem()
                wii.setText(0, "AtomSiteMagnetismAniso")
                wii.cryspy_obj = _crystal.atom_site_magnetism_aniso
                wi.addChild(wii)
                w1.addTopLevelItem(wi)

            for _experiment in rhochi_obj.experiments:
                if isinstance(_experiment, cryspy.Diffrn):
                    wi = QtWidgets.QTreeWidgetItem()
                    wi.cryspy_obj = _experiment
                    wi.setText(0, f"exp. diffrn {_experiment.label:}")

                    wii = QtWidgets.QTreeWidgetItem()
                    wii.setText(0, "OrientMatrix")
                    wii.cryspy_obj = _experiment.orient_matrix
                    wi.addChild(wii)

                    wii = QtWidgets.QTreeWidgetItem()
                    wii.setText(0, "DiffrnRefln")
                    wii.cryspy_obj = _experiment.diffrn_refln
                    wi.addChild(wii)
                

                elif isinstance(_experiment, cryspy.Pd):
                    wi = QtWidgets.QTreeWidgetItem()
                    wi.cryspy_obj = _experiment
                    wi.setText(0, f"exp. pd: {_experiment.label:}")
                elif (isinstance(_experiment, cryspy.Pd2d) | isinstance(_experiment, cryspy.Pd2dt)):
                    if isinstance(_experiment, cryspy.Pd2d):
                        wi = QtWidgets.QTreeWidgetItem()
                        wi.setText(0, f"exp. pd2d: {_experiment.label:}")
                    else:
                        wi = QtWidgets.QTreeWidgetItem()
                        wi.setText(0, f"exp. pd2dt: {_experiment.label:}")
                    wi.cryspy_obj = _experiment

                    wii = QtWidgets.QTreeWidgetItem()
                    wii.setText(0, "InstrResolution")
                    wii.cryspy_obj = _experiment.resolution
                    wi.addChild(wii)

                    wii = QtWidgets.QTreeWidgetItem()
                    wii.setText(0, "InstrRexlexAsymetry")
                    wii.cryspy_obj = _experiment.asymmetry
                    wi.addChild(wii)

                    wii = QtWidgets.QTreeWidgetItem()
                    wii.setText(0, "Exclude")
                    wii.cryspy_obj = _experiment.exclude
                    wi.addChild(wii)

                    wii = QtWidgets.QTreeWidgetItem()
                    wii.setText(0, "Phase")
                    wii.cryspy_obj = _experiment.phase
                    wi.addChild(wii)

                    wii = QtWidgets.QTreeWidgetItem()
                    wii.setText(0, "Meas")
                    wii.cryspy_obj = _experiment.meas
                    wi.addChild(wii)

                    wii = QtWidgets.QTreeWidgetItem()
                    wii.setText(0, "Proc")
                    wii.cryspy_obj = _experiment.proc
                    wi.addChild(wii)

                    wii = QtWidgets.QTreeWidgetItem()
                    wii.setText(0, "Peak")
                    wii.cryspy_obj = _experiment.peaks
                    wi.addChild(wii)

                    #wii = QtWidgets.QTreeWidgetItem()
                    #wii.setText(0, "Pd2dReflns")
                    #wii.cryspy_obj = _crystal.reflns
                    #wi.addChild(wii)
                
                
                wii = QtWidgets.QTreeWidgetItem()
                wii.setText(0, "BeamPolarization")
                wii.cryspy_obj = _experiment.beam_polarization
                wi.addChild(wii)

                wii = QtWidgets.QTreeWidgetItem()
                wii.setText(0, "Wavelength")
                wii.cryspy_obj = _experiment.wavelength
                wi.addChild(wii)
                w1.addTopLevelItem(wi)

            w1.itemClicked.connect(self.onItemClickedCryspy)
            self.lay_cpanel.addWidget(w1)

            b_run_rhochi = QtWidgets.QPushButton("Run RhoChi")
            b_run_rhochi.clicked.connect(self.run_rhochi)
            self.lay_cpanel.addWidget(b_run_rhochi)
            sizePolicy_2 = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)
            b_run_rhochi.setSizePolicy(sizePolicy_2)
            b_run_rhochi.setMinimumWidth(width_m_1)


    def run_rhochi(self):
        print("Started")
        self.thread.rhochi = self._rhochi_obj
        self.thread.start()
        print("Done")
        #self._rhochi_obj.refine()
        #self.form_widg_cpanel_rhochi()


    def form_widg_cpanel_mem(self, mem_obj=None):
        del_layout(self.lay_cpanel)
        width_m_1 = self.__width_cpanel
        
        if mem_obj is None:
            mem_obj = self._mem_obj

        if mem_obj is not None:
            self._mem_obj = mem_obj

            w1 = QtWidgets.QTreeWidget()
            w1.setMinimumSize(width_m_1, width_m_1)
            sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)
            w1.setSizePolicy(sizePolicy)

            w1.setColumnCount(1)
            w1.setHeaderHidden(True)
            wi = QtWidgets.QTreeWidgetItem()
            wi.cryspy_obj = mem_obj
            wi.setText(0, f"MEM")
            w1.addTopLevelItem(wi)



            _crystal = mem_obj.crystal

            wi = QtWidgets.QTreeWidgetItem()
            wi.cryspy_obj = _crystal
            wi.setText(0, f"crystal: {_crystal.label:}")

            wii = QtWidgets.QTreeWidgetItem()
            wii.setText(0, "Cell")
            wii.cryspy_obj = _crystal.cell
            wi.addChild(wii)

            wii = QtWidgets.QTreeWidgetItem()
            wii.setText(0, "SpaceGroup")
            wii.cryspy_obj = _crystal.space_group
            wi.addChild(wii)

            wii = QtWidgets.QTreeWidgetItem()
            wii.setText(0, "AtomSite")
            wii.cryspy_obj = _crystal.atom_site
            wi.addChild(wii)

            wii = QtWidgets.QTreeWidgetItem()
            wii.setText(0, "AtomSiteAniso")
            wii.cryspy_obj = _crystal.atom_site_aniso
            wi.addChild(wii)

            wii = QtWidgets.QTreeWidgetItem()
            wii.setText(0, "AtomSiteMagnetism")
            wii.cryspy_obj = _crystal.atom_site_magnetism
            wi.addChild(wii)

            wii = QtWidgets.QTreeWidgetItem()
            wii.setText(0, "AtomSiteMagnetismAniso")
            wii.cryspy_obj = _crystal.atom_site_magnetism_aniso
            wi.addChild(wii)
            w1.addTopLevelItem(wi)


            for _experiment in mem_obj.diffrns:
                wi = QtWidgets.QTreeWidgetItem()
                wi.cryspy_obj = _experiment
                wi.setText(0, f"exp. diffrn {_experiment.label:}")

                wii = QtWidgets.QTreeWidgetItem()
                wii.setText(0, "OrientMatrix")
                wii.cryspy_obj = _experiment.orient_matrix
                wi.addChild(wii)

                wii = QtWidgets.QTreeWidgetItem()
                wii.setText(0, "DiffrnRefln")
                wii.cryspy_obj = _experiment.diffrn_refln
                wi.addChild(wii)
                
                wii = QtWidgets.QTreeWidgetItem()
                wii.setText(0, "BeamPolarization")
                wii.cryspy_obj = _experiment.beam_polarization
                wi.addChild(wii)

                wii = QtWidgets.QTreeWidgetItem()
                wii.setText(0, "Wavelength")
                wii.cryspy_obj = _experiment.wavelength
                wi.addChild(wii)
                w1.addTopLevelItem(wi)

            _density = mem_obj.density
            wi = QtWidgets.QTreeWidgetItem()
            wi.cryspy_obj = _density
            wi.setText(0, f"density")
            
            for _density_point in _density.density_points:
                wii = QtWidgets.QTreeWidgetItem()
                wii.setText(0, f"density_point_{_density_point.atom_label:}")
                wii.cryspy_obj = _density_point
                wi.addChild(wii)
            w1.addTopLevelItem(wi)
                

            w1.itemClicked.connect(self.onItemClickedCryspy)
            self.lay_cpanel.addWidget(w1)

            b_run_mem = QtWidgets.QPushButton("Run MEM")
            b_run_mem.clicked.connect(self.run_mem)
            self.lay_cpanel.addWidget(b_run_mem)
            sizePolicy_2 = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)
            b_run_mem.setSizePolicy(sizePolicy_2)
            b_run_mem.setMinimumWidth(width_m_1)


    def run_mem(self):
        print("Started")
        #self.thread.mem = self._mem_obj
        #self.thread.start()
        
        self._mem_obj.maximize_entropy()
        #self.form_widg_cpanel_rhochi()
        print("Done")


    def form_widg_left_star(self, star_object):
        #form the left widget
        del_layout(self.lay_left)

        if isinstance(star_object, pycifstar.Item):
            _item = star_object
            widg_out = widget_for_item(_item)
            self.lay_left.addWidget(widg_out)
        elif isinstance(star_object, pycifstar.Loop): 
            _loop = star_object
            widg_out = widget_for_loop(_loop)
            self.lay_left.addWidget(widg_out)
        elif isinstance(star_object, pycifstar.Data):
            widg_out = QtWidgets.QFrame()
            sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)
            widg_out.setSizePolicy(sizePolicy)
            self.lay_left.addWidget(widg_out)
        elif isinstance(star_object, pycifstar.Global):
            widg_out = QtWidgets.QFrame()
            sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)
            widg_out.setSizePolicy(sizePolicy)
            self.lay_left.addWidget(widg_out)


    def form_widg_left_cryspy(self, cryspy_object):
        #form the left widget
        del_layout(self.lay_left)

        if isinstance(cryspy_object, cryspy.Cell):
            widg_out = widget_for_cell(cryspy_object)
        elif isinstance(cryspy_object, cryspy.SpaceGroup):
            widg_out = widget_for_space_group(cryspy_object)
        elif isinstance(cryspy_object, cryspy.AtomSite):
            widg_out = widget_for_atom_site(cryspy_object)
        elif isinstance(cryspy_object, cryspy.AtomSiteMagnetismAniso):
            widg_out = widget_for_atom_site_magnetism_aniso(cryspy_object)
        elif isinstance(cryspy_object, cryspy.Crystal):
            widg_out = widget_for_crystal(cryspy_object)
        elif isinstance(cryspy_object, cryspy.Pd2dProc):
            widg_out = widget_for_pd2d_proc(cryspy_object)
        elif isinstance(cryspy_object, cryspy.Pd2dMeas):
            widg_out = widget_for_pd2d_meas(cryspy_object)
        elif isinstance(cryspy_object, cryspy.Pd2dPhase):
            widg_out = widget_for_pd2d_phase(cryspy_object)
        elif isinstance(cryspy_object, cryspy.Pd2d):
            widg_out = widget_for_pd2d(cryspy_object)
        elif isinstance(cryspy_object, cryspy.Pd2dt):
            widg_out = widget_for_pd2dt(cryspy_object)
        elif isinstance(cryspy_object, cryspy.Pd2dInstrResolution):
            widg_out = widget_for_pd2d_instr_resolution(cryspy_object)
        elif isinstance(cryspy_object, cryspy.Pd2dInstrReflexAsymmetry):
            widg_out = widget_for_pd2d_instr_reflex_asymmetry(cryspy_object)
        elif isinstance(cryspy_object, cryspy.Pd2dExclude):
            widg_out = widget_for_pd2d_exclude(cryspy_object)
        elif isinstance(cryspy_object, cryspy.DiffrnRefln):
            widg_out = widget_for_diffrn_refln(cryspy_object)
        elif isinstance(cryspy_object, lib_mem.MemTensor):
            widg_out = widget_for_mem_tensor(cryspy_object)
        elif isinstance(cryspy_object, lib_mem.Density):
            widg_out = widget_for_density(cryspy_object)
        else:
            widg_out = QtWidgets.QFrame()
            sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)
            widg_out.setSizePolicy(sizePolicy)
        self.lay_left.addWidget(widg_out)




def main_w(l_arg= []):
    app = QtWidgets.QApplication(l_arg)
    f_dir_prog = os.path.dirname(__file__)
    main_wind_1 = cbuilder(f_dir_prog)
    sys.exit(app.exec_())


if __name__ == '__main__':
    l_arg = sys.argv
    main_w(l_arg)


