import sys

from .main_window import main_w



if __name__ == '__main__':
    l_arg = sys.argv
    main_w(l_arg)