"""
CrysPyEditor
======

"""
name = "cryspy_editor"
__version__ = "1.4.12"
from cryspy_editor.main_window import main_w


if __name__ == "__main__":
    main_w()
