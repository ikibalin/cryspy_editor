"""
CryspyEditor
======

"""
name = "crypsy_editor"
from .main_window import main_w


if __name__ == "__main__":
    main_w()
