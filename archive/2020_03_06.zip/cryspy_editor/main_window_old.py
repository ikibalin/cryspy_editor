# -*- coding: utf-8 -*-
__author__ = 'ikibalin'
__version__ = "2020_01_15"

import os
import os.path
import sys


import importlib
FLAG_CRYSPY = importlib.util.find_spec("cryspy") is not None
FLAG_MAGREF = importlib.util.find_spec("magref") is not None
FLAG_MEM = importlib.util.find_spec("lib_mem") is not None

from pycifstar import Item, Items, Loop, Data, Global, to_global
from cryspy_editor.widgets.FUNCTIONS import del_layout

if FLAG_CRYSPY is not None:
    from cryspy.common.cl_global_constr import GlobalConstr
    from cryspy.common.cl_global_constr import DataConstr
    from cryspy.common.cl_loop_constr import LoopConstr
    from cryspy.common.cl_item_constr import ItemConstr

    from cryspy.scripts.cl_rhochi import RhoChi
    from cryspy.cif_like.cl_crystal import Crystal
    from cryspy.cif_like.cl_pd import Pd
    from cryspy.cif_like.cl_pd2d import Pd2d
    from cryspy.cif_like.cl_diffrn import Diffrn

    from cryspy.pd1dcif_like.cl_pd_meas import PdMeasL
    from cryspy.pd1dcif_like.cl_pd_proc import PdProcL
    from cryspy.pd2dcif_like.cl_pd2d_meas import Pd2dMeas
    from cryspy.pd2dcif_like.cl_pd2d_proc import Pd2dProc 

if FLAG_MAGREF is not None:
    from magref import CrystRef
    from magref.classes.cl_cryst_field import CrystField
    from magref.classes.cl_meas_inelastic import MeasInelasticL

if FLAG_MEM is not None:
    from lib_mem.mem.cl_density import Density
    from lib_mem.scripts.cl_mem_tensor import MemTensor

from cryspy_editor.b_rcif_to_cryspy import rcif_to_cryspy


from cryspy_editor.widgets.widget_item import widget_for_item
from cryspy_editor.widgets.widget_loop import widget_for_loop
from cryspy_editor.widgets.widget_global_constr import widget_for_global_constr
from cryspy_editor.widgets.widget_data_constr import widget_for_data_constr
from cryspy_editor.widgets.widget_loop_constr import widget_for_loop_constr
from cryspy_editor.widgets.widget_item_constr import widget_for_item_constr
from cryspy_editor.widgets.widget_meas_inelasticl import widget_for_meas_inelasticl
from cryspy_editor.widgets.widget_pd_meas import widget_for_pd_meas
from cryspy_editor.widgets.widget_pd_proc import widget_for_pd_proc
from cryspy_editor.widgets.widget_pd2d_meas import widget_for_pd2d_meas
from cryspy_editor.widgets.widget_pd2d_proc import widget_for_pd2d_proc

from PyQt5 import QtWidgets
from PyQt5 import QtGui
from PyQt5 import QtCore



class mythread(QtCore.QThread):
    def __init__(self, parent=None):
        QtCore.QThread.__init__(self,parent)
        self.signal = None
        self.rhochi = None
        self.mem = None
        self.magref = None
        self.message = None

    def run(self):
        l_message = []
        if self.message is not None:
            if self.message == "magref_gen_alg":
                f_sipf = os.path.join(os.path.dirname(self.magref.file_input), "test.sipf")
                self.magref.refine_gen_alg(f_sipf)
            elif self.message == "magref_simplex":
                f_sipf = os.path.join(os.path.dirname(self.magref.file_input), "test.sipf")
                self.magref.refine(f_sipf)

        elif self.rhochi is not None:
            self.rhochi.refine()
        elif self.mem is not None:
            self.mem.maximize_entropy(10e-8, 251)
        elif self.magref is not None:
            f_sipf = os.path.join(os.path.dirname(self.magref.file_input), "test.sipf")
            self.magref.refine(f_sipf)
        #try:
        #    l_message = []
        #    if self.rhochi is not None:
        #        self.rhochi.refine()
        #    elif self.mem is not None:
        #        self.mem.maximize_entropy(10e-8, 251)
        #except:
        #    l_message = ["Undefined mistake during the refinement procedure.\nSomething wrong."]
        print("\n".join(l_message))
        print("Calculations are stopped")

        self.signal.messages = l_message
        self.signal.rename_signal.emit()


class cthread_signal(QtCore.QObject):
    rename_signal = QtCore.pyqtSignal()


class cbuilder(QtWidgets.QMainWindow):
    def __init__(self, f_dir_data=os.path.dirname(__file__)):
        super(cbuilder, self).__init__()

        self.__f_dir_prog = os.path.dirname(__file__)
        self.__f_dir_data = f_dir_data 
        self.__f_star_file = None
        if os.path.isfile(f_dir_data):
            self.__f_star_file = f_dir_data
            self.__f_dir_data = os.path.dirname(f_dir_data)
        self.__mode = "star"
        
        self.def_actions()
        self.init_widget()
        self.setWindowTitle(f'Editor')

        self.__widg_central.thread = mythread()
        self.__widg_central.signal = cthread_signal()
        self.__widg_central.thread.signal = self.__widg_central.signal
        self.__widg_central.thread.signal.rename_signal.connect(self.calc_is_finished)

        if self.__f_star_file is not None:
            self.to_star()
        #self.setStyleSheet("background-color:lightgray;")
        self.show()

    def calc_is_finished(self):
        m_box = QtWidgets.QMessageBox()
        m_box.setIcon(QtWidgets.QMessageBox.Information)
        m_box.setText("Calculations are finished")
        m_box.setWindowTitle("Message")
        m_box.setStandardButtons(QtWidgets.QMessageBox.Ok | QtWidgets.QMessageBox.Cancel)
        m_box.exec()
        if self.__mode == "rhochi":
            self.to_rhochi()
        elif self.__mode == "mem":
            self.to_mem()
        elif self.__mode == "magref":
            self.to_magref()

    def def_actions(self):
        f_dir_prog = self.__f_dir_prog
        f_dir_prog_icon = os.path.join(f_dir_prog, 'f_icon')
        self.setWindowIcon(QtGui.QIcon(os.path.join(f_dir_prog_icon,'icon.png'))) 

        new_action = QtWidgets.QAction(QtGui.QIcon(os.path.join(f_dir_prog_icon,'new.png')),'&New', self)
        new_action.setStatusTip('New rhochi file')
        new_action.triggered.connect(self.new_rhochi)

        open_action = QtWidgets.QAction(QtGui.QIcon(os.path.join(f_dir_prog_icon,'open.png')),'&Open', self)
        open_action.setShortcut('Ctrl+O')
        open_action.setStatusTip('Open file')
        open_action.triggered.connect(self.open)

        to_star_action = QtWidgets.QAction(QtGui.QIcon(os.path.join(f_dir_prog_icon,'to_star.png')),'S&TAR mode', self)
        to_star_action.setStatusTip('Switch on STAR mode')
        to_star_action.triggered.connect(self.to_star)

        if FLAG_CRYSPY:
            to_cryspy_action = QtWidgets.QAction(QtGui.QIcon(os.path.join(f_dir_prog_icon,'to_cryspy.png')),'&CrysPy mode', self)
            to_cryspy_action.setStatusTip('Switch on CrysPy mode')
            to_cryspy_action.triggered.connect(self.to_cryspy)

            to_rhochi_action = QtWidgets.QAction(QtGui.QIcon(os.path.join(f_dir_prog_icon,'to_rhochi.png')),'&RhoChi mode', self)
            to_rhochi_action.setStatusTip('Switch on RhoChi mode')
            to_rhochi_action.triggered.connect(self.to_rhochi)

        if FLAG_MEM:
            to_mem_action = QtWidgets.QAction(QtGui.QIcon(os.path.join(f_dir_prog_icon,'to_mem.png')),'&MEM mode', self)
            to_mem_action.setStatusTip('Switch on MEM mode')
            to_mem_action.triggered.connect(self.to_mem)

        if FLAG_MAGREF:
            to_magref_action = QtWidgets.QAction(QtGui.QIcon(os.path.join(f_dir_prog_icon,'to_magref.png')),'M&agRef mode', self)
            to_magref_action.setStatusTip('Switch on Magref mode')
            to_magref_action.triggered.connect(self.to_magref)

        save_action = QtWidgets.QAction(QtGui.QIcon(os.path.join(f_dir_prog_icon,'save.png')),'&Save', self)
        save_action.setShortcut('Ctrl+S')
        save_action.setStatusTip('Save')
        save_action.triggered.connect(self.save)

        save_as_action = QtWidgets.QAction(QtGui.QIcon(os.path.join(f_dir_prog_icon,'save_as.png')),'Save &as...', self)
        save_as_action.setStatusTip('Save as ...')
        save_as_action.triggered.connect(self.save_as)

        open_folder = QtWidgets.QAction(QtGui.QIcon(os.path.join(f_dir_prog_icon,'open_folder.png')),'Open folder', self)
        open_folder.setStatusTip('Open folder')
        open_folder.triggered.connect(self.open_folder)

        self.statusBar()

        menubar = self.menuBar()
        fileMenu = menubar.addMenu('&File')
        fileMenu.addAction(new_action)
        fileMenu.addAction(open_action)
        fileMenu.addAction(to_star_action)
        if FLAG_CRYSPY:
            fileMenu.addAction(to_cryspy_action)
            fileMenu.addAction(to_rhochi_action)
        if FLAG_MEM:
            fileMenu.addAction(to_mem_action)
        if FLAG_MAGREF:
            fileMenu.addAction(to_magref_action)
        fileMenu.addAction(save_action)
        fileMenu.addAction(save_as_action)

        self.toolbar = self.addToolBar("Open")
        self.toolbar.addAction(new_action)
        self.toolbar.addAction(open_action)
        self.toolbar.addAction(to_star_action)
        if FLAG_CRYSPY:
            self.toolbar.addAction(to_cryspy_action)
            self.toolbar.addAction(to_rhochi_action)
        if FLAG_MEM:
            self.toolbar.addAction(to_mem_action)
        if FLAG_MAGREF:
            self.toolbar.addAction(to_magref_action)
        self.toolbar.addAction(save_action)
        self.toolbar.addAction(save_as_action)
        self.toolbar.addAction(open_folder)
        

    def to_star(self):
        if self.__widg_central._star is not None:
            star_ = self.__widg_central._star
        elif self.__f_star_file is not None:
            star_ = to_global(self.__f_star_file)
        else:
            f_file_data_new, okPressed = QtWidgets.QFileDialog.getOpenFileName(self, 'Select a cif file:', self.__f_dir_data, "All files (*.*)")
            if not(okPressed):
                return None
            star_ = to_global(f_file_data_new)
            self.__f_star_file = f_file_data_new
            self.__f_dir_data = os.path.dirname(f_file_data_new) 
        self.__mode = "star"
        self.__widg_central.form_widg_cpanel_star(star_)

    def to_cryspy(self):
        mode_orig = self.__mode
        flag = True
        cryspy_obj = None
        str_obj = None
        if mode_orig == "cryspy":
            cryspy_obj = self.__widg_central._cryspy_obj
        elif mode_orig == "star":
            obj = self.__widg_central._star
            if obj is not None:
                cryspy_obj = rcif_to_cryspy(obj)
        else:
            obj = self.__widg_central._cryspy_obj
            str_obj = str(obj.to_cif())
            star_obj = Global()
            star_obj.take_from_string(str_obj, f_dir=self.__f_dir_data)
            cryspy_obj = rcif_to_cryspy(star_obj)
        if cryspy_obj is None:
            cryspy_obj = GlobalConstr()
        if flag:
            self.__mode = "cryspy"
            cryspy_obj.file_input = self.__f_star_file
            self.__widg_central.form_widg_cpanel_magref(cryspy_obj)

    def to_rhochi(self):
        mode_orig = self.__mode
        flag = True
        cryspy_obj = None
        if mode_orig == "rhochi":
            cryspy_obj = self.__widg_central._cryspy_obj
        elif mode_orig == "star":
            obj = self.__widg_central._star
            if obj is not None:
                cryspy_obj = RhoChi.from_cif(str(obj))
        else:
            obj = self.__widg_central._cryspy_obj
            cryspy_obj = RhoChi.from_cif(obj.to_cif())
            if cryspy_obj is None:
                if mode_orig != "cryspy":
                    flag = False
        if cryspy_obj is None:
            cryspy_obj = RhoChi()
        if flag:
            self.__mode = "rhochi"
            cryspy_obj.file_input = self.__f_star_file
            self.__widg_central.form_widg_cpanel_magref(cryspy_obj)

        
    def to_mem(self):
        mode_orig = self.__mode
        flag = True
        cryspy_obj = None
        if mode_orig == "mem":
            cryspy_obj = self.__widg_central._cryspy_obj
        elif mode_orig == "star":
            obj = self.__widg_central._star
            if obj is not None:
                cryspy_obj = MemTensor.from_cif(str(obj))
        else:
            obj = self.__widg_central._cryspy_obj
            cryspy_obj = MemTensor.from_cif(obj.to_cif())
            if cryspy_obj is None:
                if mode_orig != "cryspy":
                    flag = False
        if cryspy_obj is None:
            cryspy_obj = MemTensor()
        if flag:
            self.__mode = "mem"
            cryspy_obj.file_input = self.__f_star_file
            self.__widg_central.form_widg_cpanel_magref(cryspy_obj)


    def to_magref(self):
        mode_orig = self.__mode
        flag = True
        cryspy_obj = None
        if mode_orig == "magref":
            cryspy_obj = self.__widg_central._cryspy_obj
        elif mode_orig == "star":
            obj = self.__widg_central._star
            if obj is not None:
                cryspy_obj = CrystRef.from_cif(str(obj))
        else:
            obj = self.__widg_central._cryspy_obj
            cryspy_obj = CrystRef.from_cif(obj.to_cif())
            if cryspy_obj is None:
                if mode_orig != "cryspy":
                    flag = False
        if cryspy_obj is None:
            cryspy_obj = CrystRef()
        if flag:
            self.__mode = "magref"
            cryspy_obj.file_input = self.__f_star_file
            self.__widg_central.form_widg_cpanel_magref(cryspy_obj)

    def init_widget(self): 
        """
module is reloaded for cwidget
        """
        self.location_on_the_screen()
        self.__widg_central = cwidget(self.info_width, self.info_height)
        self.setCentralWidget(self.__widg_central)

    def location_on_the_screen(self):
        """
        position and size of main window
        """
        screen = QtWidgets.QDesktopWidget().screenGeometry()
        self.setMinimumSize(screen.width()*1/4, screen.height()*1/4)
        self.info_width = screen.width()*8./10.
        self.info_height = screen.height()*14./16.
        self.move(screen.width()/10 , screen.height()/20)
        self.resize(screen.width()*8./10., screen.height()*14./16.)

    def save_star(self, f_name):
        star_obj = self.__widg_central._star
        with open(f_name, "w") as fid:
            fid.write(str(star_obj))
        return
        
    def save_cryspy(self, f_name):
        _obj = self.__widg_central._cryspy_obj
        ls_out = []
        ls_out.append(_obj.to_cif())
        with open(f_name, "w") as fid:
            fid.write("\n".join(ls_out))
        return

    def save_rhochi(self, f_name):
        rhochi_obj = self.__widg_central._cryspy_obj
        if rhochi_obj is None:
            return
        rhochi_obj.file_input = f_name
        rhochi_obj.save_to_file(f_name)
        return

    def save_mem(self, f_name):
        mem_obj = self.__widg_central._cryspy_obj
        if mem_obj is None:
            return
        mem_obj.file_input = f_name
        mem_obj.save_to_file(f_name)
        return

    def save_magref(self, f_name):
        magref_obj = self.__widg_central._cryspy_obj
        if magref_obj is None:
            return
        magref_obj.file_input = f_name
        magref_obj.save_to_file(f_name)
        return

    def save(self):
        f_name = self.__f_star_file
        if f_name is None:
            f_dir_data = self.__f_dir_data
            f_name = os.path.join(f_dir_data, "main.rcif")
        if self.__mode == "star":
            self.save_star(f_name)
        elif self.__mode == "cryspy":
            self.save_cryspy(f_name)
        elif self.__mode == "rhochi":
            self.save_rhochi(f_name)
        elif self.__mode == "mem":
            self.save_mem(f_name)
        elif self.__mode == "magref":
            self.save_magref(f_name)
        return

    def save_as(self):
        f_name, okPressed = QtWidgets.QFileDialog.getSaveFileName(self, 'Select a file:', self.__f_dir_data, "Rcif files (*.rcif)")
        if not(okPressed):
            return None
        self.__f_star_file = f_name
        self.__f_dir_data = os.path.dirname(f_name)
        os.chdir(os.path.dirname(f_name))
        self.save()

    def open_folder(self):
        os.startfile(self.__f_dir_data)

    def open(self):
        f_name, okPressed = QtWidgets.QFileDialog.getOpenFileName(self, 'Select a cif file:', self.__f_dir_data, "All files (*.*)")
        if not(okPressed):
            return None
        self.__widg_central._star = None
        self.__widg_central._cryspy_obj = None
        self.__f_star_file = f_name
        self.__f_dir_data = os.path.dirname(f_name)
        os.chdir(os.path.dirname(f_name))
        mode_orig = str(self.__mode)
        self.to_star()
        if mode_orig == "cryspy":
            self.to_cryspy()
        elif mode_orig == "rhochi":
            self.to_rhochi()
        elif mode_orig == "mem":
            self.to_mem()
        elif mode_orig == "magref":
            self.to_magref()

    def new_rhochi(self):
        self.__mode = "rhochi"
        f_name, okPressed = QtWidgets.QFileDialog.getSaveFileName(self, "Select a folder:", "main.rcif")
        if not okPressed:
            return
        self.__f_star_file = f_name
        self.__f_dir_data = os.path.dirname(f_name)

        i, okPressed = QtWidgets.QInputDialog.getInt(self, "Type of data","Type of experiment:\n\n 1. Single crystal\n 2. Powder 1D\n 3 .Powder 2D\n 4 .Powder 2D (one-axial texture)", 1, 1, 4, 1)
        if okPressed:
            exp_type = str(i)
            self.__widg_central._cryspy_obj = RhoChi()
        self.to_rhochi()

class cwidget(QtWidgets.QSplitter):
    def __init__(self, width, height):
        self.info_width = width
        self.info_height = height
        super(cwidget, self).__init__()
        self._star = None
        self._cryspy_obj = None
        self.init_widget()

    def init_widget(self):
        """
        make central layout
        """
        width_m_1 = self.info_width/6.
        width_m_2 = (5.*self.info_width)/6.
        width_m_3 = 0
        width_v_1 = self.info_height*0.75
        width_v_2 = self.info_height*0.25

        self.__width_cpanel = width_m_1
        self.__width_left = width_m_2

        self.lay_cpanel = QtWidgets.QVBoxLayout()
        self.lay_left = QtWidgets.QVBoxLayout()
        self.lay_right = QtWidgets.QVBoxLayout()

        w_cpanel = QtWidgets.QWidget()
        w_cpanel.setLayout(self.lay_cpanel)

        w_left = QtWidgets.QWidget()
        w_left.setLayout(self.lay_left)

        w_right = QtWidgets.QWidget()
        w_right.setLayout(self.lay_right)

        splitter_vert = QtWidgets.QSplitter()
        splitter_vert.setOrientation(QtCore.Qt.Vertical)
        splitter_vert.addWidget(w_left)
        splitter_vert.addWidget(w_right)
        splitter_vert.setSizes([width_v_1, width_v_2])
 
        self.addWidget(w_cpanel)
        self.addWidget(splitter_vert)
        self.setSizes([width_m_1, width_m_2])
        self.form_widg_right_cryspy()

    def form_widg_cpanel_star(self, star=None):
        del_layout(self.lay_cpanel)
        width_m_1 = self.__width_cpanel

        if star is None:
            star = self._star

        if star is not None:
            self._star = star

            w1 = QtWidgets.QTreeWidget()
            w1.setMinimumSize(width_m_1, width_m_1)
            sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)
            w1.setSizePolicy(sizePolicy)
            
            w1.setColumnCount(1)
            w1.setHeaderHidden(True)

            wi = QtWidgets.QTreeWidgetItem()
            s_global_name = "Unknown"
            if isinstance(star, Global):
                s_global_name = "STAR"
            wi.setText(0, f"{s_global_name:}")
            wi.cryspy_obj = star
            wi.setToolTip(0, star.__doc__)
            w1.addTopLevelItem(wi)

            if (len(star.items)+len(star.loops))>0:
                for _loop in star.loops:
                    wii = QtWidgets.QTreeWidgetItem()
                    if _loop.name != "":
                        wii.setText(0, f"loop_{_loop.name:}{_loop.prefix:}")
                    else:
                        wii.setText(0, f"loop{_loop.prefix:}")
                    wii.cryspy_obj = _loop
                    wii.setToolTip(0, _loop.__doc__)
                    wi.addChild(wii)
                for _item in star.items:
                    wii = QtWidgets.QTreeWidgetItem()
                    wii.setText(0, _item.name)
                    wii.cryspy_obj = _item
                    wii.setToolTip(0, _item.__doc__)
                    wi.addChild(wii)


            for _data in star.datas:
                wi = QtWidgets.QTreeWidgetItem()
                wi.setText(0, f"data_{_data.name}")
                wi.setToolTip(0, _data.__doc__)
                wi.cryspy_obj = _data
                for _loop in _data.loops:
                    wii = QtWidgets.QTreeWidgetItem()
                    if _loop.name != "":
                        wii.setText(0, f"loop_{_loop.name:}{_loop.prefix:}")
                    else:
                        wii.setText(0, f"loop{_loop.prefix:}")
                    wii.cryspy_obj = _loop
                    wii.setToolTip(0, _loop.__doc__)
                    wi.addChild(wii)
                for _item in _data.items:
                    wii = QtWidgets.QTreeWidgetItem()
                    wii.setText(0, _item.name)
                    wii.cryspy_obj = _item
                    wii.setToolTip(0, _item.__doc__)
                    wi.addChild(wii)

                w1.addTopLevelItem(wi)
            w1.itemClicked.connect(self.onItemClickedCryspy)
            w1.expandAll()

            self.lay_cpanel.addWidget(w1)


    @QtCore.pyqtSlot(QtWidgets.QTreeWidgetItem, int)
    def onItemClickedCryspy(self, it, col):
        self.form_widg_left_cryspy(it.cryspy_obj)
        #try:
        #    self.form_widg_left_cryspy(it.cryspy_obj)
        #except:
        #    pass



    def run_rhochi(self):
        print("Started")
        self.thread.rhochi = self._cryspy_obj
        self.thread.start()
        #self._cryspy_obj.refine()
        #self.form_widg_cpanel_magref()
        #print("Done")



    def run_mem(self):
        print("Started")
        #self.thread.mem = self._cryspy_obj
        #self.thread.start()
        
        self._cryspy_obj.maximize_entropy()
        #self.form_widg_cpanel_mem()
        print("Done")


    def form_widg_cpanel_magref(self, cryspy_obj=None):
        del_layout(self.lay_cpanel)
        width_m_1 = self.__width_cpanel
        
        if cryspy_obj is None:
            cryspy_obj = self._cryspy_obj

        if cryspy_obj is not None:

            w1 = QtWidgets.QTreeWidget()
            w1.setMinimumSize(width_m_1, width_m_1)
            sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)
            w1.setSizePolicy(sizePolicy)

            w1.setColumnCount(1)
            w1.setHeaderHidden(True)
            wi = QtWidgets.QTreeWidgetItem()
            wi.cryspy_obj = cryspy_obj
            wi.setToolTip(0, cryspy_obj.__doc__)
            s_global_name = ""
            if isinstance(cryspy_obj, CrystRef):
                s_global_name = "MagRef"
            elif isinstance(cryspy_obj, RhoChi):
                s_global_name = "RhoChi"
            elif isinstance(cryspy_obj, MemTensor):
                s_global_name = "MEM"
            elif isinstance(cryspy_obj, GlobalConstr):
                s_global_name = "Cryspy"
            wi.setText(0, f"{s_global_name:}")
            w1.addTopLevelItem(wi)

            l_data_obj = cryspy_obj.mandatory_objs+cryspy_obj.optional_objs
            
            for _data_obj in l_data_obj:
                wi = QtWidgets.QTreeWidgetItem()
                wi.cryspy_obj = _data_obj
                wi.setToolTip(0, _data_obj.__doc__)

                flag_data_const = False
                flag_no_data_obj = False
                if isinstance(_data_obj, CrystField):
                    l_attr = ["ion_type", "coefficient_stevens", "coefficient_wybourne", 
                    "point_type", "point_site", "meas_elastic", "meas_inelastic_peak", 
                    "inelastic_parameter", "inelastic_background", "refinement"]
                    l_attr_list = ["meas_inelastics", ]
                    s_name = "cryst_field"
                elif isinstance(_data_obj, Crystal):
                    l_attr = ["cell", "space_group", "atom_site", 
                    "atom_type", "atom_site_aniso", "atom_site_susceptibility", 
                    "atom_type_scat", "atom_site_scat", "atom_local_axes"]
                    s_name = "crystal"
                    l_attr_list = []
                elif isinstance(_data_obj, Diffrn):
                    l_attr = ["setup", "diffrn_radiation", "diffrn_orient_matrix", 
                    "diffrn_refln", "extinction", "phase", "refine_ls"]
                    s_name = "diffrn"
                    l_attr_list = ["refln", "refln_susceptibility"]
                elif isinstance(_data_obj, Pd):
                    l_attr = ["setup", "diffrn_radiation", "background", 
                    "resolution", "meas", "phase", "range", "chi2", "extinction",
                    "exclude", "asymmetry", "peak", "proc"]
                    s_name = "pd"
                    l_attr_list = []
                elif isinstance(_data_obj, Pd2d):
                    l_attr = ["setup", "diffrn_radiation", "background", 
                    "resolution", "meas", "phase", "range", "chi2", "extinction",
                    "exclude", "asymmetry", "proc", "texture", "refine_ls"]
                    s_name = "pd2d"
                    l_attr_list = ["refln", "refln_susceptibility", "peak"]
                elif isinstance(_data_obj, Density):
                    l_attr = ["density_points_number", ]
                    s_name = "density"
                    l_attr_list = ["density_points", ]
                elif isinstance(_data_obj, DataConstr):
                    s_name = "DataConstr"
                    l_attr = []
                    l_attr_list = []
                    flag_data_const = True
                else:
                    flag_no_data_obj = True
                    l_attr = []
                    l_attr_list = []

    
                if not(flag_no_data_obj):
                    wi.setText(0, f"{s_name:}: {_data_obj.data_name:}")

                for _attr in l_attr:
                    _val_attr = getattr(_data_obj, _attr)
                    if  _val_attr is not None:
                        wii = QtWidgets.QTreeWidgetItem()
                        wii.setText(0, f"{_attr:}")
                        wii.cryspy_obj = _val_attr
                        wii.setToolTip(0, _val_attr.__doc__)
                        wi.addChild(wii)
                        
                        if  isinstance(_val_attr, ItemConstr):
                            l_int_attr = _val_attr.INTERNAL_ATTRIBUTE 
                            for _int_attr in l_int_attr:
                                _int_obj = getattr(_val_attr, _int_attr)
                                if ((isinstance(_int_obj, ItemConstr)) | (isinstance(_int_obj, LoopConstr))):
                                    wiii = QtWidgets.QTreeWidgetItem()
                                    wiii.setText(0, f"{_int_attr:}")
                                    wiii.cryspy_obj = _int_obj
                                    wiii.setToolTip(0, _int_obj.__doc__)
                                    wii.addChild(wiii)

                for _attr in l_attr_list:
                    l_val_attr = getattr(_data_obj, _attr)
                    if  l_val_attr is not None:
                        for _val_attr in l_val_attr:
                            wii = QtWidgets.QTreeWidgetItem()
                            wii.setText(0, f"{_attr:}")
                            wii.cryspy_obj = _val_attr
                            wii.setToolTip(0, _val_attr.__doc__)
                            wi.addChild(wii)

                            if  isinstance(_val_attr, ItemConstr):
                                l_int_attr = _val_attr.INTERNAL_ATTRIBUTE 
                                for _int_attr in l_int_attr:
                                    _int_obj = getattr(_val_attr, _int_attr)
                                    if ((isinstance(_int_obj, ItemConstr)) | (isinstance(_int_obj, LoopConstr))):
                                        wiii = QtWidgets.QTreeWidgetItem()
                                        wiii.setText(0, f"{_int_attr:}")
                                        wiii.cryspy_obj = _int_obj
                                        wiii.setToolTip(0, _int_obj.__doc__)
                                        wii.addChild(wiii)


                if flag_data_const:
                    l_obj = _data_obj.optional_objs
                    for _val_attr in l_obj:
                        wii = QtWidgets.QTreeWidgetItem()
                        wii.setText(0, f"{_val_attr.__class__.__name__:}")
                        wii.cryspy_obj = _val_attr
                        wii.setToolTip(0, _val_attr.__doc__)
                        wi.addChild(wii)
                        

                if flag_no_data_obj:
                    _val_attr = _data_obj
                    wi.setText(0, f"{_val_attr.__class__.__name__:}")
                    wi.cryspy_obj = _val_attr
                    wi.setToolTip(0, _val_attr.__doc__)
                    
                    if  isinstance(_val_attr, ItemConstr):
                        l_int_attr = _val_attr.INTERNAL_ATTRIBUTE 
                        for _int_attr in l_int_attr:
                            _int_obj = getattr(_val_attr, _int_attr)
                            if ((isinstance(_int_obj, ItemConstr)) | (isinstance(_int_obj, LoopConstr))):
                                wii = QtWidgets.QTreeWidgetItem()
                                wii.setText(0, f"{_int_attr:}")
                                wii.setToolTip(_int_obj.__doc__)
                                wii.cryspy_obj = _int_obj
                                wii.setToolTip(0, _int_obj.__doc__)
                                wi.addChild(wii)

                w1.addTopLevelItem(wi)

            w1.itemClicked.connect(self.onItemClickedCryspy)
            self.lay_cpanel.addWidget(w1)

            self._cryspy_obj = cryspy_obj
            if isinstance(cryspy_obj, CrystRef):

                b_calc_magref = QtWidgets.QPushButton("Calc MagRef")
                b_calc_magref.clicked.connect(self.calc_magref)
                self.lay_cpanel.addWidget(b_calc_magref)

                b_run_magref = QtWidgets.QPushButton("Run MagRef")
                b_run_magref.clicked.connect(self.run_magref)
                self.lay_cpanel.addWidget(b_run_magref)
                sizePolicy_2 = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)
                b_run_magref.setSizePolicy(sizePolicy_2)
                b_run_magref.setMinimumWidth(width_m_1)

                b_run_gen_alg = QtWidgets.QPushButton("Run GenAlg")
                b_run_gen_alg.clicked.connect(self.run_gen_alg)
                self.lay_cpanel.addWidget(b_run_gen_alg)
                sizePolicy_3 = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)
                b_run_gen_alg.setSizePolicy(sizePolicy_3)
                b_run_gen_alg.setMinimumWidth(width_m_1)

            elif isinstance(cryspy_obj, RhoChi):

                b_calc_rhochi = QtWidgets.QPushButton("Calc RhoChi")
                b_calc_rhochi.clicked.connect(self.calc_rhochi)
                self.lay_cpanel.addWidget(b_calc_rhochi)

                b_run_rhochi = QtWidgets.QPushButton("Run RhoChi")
                b_run_rhochi.clicked.connect(self.run_rhochi)
                self.lay_cpanel.addWidget(b_run_rhochi)
                sizePolicy_2 = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)
                b_run_rhochi.setSizePolicy(sizePolicy_2)
                b_run_rhochi.setMinimumWidth(width_m_1)
            elif isinstance(cryspy_obj, MemTensor):
    
                b_run_mem = QtWidgets.QPushButton("Run MEM")
                b_run_mem.clicked.connect(self.run_mem)
                self.lay_cpanel.addWidget(b_run_mem)
                sizePolicy_2 = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)
                b_run_mem.setSizePolicy(sizePolicy_2)
                b_run_mem.setMinimumWidth(width_m_1)

            elif isinstance(cryspy_obj, GlobalConstr):
                pass
            
            w1.expandAll()


    def calc_rhochi(self):
        self._cryspy_obj.calc_chi_sq()
        self.form_widg_cpanel_magref(self._cryspy_obj)

    def calc_magref(self):
        f_dir = os.path.dirname(self._cryspy_obj.file_input)
        f_sipf = os.path.join(f_dir, "test.sipf")
        self._cryspy_obj.calc_chi_sq_n(f_sipf)
        self.form_widg_cpanel_magref(self._cryspy_obj)

    def run_magref(self):
        print("Started")
        self.thread.magref = self._cryspy_obj
        self.thread.message = "magref_simplex"
        self.thread.start()
        
        #f_dir = os.path.dirname(self._cryspy_obj.file_input)
        #f_sipf = os.path.join(f_dir, "test.sipf")
        #self._cryspy_obj.refine(f_sipf)
        #self.form_widg_cpanel_magref()
        #print("Done")

    def run_gen_alg(self):
        print("Started")
        self.thread.magref = self._cryspy_obj
        self.thread.message = "magref_gen_alg"
        self.thread.start()
        
        #f_dir = os.path.dirname(self._cryspy_obj.file_input)
        #f_sipf = os.path.join(f_dir, "test.sipf")
        #self._cryspy_obj.refine(f_sipf)
        #self.form_widg_cpanel_magref()
        #print("Done")


    def form_widg_left_cryspy(self, cryspy_object):
        #form the left widget
        del_layout(self.lay_left)
        label_out = self.label_out
        if isinstance(cryspy_object, MeasInelasticL):
            widg_out = widget_for_meas_inelasticl(cryspy_object, label_out)
        elif isinstance(cryspy_object, PdMeasL): 
            widg_out = widget_for_pd_meas(cryspy_object)
        elif isinstance(cryspy_object, PdProcL): 
            widg_out = widget_for_pd_proc(cryspy_object)
        elif isinstance(cryspy_object, Pd2dMeas): 
            widg_out = widget_for_pd2d_meas(cryspy_object)
        elif isinstance(cryspy_object, Pd2dProc): 
            widg_out = widget_for_pd2d_proc(cryspy_object)     
        elif isinstance(cryspy_object, GlobalConstr): 
            widg_out = widget_for_global_constr(cryspy_object, label_out)
        elif isinstance(cryspy_object, DataConstr): 
            widg_out = widget_for_data_constr(cryspy_object, label_out)  
        elif isinstance(cryspy_object, LoopConstr): 
            widg_out = widget_for_loop_constr(cryspy_object, label_out)  
        elif isinstance(cryspy_object, ItemConstr): 
            widg_out = widget_for_item_constr(cryspy_object, label_out)
        elif isinstance(cryspy_object, Item):
            widg_out = widget_for_item(cryspy_object)
        elif isinstance(cryspy_object, Loop): 
            widg_out = widget_for_loop(cryspy_object)
        else:
            widg_out = QtWidgets.QFrame()
            sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)
            widg_out.setSizePolicy(sizePolicy)
        self.lay_left.addWidget(widg_out)


    def form_widg_right_cryspy(self):
        del_layout(self.lay_right)
        self.label_out = QtWidgets.QLabel()
        size_pol_2 =  QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)
        self.label_out.setSizePolicy(size_pol_2)
        self.label_out.setFont(QtGui.QFont("Courier", 8, QtGui.QFont.Normal))
        self.label_out.setTextInteractionFlags(QtCore.Qt.TextSelectableByMouse)
        self.label_out.setAlignment(QtCore.Qt.AlignTop)
        self.label_out.setWordWrap(True)
    
        area = QtWidgets.QScrollArea()
        area.setWidgetResizable(True)
        area.setWidget(self.label_out)

        self.lay_right.addWidget(area)
    
def main_w(l_arg= []):
    app = QtWidgets.QApplication(l_arg)
    if len(l_arg) >= 2:
        f_dir_data = os.path.abspath(l_arg[1])
    else:
        f_dir_data = os.getcwd()
    main_wind_1 = cbuilder(f_dir_data)
    sys.exit(app.exec_())


if __name__ == '__main__':
    l_arg = sys.argv
    main_w(l_arg)
