from PyQt5 import QtWidgets

def widget_for_atom_site(atom_site):
    lay_to_fill = QtWidgets.QVBoxLayout()
    n_row, n_col = len(atom_site.label), 6
    w_t = QtWidgets.QTableWidget(n_row, n_col)
    l_name = ["label", "type_symbol", "x", "y", "z", "occupancy"]
    w_t.setHorizontalHeaderLabels(l_name)
    _i_row = 0
    for _label, _type, _x, _y, _z, _occ in zip(atom_site.label, atom_site.type_symbol, 
                                               atom_site.x, atom_site.y, atom_site.z, 
                                               atom_site.occupancy): 
        _w_ti_0 = QtWidgets.QTableWidgetItem()
        _w_ti_0.setText(_label)
        _w_ti_1 = QtWidgets.QTableWidgetItem()
        _w_ti_1.setText(_type)
        _w_ti_2 = QtWidgets.QTableWidgetItem()
        _w_ti_2.setText(_x.print_with_sigma)
        _w_ti_3 = QtWidgets.QTableWidgetItem()
        _w_ti_3.setText(_y.print_with_sigma)
        _w_ti_4 = QtWidgets.QTableWidgetItem()
        _w_ti_4.setText(_z.print_with_sigma)
        _w_ti_5 = QtWidgets.QTableWidgetItem()
        _w_ti_5.setText(_occ.print_with_sigma)
        w_t.setItem(_i_row, 0, _w_ti_0)
        w_t.setItem(_i_row, 1, _w_ti_1)
        w_t.setItem(_i_row, 2, _w_ti_2)
        w_t.setItem(_i_row, 3, _w_ti_3)
        w_t.setItem(_i_row, 4, _w_ti_4)
        w_t.setItem(_i_row, 5, _w_ti_5)
        _i_row += 1
    lay_to_fill.addWidget(w_t)

    #lay_to_fill.addStretch(1)
    widg_out = QtWidgets.QWidget()
    widg_out.setLayout(lay_to_fill)
    return widg_out

