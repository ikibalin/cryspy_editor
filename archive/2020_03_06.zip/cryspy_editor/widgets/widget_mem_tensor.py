import os
import os.path
from PyQt5 import QtWidgets, QtGui, QtCore
from .FUNCTIONS import show_info, get_layout_method_help



def widget_for_mem_tensor(obj):
    lay_to_fill = QtWidgets.QHBoxLayout()

    lay_right = QtWidgets.QVBoxLayout()
    size_pol_2 =  QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)
    label_out = QtWidgets.QLabel()
    label_out.setSizePolicy(size_pol_2)
    label_out.setFont(QtGui.QFont("Courier", 8, QtGui.QFont.Normal))
    label_out.setTextInteractionFlags(QtCore.Qt.TextSelectableByMouse)
    area = QtWidgets.QScrollArea()
    area.setWidgetResizable(True)
    area.setWidget(label_out)
    lay_right.addWidget(area)


    lay_left = QtWidgets.QVBoxLayout()

    _lay_method_help = get_layout_method_help(obj, label_out)
    lay_left.addLayout(_lay_method_help)


    _b_new_crystal = QtWidgets.QPushButton("New crystal")
    _b_new_crystal.clicked.connect(lambda : new_crystal(obj, label_out))
    lay_left.addWidget(_b_new_crystal)

    _b_add_experiment = QtWidgets.QPushButton("Add diffrn")
    _b_add_experiment.clicked.connect(lambda : add_diffrn(obj, label_out))
    lay_left.addWidget(_b_add_experiment)
    _b_del_experiment = QtWidgets.QPushButton("Delete diffrns")
    _b_del_experiment.clicked.connect(lambda : delete_diffrns(obj, label_out))
    lay_left.addWidget(_b_del_experiment)

    _b_new_density = QtWidgets.QPushButton("New density")
    _b_new_density.clicked.connect(lambda : new_density(obj, label_out))
    lay_left.addWidget(_b_new_density)

    lay_left.addStretch(1)

    _b_create_flat_density = QtWidgets.QPushButton("Create flat_density")
    _b_create_flat_density.clicked.connect(lambda : create_flat_density(obj, label_out))
    lay_left.addWidget(_b_create_flat_density)
    
    _b_renorm_susceptibility = QtWidgets.QPushButton("Renorm susceptibility")
    _b_renorm_susceptibility.clicked.connect(lambda : renorm_susceptibility(obj, label_out))
    lay_left.addWidget(_b_renorm_susceptibility)

    _b_info = QtWidgets.QPushButton("info")
    _b_info.clicked.connect(lambda : show_info(obj, label_out))
    lay_left.addWidget(_b_info)


    lay_to_fill.addLayout(lay_left)
    lay_to_fill.addLayout(lay_right)
    widg_out = QtWidgets.QWidget()
    widg_out.setLayout(lay_to_fill)

    return widg_out


def show_info(obj, label):
    label.setText(str(obj))


def new_crystal(obj, label):
    obj.delete_crystals
    crystal_class = obj.MANDATORY_CLASSES[0]
    crystal = crystal_class(data_name="phase1")
    obj.mandatory_objs.append(crystal)
    label.setText("Crystal was created")

def add_diffrn(obj, label):
    #obj.delete_densities
    diffrn_class = obj.MANDATORY_CLASSES[1]
    diffrn = diffrn_class(data_name="diffrn1")
    obj.mandatory_objs.append(diffrn)
    label.setText("Diffrn was added")

def delete_diffrns(obj, label):
    obj.delete_diffrns
    label.setText("All diffrns were deleted")

def new_density(obj, label):
    obj.delete_densities
    density_class = obj.MANDATORY_CLASSES[2]
    density = density_class(data_name="density1")
    obj.mandatory_objs.append(density)
    label.setText("Density was created")

def calc_fr_mod(obj, label):
    ls_out = []
    obj.calc_fr_mod()
    ls_out.append("Calculations done.")
    label.setText("\n".join(ls_out))
    

def calc_total_electrons(obj, label):
    ls_out = []
    ls_out.append("Total electron number for atoms in an unit cell.")
    obj.calc_total_electrons()
    for _ in obj.density.density_points:
        ls_out.append(f"{_.total_electrons:.5f} for '{_.atom_label:}'")
    label.setText("\n".join(ls_out))    

def create_flat_density(obj, label):
    ls_out = []
    obj.create_flat_density()
    ls_out.append("Density was created.")
    label.setText("\n".join(ls_out))

def renorm_susceptibility(obj, label):
    ls_out = []
    obj.renorm_susceptibility()
    ls_out.append("Susceptibility was renormed.")
    label.setText("\n".join(ls_out))



def to_file_den(obj, file_prefix, atom_label, label):
    file_name = f"{file_prefix.strip():}_{atom_label.strip():}.den"
    if obj.file_input is not None:
        _file_name = os.path.join(os.path.dirname(obj.file_input), file_name)
    else:
        _file_name = file_name
    obj.to_file_den(_file_name, atom_label=atom_label)
    ls_out = []
    ls_out.append(f"The density was saved to file '{file_name:}'.")
    label.setText("\n".join(ls_out))
