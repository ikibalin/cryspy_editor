from PyQt5 import QtWidgets, QtGui, QtCore



def widget_for_cell(cell):
    lay_to_fill = QtWidgets.QHBoxLayout()

    lay_right = QtWidgets.QVBoxLayout()
    size_pol_2 =  QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)
    label_out = QtWidgets.QLabel()
    label_out.setSizePolicy(size_pol_2)
    label_out.setFont(QtGui.QFont("Courier", 8, QtGui.QFont.Normal))
    label_out.setTextInteractionFlags(QtCore.Qt.TextSelectableByMouse)
    area = QtWidgets.QScrollArea()
    area.setWidgetResizable(True)
    area.setWidget(label_out)
    lay_right.addWidget(area)


    lay_left = QtWidgets.QVBoxLayout()

    _l_a = QtWidgets.QLabel("a:")
    _l_e_a = QtWidgets.QLineEdit(cell.a.print_with_sigma)
    _l_e_a.editingFinished.connect(lambda: cell.a.take_it(str(_l_e_a.text())))
    lay_left.addWidget(_l_a)
    lay_left.addWidget(_l_e_a)

    _l_b = QtWidgets.QLabel("b:")
    _l_e_b = QtWidgets.QLineEdit(cell.b.print_with_sigma)
    _l_e_b.editingFinished.connect(lambda: cell.b.take_it(str(_l_e_b.text())))
    lay_left.addWidget(_l_b)
    lay_left.addWidget(_l_e_b)

    _l_c = QtWidgets.QLabel("c:")
    _l_e_c = QtWidgets.QLineEdit(cell.c.print_with_sigma)
    _l_e_c.editingFinished.connect(lambda: cell.c.take_it(str(_l_e_c.text())))
    lay_left.addWidget(_l_c)
    lay_left.addWidget(_l_e_c)

    _l_alpha = QtWidgets.QLabel("alpha:")
    _l_e_alpha = QtWidgets.QLineEdit(cell.alpha.print_with_sigma)
    _l_e_alpha.editingFinished.connect(lambda: cell.alpha.take_it(str(_l_e_alpha.text())))
    lay_left.addWidget(_l_alpha)
    lay_left.addWidget(_l_e_alpha)

    _l_beta = QtWidgets.QLabel("beta:")
    _l_e_beta = QtWidgets.QLineEdit(cell.beta.print_with_sigma)
    _l_e_beta.editingFinished.connect(lambda: cell.beta.take_it(str(_l_e_beta.text())))
    lay_left.addWidget(_l_beta)
    lay_left.addWidget(_l_e_beta)

    _l_gamma = QtWidgets.QLabel("gamma:")
    _l_e_gamma = QtWidgets.QLineEdit(cell.gamma.print_with_sigma)
    _l_e_gamma.editingFinished.connect(lambda: cell.gamma.take_it(str(_l_e_gamma.text())))
    lay_left.addWidget(_l_gamma)
    lay_left.addWidget(_l_e_gamma)

    lay_left.addStretch(1)

    _b_info = QtWidgets.QPushButton("info")
    _b_info.clicked.connect(lambda : show_cell(cell, label_out))
    lay_left.addWidget(_b_info)

    lay_to_fill.addLayout(lay_left)
    lay_to_fill.addLayout(lay_right)

    widg_out = QtWidgets.QWidget()
    widg_out.setLayout(lay_to_fill)
    return widg_out

def show_cell(cell, label):
    cell.apply_constraint()
    label.setText(str(cell))
