from PyQt5 import QtWidgets, QtGui, QtCore
from .FUNCTIONS import show_info


def widget_for_coefficient_stevens(obj):
    lay_to_fill = QtWidgets.QHBoxLayout()

    lay_right = QtWidgets.QVBoxLayout()
    size_pol_2 =  QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)
    label_out = QtWidgets.QLabel()
    label_out.setSizePolicy(size_pol_2)
    label_out.setFont(QtGui.QFont("Courier", 8, QtGui.QFont.Normal))
    label_out.setTextInteractionFlags(QtCore.Qt.TextSelectableByMouse)
    area = QtWidgets.QScrollArea()
    area.setWidgetResizable(True)
    area.setWidget(label_out)
    lay_right.addWidget(area)


    lay_left = QtWidgets.QVBoxLayout()
    if obj.b00 is not None:
        _l_b00 = QtWidgets.QLabel("b00:")
        _l_e_b00 = QtWidgets.QLineEdit(obj.b00.print_with_sigma)
        _l_e_b00.editingFinished.connect(lambda: obj.b00.take_it(str(_l_e_b00.text())))
        lay_left.addWidget(_l_b00)
        lay_left.addWidget(_l_e_b00)

    if obj.b22s is not None:
        _l_b22s = QtWidgets.QLabel("b22s:")
        _l_e_b22s = QtWidgets.QLineEdit(obj.b22s.print_with_sigma)
        _l_e_b22s.editingFinished.connect(lambda: obj.b22s.take_it(str(_l_e_b22s.text())))
        lay_left.addWidget(_l_b22s)
        lay_left.addWidget(_l_e_b22s)

    if obj.b20 is not None:
        _l_b20 = QtWidgets.QLabel("b20:")
        _l_e_b20 = QtWidgets.QLineEdit(obj.b20.print_with_sigma)
        _l_e_b20.editingFinished.connect(lambda: obj.b20.take_it(str(_l_e_b20.text())))
        lay_left.addWidget(_l_b20)
        lay_left.addWidget(_l_e_b20)

    if obj.b42s is not None:
        _l_b42s = QtWidgets.QLabel("b42s:")
        _l_e_b42s = QtWidgets.QLineEdit(obj.b42s.print_with_sigma)
        _l_e_b42s.editingFinished.connect(lambda: obj.b42s.take_it(str(_l_e_b42s.text())))
        lay_left.addWidget(_l_b42s)
        lay_left.addWidget(_l_e_b42s)

    if obj.b40 is not None:
        _l_b40 = QtWidgets.QLabel("b40:")
        _l_e_b40 = QtWidgets.QLineEdit(obj.b40.print_with_sigma)
        _l_e_b40.editingFinished.connect(lambda: obj.b40.take_it(str(_l_e_b40.text())))
        lay_left.addWidget(_l_b40)
        lay_left.addWidget(_l_e_b40)

    if obj.b44 is not None:
        _l_b44 = QtWidgets.QLabel("b44:")
        _l_e_b44 = QtWidgets.QLineEdit(obj.b44.print_with_sigma)
        _l_e_b44.editingFinished.connect(lambda: obj.b44.take_it(str(_l_e_b44.text())))
        lay_left.addWidget(_l_b44)
        lay_left.addWidget(_l_e_b44)

    if obj.b66s is not None:
        _l_b66s = QtWidgets.QLabel("b66s:")
        _l_e_b66s = QtWidgets.QLineEdit(obj.b66s.print_with_sigma)
        _l_e_b66s.editingFinished.connect(lambda: obj.b66s.take_it(str(_l_e_b66s.text())))
        lay_left.addWidget(_l_b66s)
        lay_left.addWidget(_l_e_b66s)

    if obj.b62s is not None:
        _l_b62s = QtWidgets.QLabel("b62s:")
        _l_e_b62s = QtWidgets.QLineEdit(obj.b62s.print_with_sigma)
        _l_e_b62s.editingFinished.connect(lambda: obj.b62s.take_it(str(_l_e_b62s.text())))
        lay_left.addWidget(_l_b62s)
        lay_left.addWidget(_l_e_b62s)

    if obj.b60 is not None:
        _l_b60 = QtWidgets.QLabel("b60:")
        _l_e_b60 = QtWidgets.QLineEdit(obj.b60.print_with_sigma)
        _l_e_b60.editingFinished.connect(lambda: obj.b60.take_it(str(_l_e_b60.text())))
        lay_left.addWidget(_l_b60)
        lay_left.addWidget(_l_e_b60)

    if obj.b64 is not None:
        _l_b64 = QtWidgets.QLabel("b64:")
        _l_e_b64 = QtWidgets.QLineEdit(obj.b64.print_with_sigma)
        _l_e_b64.editingFinished.connect(lambda: obj.b64.take_it(str(_l_e_b64.text())))
        lay_left.addWidget(_l_b64)
        lay_left.addWidget(_l_e_b64)


    lay_left.addStretch(1)

    _b_info = QtWidgets.QPushButton("info")
    _b_info.clicked.connect(lambda : show_obj(obj, label_out))
    lay_left.addWidget(_b_info)

    lay_to_fill.addLayout(lay_left)
    lay_to_fill.addLayout(lay_right)

    widg_out = QtWidgets.QWidget()
    widg_out.setLayout(lay_to_fill)
    return widg_out
