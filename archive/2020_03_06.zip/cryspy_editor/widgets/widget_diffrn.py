import numpy

from PyQt5 import QtWidgets, QtGui, QtCore
from .FUNCTIONS import show_info, get_layout_method_help


def widget_for_diffrn(obj, label_out):
    lay_to_fill = QtWidgets.QHBoxLayout()

    lay_left = QtWidgets.QVBoxLayout()
    lay_left.addWidget(QtWidgets.QLabel("Diffrn name:"))
    _l_e_dist = QtWidgets.QLineEdit()
    _l_e_dist.setText(obj.data_name)
    _l_e_dist.editingFinished.connect(lambda : setattr(obj, "data_name", _l_e_dist.text()))
    lay_left.addWidget(_l_e_dist)

    _lay_method_help = get_layout_method_help(obj, label_out)
    lay_left.addLayout(_lay_method_help)

    #_l_b = QtWidgets.QLabel("label:")
    #_l_e_b = QtWidgets.QLineEdit(obj.data_name)
    #_l_e_b.editingFinished.connect(lambda: temp_func(str(_l_e_b.text()), "label", obj))
    #lay_left.addWidget(_l_b)
    #lay_left.addWidget(_l_e_b)


    _b_new_setup = QtWidgets.QPushButton("New setup")
    _b_new_setup.clicked.connect(lambda : new_setup(obj, label_out))
    lay_left.addWidget(_b_new_setup)

    _b_new_diffrn_radiation = QtWidgets.QPushButton("New diffrn_radiation")
    _b_new_diffrn_radiation.clicked.connect(lambda : new_diffrn_radiation(obj, label_out))
    lay_left.addWidget(_b_new_diffrn_radiation)

    _b_new_diffrn_orient_matrix = QtWidgets.QPushButton("New diffrn_orient_matrix")
    _b_new_diffrn_orient_matrix.clicked.connect(lambda : new_diffrn_orient_matrix(obj, label_out))
    lay_left.addWidget(_b_new_diffrn_orient_matrix)

    _b_new_diffrn_refln = QtWidgets.QPushButton("New diffrn_refln")
    _b_new_diffrn_refln.clicked.connect(lambda : new_diffrn_refln(obj, label_out))
    lay_left.addWidget(_b_new_diffrn_refln)

    _b_new_extinction = QtWidgets.QPushButton("New extinction")
    _b_new_extinction.clicked.connect(lambda : new_extinction(obj, label_out))
    lay_left.addWidget(_b_new_extinction)

    _b_new_phase = QtWidgets.QPushButton("New phase")
    _b_new_phase.clicked.connect(lambda : new_phase(obj, label_out))
    lay_left.addWidget(_b_new_phase)

    lay_left.addStretch(1)


    _b_info = QtWidgets.QPushButton("info")
    _b_info.clicked.connect(lambda : show_info(obj, label_out))
    lay_left.addWidget(_b_info)

    lay_to_fill.addLayout(lay_left)
    widg_out = QtWidgets.QWidget()
    widg_out.setLayout(lay_to_fill)
    return widg_out







def new_setup(obj, label):
    obj_class = obj.MANDATORY_CLASSES[0]
    obj_item = obj_class()
    obj.setup = obj_item
    label.setText("Setup was created")

def new_diffrn_radiation(obj, label):
    obj_class = obj.MANDATORY_CLASSES[1]
    obj_item = obj_class()
    obj.diffrn_radiation = obj_item
    label.setText("DiffrnRadiation was created")

def new_diffrn_orient_matrix(obj, label):
    obj_class = obj.MANDATORY_CLASSES[2]
    obj_item = obj_class()
    obj.diffrn_orient_matrix = obj_item
    label.setText("DiffrnOrientMatrix was created")

def new_diffrn_refln(obj, label):
    obj_class = obj.MANDATORY_CLASSES[3]
    obj_item = obj_class()
    obj.diffrn_refln = obj_item
    label.setText("DiffrnRefln was created")



def new_extinction(obj, label):
    obj_class = obj.OPTIONAL_CLASSES[0]
    obj_item = obj_class()
    obj.extinction = obj_item
    label.setText("Extinction was created")

def new_phase(obj, label):
    obj_class = obj.OPTIONAL_CLASSES[1]
    obj_item = obj_class()
    obj.phase = obj_item
    label.setText("Phase was created")
