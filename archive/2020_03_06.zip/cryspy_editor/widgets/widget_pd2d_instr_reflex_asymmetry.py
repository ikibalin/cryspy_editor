from PyQt5 import QtWidgets



def widget_for_pd2d_instr_reflex_asymmetry(pd2d_instr_reflex_asymmetry):
    lay_to_fill = QtWidgets.QVBoxLayout()

    _l = QtWidgets.QLabel("p1:")
    _l_e_p1 = QtWidgets.QLineEdit(pd2d_instr_reflex_asymmetry.p1.print_with_sigma)
    _l_e_p1.editingFinished.connect(lambda: pd2d_instr_reflex_asymmetry.p1.take_it(str(_l_e_p1.text())))
    lay_to_fill.addWidget(_l)
    lay_to_fill.addWidget(_l_e_p1)

    _l = QtWidgets.QLabel("p2:")
    _l_e_p2 = QtWidgets.QLineEdit(pd2d_instr_reflex_asymmetry.p2.print_with_sigma)
    _l_e_p2.editingFinished.connect(lambda: pd2d_instr_reflex_asymmetry.p2.take_it(str(_l_e_p2.text())))
    lay_to_fill.addWidget(_l)
    lay_to_fill.addWidget(_l_e_p2)

    _l = QtWidgets.QLabel("p3:")
    _l_e_p3 = QtWidgets.QLineEdit(pd2d_instr_reflex_asymmetry.p3.print_with_sigma)
    _l_e_p3.editingFinished.connect(lambda: pd2d_instr_reflex_asymmetry.p3.take_it(str(_l_e_p3.text())))
    lay_to_fill.addWidget(_l)
    lay_to_fill.addWidget(_l_e_p3)

    _l = QtWidgets.QLabel("p4:")
    _l_e_p4 = QtWidgets.QLineEdit(pd2d_instr_reflex_asymmetry.p4.print_with_sigma)
    _l_e_p4.editingFinished.connect(lambda: pd2d_instr_reflex_asymmetry.p4.take_it(str(_l_e_p4.text())))
    lay_to_fill.addWidget(_l)
    lay_to_fill.addWidget(_l_e_p4)

    lay_to_fill.addStretch(1)
    
    widg_out = QtWidgets.QWidget()
    widg_out.setLayout(lay_to_fill)
    return widg_out

