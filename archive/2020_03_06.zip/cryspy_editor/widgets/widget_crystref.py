import os
import numpy
from PyQt5 import QtWidgets, QtGui, QtCore
from .FUNCTIONS import show_info, show_variables, get_layout_method_help

def widget_for_crystref(obj, label_out):
    lay_to_fill = QtWidgets.QHBoxLayout()


    lay_left = QtWidgets.QVBoxLayout()

    _lay_method_help = get_layout_method_help(obj, label_out)
    lay_left.addLayout(_lay_method_help)

    _lay_print = QtWidgets.QHBoxLayout()
    _l = QtWidgets.QLabel("Distance:")
    _l_e_dist = QtWidgets.QLineEdit()
    _l_e_dist.setText("5.")
    _b_print = QtWidgets.QPushButton("print_point_site")
    _b_create = QtWidgets.QPushButton("create_point_site")
    _lay_print.addWidget(_l)
    _lay_print.addWidget(_l_e_dist)
    _lay_print.addWidget(_b_print)
    _lay_print.addWidget(_b_create)
    _b_print.clicked.connect(lambda : print_point_site(obj, str(_l_e_dist.text()), label_out))
    _b_create.clicked.connect(lambda : create_point_site(obj, str(_l_e_dist.text()), label_out))
    lay_left.addLayout(_lay_print)


    _b_print_levels = QtWidgets.QPushButton("print_levels")
    _b_print_levels.clicked.connect(lambda : print_levels(obj, label_out))
    lay_left.addWidget(_b_print_levels)

    _b_g_tensor = QtWidgets.QPushButton("print_g-tensor")
    _b_g_tensor.clicked.connect(lambda : print_g_tensor(obj, label_out))
    lay_left.addWidget(_b_g_tensor)

    _b_stevens = QtWidgets.QPushButton("print_Stevens")
    _b_stevens.clicked.connect(lambda : print_stevens(obj, label_out))
    lay_left.addWidget(_b_stevens)

    _b_variables = QtWidgets.QPushButton("Print variables")
    _b_variables.clicked.connect(lambda : show_variables(obj, label_out))
    lay_left.addWidget(_b_variables)

    _b_info = QtWidgets.QPushButton("info")
    _b_info.clicked.connect(lambda : show_info(obj, label_out))
    lay_left.addWidget(_b_info)


    lay_to_fill.addLayout(lay_left)
    widg_out = QtWidgets.QWidget()
    widg_out.setLayout(lay_to_fill)
    
    return widg_out

def print_point_site(obj, s_dist, label):
    point_type, point_site = obj.calc_point_type_point_site_by_crystal(distance=float(s_dist))
    _str = point_type.to_cif()+"\n\n"+point_site.to_cif()
    label.setText(_str)

def create_point_site(obj, s_dist, label):
    flag = obj.apply_point_type_point_site_by_crystal(distance=float(s_dist))
    show_info(obj, label)
    

def print_levels(obj, label):
    f_sipf = os.path.join(os.path.dirname(obj.file_input), "test.sipf")
    _str= obj.print_levels(f_sipf)
    label.setText(_str)

def print_g_tensor(obj, label):
    ls_str= [f"g-tensor is:\n"]
    cryst_field = obj.cryst_field
    if cryst_field is not None:
        g_tensor = cryst_field.get_g_tensor()
        ls_str.append(f" {g_tensor[0, 0]:7.3f}{g_tensor[0, 1]:7.3f}{g_tensor[0, 2]:7.3f}")
        ls_str.append(f" {g_tensor[1, 0]:7.3f}{g_tensor[1, 1]:7.3f}{g_tensor[1, 2]:7.3f}")
        ls_str.append(f" {g_tensor[2, 0]:7.3f}{g_tensor[2, 1]:7.3f}{g_tensor[2, 2]:7.3f}")
    label.setText("\n".join(ls_str))


def print_stevens(obj, label):
    ls_str= [f"Stevens coefficients are:\n"]
    cryst_field = obj.cryst_field
    if cryst_field is not None:
        stevens = cryst_field.calc_coefficient_stevens()
        cf_strength = stevens.get_cf_strength()
        ls_str.append(f"{stevens.to_cif():}")
        ls_str.append(f"\nCF strength interaction is {cf_strength:.5f} meV")
    label.setText("\n".join(ls_str))

