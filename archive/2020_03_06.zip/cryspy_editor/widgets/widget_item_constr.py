from .FUNCTIONS import make_qtablewidget_for_item_constr, show_info, show_help, get_layout_method_help, get_layout_internal_attribute, show_widget

import numpy
from PyQt5 import QtWidgets, QtGui, QtCore



def widget_for_item_constr(obj, label_out):
    lay_to_fill = QtWidgets.QHBoxLayout()


    lay_setting = QtWidgets.QVBoxLayout()
    lay_setting.addStretch(1)
    cb_1 = QtWidgets.QCheckBox()
    cb_1.setCheckState(2)
    lay_setting.addWidget(cb_1)
    cb_2 = QtWidgets.QCheckBox()
    cb_2.setCheckState(2)
    lay_setting.addWidget(cb_2)
    cb_3 = QtWidgets.QCheckBox()
    cb_3.setCheckState(2)
    lay_setting.addWidget(cb_3)


    lay_left = QtWidgets.QHBoxLayout()

    lay_left_1 = QtWidgets.QVBoxLayout()

    lay_left_1.addWidget(QtWidgets.QLabel("Mandatory and optional attributes"))
    w_t = make_qtablewidget_for_item_constr(obj, label=label_out)
    lay_left_1.addWidget(w_t)

    _b_info = QtWidgets.QPushButton("info")
    _b_info.clicked.connect(lambda : show_info(obj, label_out))
    lay_left_1.addWidget(_b_info)

    lay_left_2 = get_layout_internal_attribute(obj, label_out)
    
    lay_left_3 = get_layout_method_help(obj, label_out)

    wid_left_1 = QtWidgets.QWidget()
    wid_left_1.setLayout(lay_left_1)
    wid_left_2 = QtWidgets.QWidget()
    wid_left_2.setLayout(lay_left_2)
    wid_left_3 = QtWidgets.QWidget()
    wid_left_3.setLayout(lay_left_3)

    lay_left.addWidget(wid_left_1)
    lay_left.addWidget(wid_left_2)
    lay_left.addWidget(wid_left_3)

    cb_1.stateChanged.connect(lambda _1: show_widget(wid_left_1, _1))
    cb_2.stateChanged.connect(lambda _1: show_widget(wid_left_2, _1))
    cb_3.stateChanged.connect(lambda _1: show_widget(wid_left_3, _1))

    lay_left.addLayout(lay_setting)

    widg_tab_1 = QtWidgets.QWidget()
    widg_tab_1.setLayout(lay_left)


    _lay_3 = QtWidgets.QVBoxLayout()
    _text_edit = QtWidgets.QTextEdit()
    _text_edit.setText(obj.to_cif())
    _lay_3.addWidget(_text_edit)

    widg_tab_3 = QtWidgets.QWidget()
    widg_tab_3.setLayout(_lay_3)

    tab_widget = QtWidgets.QTabWidget()
    tab_widget.addTab(widg_tab_1, "Attributes")
    tab_widget.addTab(widg_tab_3, "RCIF")


    lay_to_fill.addWidget(tab_widget, 3)
    widg_out = QtWidgets.QWidget()
    widg_out.setLayout(lay_to_fill)
    return widg_out


