from PyQt5 import QtWidgets



def widget_for_pd2d_instr_resolution(pd2d_instr_resolution):
    lay_to_fill = QtWidgets.QVBoxLayout()

    _l = QtWidgets.QLabel("u:")
    _l_e_u = QtWidgets.QLineEdit(pd2d_instr_resolution.u.print_with_sigma)
    _l_e_u.editingFinished.connect(lambda: pd2d_instr_resolution.u.take_it(str(_l_e_u.text())))
    lay_to_fill.addWidget(_l)
    lay_to_fill.addWidget(_l_e_u)

    _l = QtWidgets.QLabel("v:")
    _l_e_v = QtWidgets.QLineEdit(pd2d_instr_resolution.v.print_with_sigma)
    _l_e_v.editingFinished.connect(lambda: pd2d_instr_resolution.v.take_it(str(_l_e_v.text())))
    lay_to_fill.addWidget(_l)
    lay_to_fill.addWidget(_l_e_v)

    _l = QtWidgets.QLabel("w:")
    _l_e_w = QtWidgets.QLineEdit(pd2d_instr_resolution.w.print_with_sigma)
    _l_e_w.editingFinished.connect(lambda: pd2d_instr_resolution.w.take_it(str(_l_e_w.text())))
    lay_to_fill.addWidget(_l)
    lay_to_fill.addWidget(_l_e_w)

    _l = QtWidgets.QLabel("x:")
    _l_e_x = QtWidgets.QLineEdit(pd2d_instr_resolution.x.print_with_sigma)
    _l_e_x.editingFinished.connect(lambda: pd2d_instr_resolution.x.take_it(str(_l_e_x.text())))
    lay_to_fill.addWidget(_l)
    lay_to_fill.addWidget(_l_e_x)

    _l = QtWidgets.QLabel("y:")
    _l_e_y = QtWidgets.QLineEdit(pd2d_instr_resolution.y.print_with_sigma)
    _l_e_y.editingFinished.connect(lambda: pd2d_instr_resolution.y.take_it(str(_l_e_y.text())))
    lay_to_fill.addWidget(_l)
    lay_to_fill.addWidget(_l_e_y)

    lay_to_fill.addStretch(1)
    
    widg_out = QtWidgets.QWidget()
    widg_out.setLayout(lay_to_fill)
    return widg_out

