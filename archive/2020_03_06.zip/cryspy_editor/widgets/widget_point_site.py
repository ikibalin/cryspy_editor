import numpy
from PyQt5 import QtWidgets, QtGui, QtCore
from .FUNCTIONS import show_info

def temp_func(qt_table, i_row, i_col, obj):
    table_item = qt_table.item(i_row, i_col)
    val = str(table_item.text())
    if i_col == 0:
        obj.item[i_row].label = val
    elif i_col == 1:
        obj.item[i_row].type_symbol = val
    elif i_col == 2:
        obj.item[i_row].position_x = val
    elif i_col == 3:
        obj.item[i_row].position_y = val
    elif i_col == 4:
        obj.item[i_row].position_z = val
    return


def widget_for_point_site(obj):
    lay_to_fill = QtWidgets.QHBoxLayout()

    lay_right = QtWidgets.QVBoxLayout()
    size_pol_2 =  QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)
    label_out = QtWidgets.QLabel()
    label_out.setSizePolicy(size_pol_2)
    label_out.setFont(QtGui.QFont("Courier", 8, QtGui.QFont.Normal))
    label_out.setTextInteractionFlags(QtCore.Qt.TextSelectableByMouse)
    area = QtWidgets.QScrollArea()
    area.setWidgetResizable(True)
    area.setWidget(label_out)
    lay_right.addWidget(area)
    
    lay_left = QtWidgets.QVBoxLayout()

    n_row, n_col = len(obj.label), 5
    w_t = QtWidgets.QTableWidget(n_row, n_col)
    l_name = ["label", "type_symbol", "position_x", "position_y", "position_z"]
    w_t.setHorizontalHeaderLabels(l_name)
    _i_row = 0
    for _item in obj.item: 
        _1, _2 = _item.label, _item.type_symbol
        _3, _4, _5 = _item.position_x, _item.position_y, _item.position_z
        _w_ti_0 = QtWidgets.QTableWidgetItem()
        _w_ti_0.setText(str(_1))
        _w_ti_1 = QtWidgets.QTableWidgetItem()
        _w_ti_1.setText(str(_2))
        _w_ti_2 = QtWidgets.QTableWidgetItem()
        _w_ti_2.setText(str(_3))
        _w_ti_3 = QtWidgets.QTableWidgetItem()
        _w_ti_3.setText(str(_4))
        _w_ti_4 = QtWidgets.QTableWidgetItem()
        _w_ti_4.setText(str(_5))
        w_t.setItem(_i_row, 0, _w_ti_0)
        w_t.setItem(_i_row, 1, _w_ti_1)
        w_t.setItem(_i_row, 2, _w_ti_2)
        w_t.setItem(_i_row, 3, _w_ti_3)
        w_t.setItem(_i_row, 4, _w_ti_4)
        _i_row += 1
    w_t.cellChanged.connect(lambda _1, _2: temp_func(w_t, _1, _2, obj))


    lay_left.addWidget(w_t)

    _b_info = QtWidgets.QPushButton("info")
    _b_info.clicked.connect(lambda : show_info(obj, label_out))
    lay_left.addWidget(_b_info)

    lay_to_fill.addLayout(lay_left)
    lay_to_fill.addLayout(lay_right)

    widg_out = QtWidgets.QWidget()
    widg_out.obj = obj
    widg_out.setLayout(lay_to_fill)
    return widg_out
