import numpy

from PyQt5 import QtWidgets, QtGui, QtCore
from .FUNCTIONS import show_info, get_layout_method_help


def widget_for_density(obj):
    lay_to_fill = QtWidgets.QHBoxLayout()

    lay_right = QtWidgets.QVBoxLayout()
    size_pol_2 =  QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)
    label_out = QtWidgets.QLabel()
    label_out.setSizePolicy(size_pol_2)
    label_out.setFont(QtGui.QFont("Courier", 8, QtGui.QFont.Normal))
    label_out.setTextInteractionFlags(QtCore.Qt.TextSelectableByMouse)
    area = QtWidgets.QScrollArea()
    area.setWidgetResizable(True)
    area.setWidget(label_out)
    lay_right.addWidget(area)



    lay_left = QtWidgets.QVBoxLayout()


    _lay_method_help = get_layout_method_help(obj, label_out)
    lay_left.addLayout(_lay_method_help)


    #_l_b = QtWidgets.QLabel("label:")
    #_l_e_b = QtWidgets.QLineEdit(obj.data_name)
    #_l_e_b.editingFinished.connect(lambda: temp_func(str(_l_e_b.text()), "label", obj))
    #lay_left.addWidget(_l_b)
    #lay_left.addWidget(_l_e_b)


    _b_new_density_points_number = QtWidgets.QPushButton("New density_points_number")
    _b_new_density_points_number.clicked.connect(lambda : new_density_points_number(obj, label_out))
    lay_left.addWidget(_b_new_density_points_number)

    _b_new_density_point = QtWidgets.QPushButton("New density_point")
    _b_new_density_point.clicked.connect(lambda : new_density_point(obj, label_out))
    lay_left.addWidget(_b_new_density_point)

    lay_left.addStretch(1)


    _b_info = QtWidgets.QPushButton("info")
    _b_info.clicked.connect(lambda : show_info(obj, label_out))
    lay_left.addWidget(_b_info)

    lay_to_fill.addLayout(lay_left)
    lay_to_fill.addLayout(lay_right)
    widg_out = QtWidgets.QWidget()
    widg_out.setLayout(lay_to_fill)
    return widg_out







def new_density_points_number(obj, label):
    obj_class = obj.MANDATORY_CLASSES[0]
    obj_item = obj_class()
    obj.density_points_number = obj_item
    label.setText("DensityPointsNumber was created")



def new_density_point(obj, label):
    obj_class = obj.OPTIONAL_CLASSES[0]
    obj_item = obj_class()
    obj.optional_objs.append(obj_item)
    label.setText("DensityPoint was created")

