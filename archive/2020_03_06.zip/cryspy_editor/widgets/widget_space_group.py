from PyQt5 import QtWidgets, QtGui, QtCore
from .FUNCTIONS import make_qtablewidget_for_item_constr, show_info, show_variables, show_help, get_layout_method_help, get_layout_internal_attribute


def widget_for_space_group(obj):
    lay_to_fill = QtWidgets.QHBoxLayout()

    lay_right = QtWidgets.QVBoxLayout()
    size_pol_2 =  QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)
    label_out = QtWidgets.QLabel()
    label_out.setSizePolicy(size_pol_2)
    label_out.setFont(QtGui.QFont("Courier", 8, QtGui.QFont.Normal))
    label_out.setTextInteractionFlags(QtCore.Qt.TextSelectableByMouse)
    area = QtWidgets.QScrollArea()
    area.setWidgetResizable(True)
    area.setWidget(label_out)
    lay_right.addWidget(area)
    

    lay_left = QtWidgets.QVBoxLayout()


    lay_left_1 = QtWidgets.QHBoxLayout()

    w_t = make_qtablewidget_for_item_constr(obj)
    lay_left_1.addWidget(w_t)
    lay_left_12 = get_layout_internal_attribute(obj, label_out)
    _lay_method_help = get_layout_method_help(obj, label_out)
    lay_left_12.addLayout(_lay_method_help)
    lay_left_1.addLayout(lay_left_12)
    lay_left.addLayout(lay_left_1)

    _b_el_s = QtWidgets.QPushButton("Elements of symmetry")
    _b_el_s.clicked.connect(lambda : show_el_symm(obj, label_out))
    lay_left.addWidget(_b_el_s)

    _b_el_an = QtWidgets.QPushButton("Accessible names")
    _b_el_an.clicked.connect(lambda : show_names(obj, label_out))
    lay_left.addWidget(_b_el_an)



    _lay_atoms = QtWidgets.QHBoxLayout()
    _l = QtWidgets.QLabel("For x y z:")
    _l_e_atoms = QtWidgets.QLineEdit()
    _l_e_atoms.setText("0. 0. 0.")
    _b_atoms = QtWidgets.QPushButton("generate atoms")
    _b_symop = QtWidgets.QPushButton("generate symop")
    _lay_atoms.addWidget(_l)
    _lay_atoms.addWidget(_l_e_atoms)
    _lay_atoms.addWidget(_b_atoms)
    _lay_atoms.addWidget(_b_symop)

    _b_atoms.clicked.connect(lambda : show_atoms(obj, str(_l_e_atoms.text()), label_out))
    _b_symop.clicked.connect(lambda : show_symop_for_xyz(obj, str(_l_e_atoms.text()), label_out))

    lay_left.addLayout(_lay_atoms)




    _b_variables = QtWidgets.QPushButton("Print variables")
    _b_variables.clicked.connect(lambda : show_variables(obj, label_out))
    lay_left.addWidget(_b_variables)

    _b_info = QtWidgets.QPushButton("info")
    _b_info.clicked.connect(lambda : show_info(obj, label_out))
    lay_left.addWidget(_b_info)

    lay_to_fill.addLayout(lay_left)
    lay_to_fill.addLayout(lay_right)
    widg_out = QtWidgets.QWidget()
    widg_out.setLayout(lay_to_fill)
    



    show_help(obj, label_out)
    return widg_out


def show_el_symm(obj, label):
    s_out = str(obj.reduced_space_group_symop)
    label.setText(s_out)

def show_names(obj, label):
    ls_out = obj.ACCESIBLE_NAME_HM_ALT 
    ls_out_print = []
    n_val = 10
    for _i, _  in enumerate(ls_out):
        if _i%n_val ==0:
            ls_out_print.append("\n")
        if _i%(5*n_val) ==0:
            ls_out_print.append("\n")
        _sval = _.strip().ljust(14, " ")
        ls_out_print.append(f"{_sval:14}")
    label.setText("Accessible names:" + "".join(ls_out_print)[:-2])


def show_choices(obj, val, label):
    ls_out = obj.choices(val)
    label.setText(f"List of accessible choices for {val:} is\n\n" + ", ".join(ls_out))

def show_atoms(obj, val, label):
    sval = val.replace(",", " ").strip()
    [x,y,z]=[float(_) for _ in sval.split()[:3]]
    np_x, np_y, np_z, mult = obj.calc_xyz_mult(x,y,z)
    ls_out = [f"For atom ({x:.5f}, {y:.5f}, {z:.5f})"]
    ls_out.append(f" number of atoms in unit cell is {np_x.size:}")
    ls_out.append(f" multiplicity is {mult:}")
    ls_out.append("List of atoms in unit cell:")
    ls_out.extend([f" {_1:8.5f} {_2:8.5f} {_3:8.5f}" for _1, _2, _3 in zip(np_x, np_y, np_z)])
    label.setText("\n".join(ls_out))


def show_symop_for_xyz(obj, val, label):
    sval = val.replace(",", " ").strip()
    [x,y,z]=[float(_) for _ in sval.split()[:3]]
    symop = obj.calc_symop_for_xyz(x, y, z)
    ls_out = [f"For atom ({x:.5f}, {y:.5f}, {z:.5f})"]
    ls_out.append(f" elements of symmetry is \n{symop.to_cif():}")
    label.setText("\n".join(ls_out))
