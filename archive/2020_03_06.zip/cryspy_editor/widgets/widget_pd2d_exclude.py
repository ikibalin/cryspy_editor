import numpy
from PyQt5 import QtWidgets

def temp_func(qt_table, i_row, i_col, pd2d_exclude):
    table_item = qt_table.item(i_row, i_col)
    val = str(table_item.text())
    if i_col == 0:
        pd2d_exclude.ttheta_min[i_row] = val
    elif i_col == 1:
        pd2d_exclude.ttheta_max[i_row] = val
    elif i_col == 2:
        pd2d_exclude.phi_min[i_row] = val
    elif i_col == 3:
        pd2d_exclude.phi_max[i_row] = val
    return


def widget_for_pd2d_exclude(pd2d_exclude):
    
    widg_out = QtWidgets.QWidget()
    widg_out.pd2d_exclude = pd2d_exclude
    lay_to_fill = QtWidgets.QVBoxLayout()

    n_row, n_col = len(pd2d_exclude.ttheta_min), 4
    w_t = QtWidgets.QTableWidget(n_row, n_col)
    l_name = ["ttheta_min", "ttheta_max", "phi_min", "phi_max"]
    w_t.setHorizontalHeaderLabels(l_name)
    _i_row = 0
    for _tth_min, _tth_max, _phi_min, _phi_max in zip( pd2d_exclude.ttheta_min, 
                  pd2d_exclude.ttheta_max, pd2d_exclude.phi_min, pd2d_exclude.phi_max): 
        _w_ti_0 = QtWidgets.QTableWidgetItem()
        _w_ti_0.setText(str(_tth_min))
        _w_ti_1 = QtWidgets.QTableWidgetItem()
        _w_ti_1.setText(str(_tth_max))
        _w_ti_2 = QtWidgets.QTableWidgetItem()
        _w_ti_2.setText(str(_phi_min))
        _w_ti_3 = QtWidgets.QTableWidgetItem()
        _w_ti_3.setText(str(_phi_max))
        w_t.setItem(_i_row, 0, _w_ti_0)
        w_t.setItem(_i_row, 1, _w_ti_1)
        w_t.setItem(_i_row, 2, _w_ti_2)
        w_t.setItem(_i_row, 3, _w_ti_3)
        _i_row += 1
    w_t.cellChanged.connect(lambda _1, _2: temp_func(w_t, _1, _2, pd2d_exclude))

    lay_to_fill.addWidget(w_t)
    widg_out.setLayout(lay_to_fill)
    return widg_out
