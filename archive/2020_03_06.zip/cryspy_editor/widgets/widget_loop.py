from PyQt5 import QtWidgets, QtGui, QtCore



def widget_for_loop(loop):
    lay_to_fill = QtWidgets.QHBoxLayout()

    lay_right = QtWidgets.QVBoxLayout()
    size_pol_2 =  QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)
    label_out = QtWidgets.QLabel()
    label_out.setSizePolicy(size_pol_2)
    label_out.setFont(QtGui.QFont("Courier", 8, QtGui.QFont.Normal))
    label_out.setTextInteractionFlags(QtCore.Qt.TextSelectableByMouse)
    area = QtWidgets.QScrollArea()
    area.setWidgetResizable(True)
    area.setWidget(label_out)
    lay_right.addWidget(area)

    lay_left = QtWidgets.QVBoxLayout()


    l_name_long = loop.names
    prefix = loop.prefix
    l_name = [_[len(prefix):] for _ in l_name_long]
    ll_val = loop.table
    n_row, n_col = len(ll_val), len(ll_val[0])
    table = QtWidgets.QTableWidget(n_row, n_col)
    for _il_val, l_val in enumerate(ll_val):
        for _i_val, _val in enumerate(l_val):
            _t_i = QtWidgets.QTableWidgetItem()
            _t_i.setText(_val)
            table.setItem(_il_val, _i_val, _t_i)
    table.setHorizontalHeaderLabels(l_name)        
    lay_left.addWidget(table)
    
    lay_to_fill.addLayout(lay_left)
    lay_to_fill.addLayout(lay_right)

    widg_out = QtWidgets.QWidget()
    widg_out.setLayout(lay_to_fill)
    return widg_out

