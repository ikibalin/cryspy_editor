# -*- coding: utf-8 -*-
__author__ = 'ikibalin'
__version__ = "2020_03_05"

import os
import os.path
import sys
import json
import numpy
import pickle
import copy
import pyqtgraph as pg
import pyqtgraph.console as pg_c
import pyqtgraph.dockarea as pg_da
from typing import Callable, Union, Callable, Any, List, NoReturn
from PyQt5 import QtCore, QtGui, QtWidgets
from cryspy_editor.b_rcif_to_cryspy import rcif_to_cryspy, L_FUNCTION_ALL, L_GLOBAL_CLASS
from cryspy_editor.widgets.FUNCTIONS import show_widget
from cryspy_editor.widgets.w_data_constr import w_for_data_constr
from cryspy_editor.widgets.w_global_constr import w_for_global_constr
from cryspy_editor.widgets.w_item_constr import w_for_item_constr
from cryspy_editor.widgets.w_loop_constr import w_for_loop_constr
from cryspy_editor.widgets.w_meas_inelasticl import w_for_meas_inelasticl
from cryspy_editor.widgets.w_pd2d_meas import w_for_pd2d_meas
from cryspy_editor.widgets.w_pd2d_proc import w_for_pd2d_proc
from pycifstar import Data, Global, Item, Items, Loop, to_global
from cryspy_editor.widgets.w_function import w_for_function, WFunction
from cryspy_editor.widgets.w_for_string import w_for_string
from cryspy_editor.widgets.w_cpanel import CPanel, find_tree_item_position
from cryspy_editor.widgets.w_item import w_for_item
from cryspy_editor.widgets.w_loop import w_for_loop
from cryspy_editor.widgets.w_presentation import w_for_presentation
from cryspy_editor.widgets.w_graph import CGraph

try:
    FLAG_CRYSPY = True
    from cryspy import RhoChi
    from cryspy_editor.widgets.FUNCTIONS import del_layout
    from cryspy.common.cl_global_constr import GlobalConstr
    from cryspy.common.cl_global_constr import DataConstr
    from cryspy.common.cl_loop_constr import LoopConstr
    from cryspy.common.cl_item_constr import ItemConstr
    from cryspy.cif_like.cl_pd import Pd
    from cryspy.cif_like.cl_pd2d import Pd2d
    from cryspy.cif_like.cl_diffrn import Diffrn
    from cryspy.cif_like.cl_diffrn_refln import DiffrnReflnL 
    from cryspy.pd1dcif_like.cl_pd_peak import PdPeakL
    from cryspy.pd1dcif_like.cl_pd_meas import PdMeasL
    from cryspy.pd1dcif_like.cl_pd_proc import PdProcL
    from cryspy.pd2dcif_like.cl_pd2d_meas import Pd2dMeas
    from cryspy.pd2dcif_like.cl_pd2d_proc import Pd2dProc
except ImportError:
    FLAG_CRYSPY = False

FLAG_MAGREF = False
FLAG_MEM = False
#try:
#    FLAG_MEM = True
#    from lib_mem.mem.cl_density import Density
#    from lib_mem.scripts.cl_mem_tensor import MemTensor
#except ImportError:
#    FLAG_MEM = False

class MyThread(QtCore.QThread):
    signal_start = QtCore.pyqtSignal()
    signal_end = QtCore.pyqtSignal()
    signal_refresh = QtCore.pyqtSignal()
    signal_take_attributes = QtCore.pyqtSignal()

    def __init__(self, parent=None):
        QtCore.QThread.__init__(self, parent)
        self.message = None
        self.function = None
        self.arguments = None
        self.output = None

    def run(self):
        l_message = []
        self.signal_start.emit()
        w_cpanel = self.w_cpanel

        func = self.function
        arg = self.arguments

        if isinstance(w_cpanel, QtWidgets.QTreeWidget):
            arg_new = []
            for _arg in arg:
                flag_arg = False
                if isinstance(_arg, str):
                    l_arg = _arg.split(",")
                    s_0 = l_arg[0]
                    level_item_count = w_cpanel.topLevelItemCount()
                    for _i in range(level_item_count):
                        qtree_widget_item = w_cpanel.topLevelItem(_i)
                        s_item = str(qtree_widget_item.text(0))
                        if (s_item.lower() == s_0.lower()):
                            arg_new.append(qtree_widget_item._object)
                            flag_arg = True
                            break
                if not flag_arg:
                    arg_new.append(_arg)
        else:
            arg_new = arg

        out = func(*arg_new)
        #try:
        #    out = func(*arg_new)
        #except SyntaxError:
        #    out = "Check the syntax of function"
        #except ArithmeticError:
        #    out = "Arithmetic error"
        #except ValueError:
        #    out = "Error in the input values raised"
        #except Exception:
        #    out = "An unspecified error occurred while executing the function"
        self.output = out    
        self.signal_end.emit()


class CBuilder(QtWidgets.QMainWindow):
    def __init__(self, f_dir_data=os.path.dirname(__file__)):
        super(CBuilder, self).__init__()

        self.__f_dir_prog = os.path.dirname(__file__)
        self.__f_dir_data = f_dir_data
        self.__f_file = None
        if os.path.isfile(f_dir_data):
            self.__f_file = f_dir_data
            self.__f_dir_data = os.path.dirname(f_dir_data)
        self.__mode = "star"
        self.graph = CGraph(self)

        self.def_actions()
        self.init_widget()
        self.setWindowTitle(f'CrysPy editor')

        if self.__f_file is not None:
            self.setWindowTitle(f'CrysPy editor: {self.__f_file:}')
            self.to_star()
        self.show()

    def def_actions(self):
        f_dir_prog = self.__f_dir_prog
        f_dir_prog_icon = os.path.join(f_dir_prog, 'f_icon')
        self.setWindowIcon(QtGui.QIcon(
            os.path.join(f_dir_prog_icon, 'icon.png')))

        menubar = self.menuBar()
        fileMenu = menubar.addMenu('&File')
        self.toolbar = self.addToolBar("Open")

        open_action = QtWidgets.QAction(QtGui.QIcon(
            os.path.join(f_dir_prog_icon, 'open.png')), '&Open', self)
        open_action.setShortcut('Ctrl+O')
        open_action.setStatusTip('Open file')
        open_action.triggered.connect(self.open)

        fileMenu.addAction(open_action)
        self.toolbar.addAction(open_action)

        to_star_action = QtWidgets.QAction(QtGui.QIcon(os.path.join(f_dir_prog_icon, 'to_star.png')), 'S&TAR mode',
                                           self)
        to_star_action.setStatusTip('Switch on STAR mode')
        to_star_action.triggered.connect(self.to_star)

        fileMenu.addAction(to_star_action)
        self.toolbar.addAction(to_star_action)

        if FLAG_CRYSPY:
            to_cryspy_action = QtWidgets.QAction(QtGui.QIcon(os.path.join(f_dir_prog_icon, 'to_cryspy.png')),
                                                 '&CrysPy mode', self)
            to_cryspy_action.setStatusTip('Switch on CrysPy mode')
            to_cryspy_action.triggered.connect(self.to_cryspy)

            fileMenu.addAction(to_cryspy_action)
            self.toolbar.addAction(to_cryspy_action)

        for _global_cls in L_GLOBAL_CLASS:
            s_name = _global_cls.__name__
            f_icon = _global_cls.F_ICON
            if f_icon is None:
                to_global_constr_action = QtWidgets.QAction(QtGui.QIcon(os.path.join(f_dir_prog_icon, 'to_magref.png')),
                                                 f'{s_name:}', self)
            else:
                to_global_constr_action = QtWidgets.QAction(QtGui.QIcon(f_icon),
                                                 f'{s_name:} mode', self)

            to_global_constr_action.setStatusTip(f'Switch on {s_name:}')
            to_global_constr_action.triggered.connect(self.to_global_constr)
            to_global_constr_action.attached_class = _global_cls

            fileMenu.addAction(to_global_constr_action)
            self.toolbar.addAction(to_global_constr_action)

        save_action = QtWidgets.QAction(QtGui.QIcon(
            os.path.join(f_dir_prog_icon, 'save.png')), '&Save', self)
        save_action.setShortcut('Ctrl+S')
        save_action.setStatusTip('Save')
        save_action.triggered.connect(self.save)

        fileMenu.addAction(save_action)
        self.toolbar.addAction(save_action)

        save_as_action = QtWidgets.QAction(QtGui.QIcon(os.path.join(f_dir_prog_icon, 'save_as.png')), 'Save &as...',
                                           self)
        save_as_action.setStatusTip('Save as ...')
        save_as_action.triggered.connect(self.save_as)

        fileMenu.addAction(save_as_action)
        self.toolbar.addAction(save_as_action)

        show_graph = QtWidgets.QAction(QtGui.QIcon(os.path.join(f_dir_prog_icon, 'graph.png')), 'Show graph',
                                           self)
        show_graph.setStatusTip('Show graph')
        show_graph.triggered.connect(self.graph.show)

        self.toolbar.addAction(show_graph)


        #save_session_as = QtWidgets.QAction(QtGui.QIcon(
        #    os.path.join(f_dir_prog_icon, 'save.png')), 'Save session as ...', self)
        #save_session_as.setStatusTip('Save session as..')
        #save_session_as.triggered.connect(self.save_session_as)
        #fileMenu.addAction(save_session_as)
        #self.toolbar.addAction(save_session_as)
        #load_session = QtWidgets.QAction(QtGui.QIcon(
        #    os.path.join(f_dir_prog_icon, 'save.png')), 'Load session', self)
        #load_session.setStatusTip('Save session as..')
        #load_session.triggered.connect(self.load_session)
        #fileMenu.addAction(load_session)
        #self.toolbar.addAction(load_session)

        open_folder = QtWidgets.QAction(QtGui.QIcon(os.path.join(f_dir_prog_icon, 'open_folder.png')), 'Open folder',
                                        self)
        open_folder.setStatusTip('Open folder')
        open_folder.triggered.connect(self.open_folder)

        self.toolbar.addAction(open_folder)

        self.statusBar()

    def init_widget(self) -> NoReturn:
        self.location_on_the_screen()
        self.w_function = WFunction()
        self.__widg_central = CWidget(self.info_width, self.info_height, self.w_function)

        layout_central = QtWidgets.QVBoxLayout()
        layout_central.addWidget(self.w_function)
        layout_central.addWidget(self.__widg_central)

        central_widget = QtWidgets.QWidget()
        central_widget.setLayout(layout_central)
        self.setCentralWidget(central_widget)
        
    def location_on_the_screen(self) -> NoReturn:
        screen = QtWidgets.QDesktopWidget().screenGeometry()
        self.setMinimumSize(screen.width() * 1 / 4, screen.height() * 1 / 4)
        self.info_width = screen.width() * 8. / 10.
        self.info_height = screen.height() * 14. / 16.
        self.move(screen.width() / 10, screen.height() / 20)
        self.resize(screen.width() * 8. / 10., screen.height() * 14. / 16.)

    def calc_is_finished(self) -> NoReturn:
        m_box = QtWidgets.QMessageBox()
        m_box.setIcon(QtWidgets.QMessageBox.Information)
        m_box.setText("Calculations are finished")
        m_box.setWindowTitle("Message")
        m_box.setStandardButtons(
            QtWidgets.QMessageBox.Ok | QtWidgets.QMessageBox.Cancel)
        m_box.exec()
        if self.__mode == "rhochi":
            self.to_rhochi()
        elif self.__mode == "mem":
            self.to_mem()
        elif self.__mode == "magref":
            self.to_magref()

    def to_star(self) -> NoReturn:
        if self.__widg_central._star is not None:
            star_ = self.__widg_central._star
        elif self.__f_file is not None:
            star_ = to_global(self.__f_file)
        else:
            f_file_data_new, okPressed = QtWidgets.QFileDialog.getOpenFileName(self, 'Select a cif file:',
                                                                               self.__f_dir_data, "All files (*.*)")
            if not (okPressed):
                return None
            star_ = to_global(f_file_data_new)
            self.__f_file = f_file_data_new
            self.__f_dir_data = os.path.dirname(f_file_data_new)
        self.__mode = "star"
        self.__widg_central.replace_object_global(star_)

    def to_cryspy(self) -> NoReturn:
        mode_orig = self.__mode
        flag = True
        cryspy_obj = None
        str_obj = None
        if mode_orig == "cryspy":
            cryspy_obj = self.__widg_central._object
        elif mode_orig == "star":
            obj = self.__widg_central._star
            if obj is not None:
                cryspy_obj = rcif_to_cryspy(obj)
        else:
            obj = self.__widg_central._object
            str_obj = str(obj.to_cif())
            star_obj = Global()
            star_obj.take_from_string(str_obj, f_dir=self.__f_dir_data)
            cryspy_obj = rcif_to_cryspy(star_obj)
        if cryspy_obj is None:
            cryspy_obj = GlobalConstr()
        if flag:
            self.__mode = "cryspy"
            cryspy_obj.file_input = self.__f_file
            self.__widg_central.replace_object_global(cryspy_obj)



    def to_global_constr(self) -> NoReturn:
        sender = self.sender()
        attached_class = sender.attached_class 

        mode_orig = self.__mode
        flag = True
        cryspy_obj = None
        if mode_orig == "star":
            obj = self.__widg_central._star
            if obj is not None:
                cryspy_obj = attached_class.from_cif(str(obj))
        else:
            obj = self.__widg_central._object
            cryspy_obj = attached_class.from_cif(obj.to_cif())
            if cryspy_obj is None:
                if mode_orig != "cryspy":
                    flag = False
        if cryspy_obj is None:
            cryspy_obj = attached_class()
        if flag:
            self.__mode = "global_constr"
            cryspy_obj.file_input = self.__f_file
            self.__widg_central.replace_object_global(cryspy_obj)

    def save(self) -> NoReturn:
        f_name = self.__f_file
        if f_name is None:
            f_dir_data = self.__f_dir_data
            f_name = os.path.join(f_dir_data, "main.rcif")
        if self.__mode == "star":
            star_obj = self.__widg_central._star
            with open(f_name, "w") as fid:
                fid.write(str(star_obj))
        elif self.__mode in ["cryspy", "global_constr"]:
            cryspy_obj = self.__widg_central._object
            if cryspy_obj is None:
                return
            cryspy_obj.file_input = f_name
            if self.__mode == "cryspy":
                with open(f_name, "w") as fid:
                    fid.write(cryspy_obj.to_cif())
            else:
                cryspy_obj.save_to_file(f_name)

    def save_as(self) -> NoReturn:
        f_name, okPressed = QtWidgets.QFileDialog.getSaveFileName(self, 'Select a file:', self.__f_dir_data,
                                                                  "Rcif files (*.rcif)")
        if not (okPressed):
            return None
        self.__f_file = f_name
        self.setWindowTitle(f'CrysPy editor: {f_name:}')
        
        self.__f_dir_data = os.path.dirname(f_name)
        os.chdir(os.path.dirname(f_name))
        self.save()

    def save_session_as(self) -> NoReturn:
        f_name, okPressed = QtWidgets.QFileDialog.getSaveFileName(self, 'Select a file:', self.__f_dir_data,
                                                                  "Pickle files (*.pkl)")
        if not (okPressed):
            return None

        with open(f_name, 'wb') as fid:
            f_name = self.__f_file
            pickle.dump(f_name, fid, pickle.HIGHEST_PROTOCOL)

            f_dir = self.__f_dir_data
            pickle.dump(f_dir, fid, pickle.HIGHEST_PROTOCOL)

            mode_orig = str(self.__mode)
            pickle.dump(mode_orig, fid, pickle.HIGHEST_PROTOCOL)

            star_obj = self.__widg_central._star
            pickle.dump(star_obj, fid, pickle.HIGHEST_PROTOCOL)

            cryspy_obj = self.__widg_central._object
            pickle.dump(cryspy_obj, fid, pickle.HIGHEST_PROTOCOL)

            glob_const_obj = self.__widg_central._objects
            pickle.dump(glob_const_obj, fid, pickle.HIGHEST_PROTOCOL)

    def load_session(self) -> NoReturn:
        f_in_name, okPressed = QtWidgets.QFileDialog.getOpenFileName(self, 'Select a cif file:', "",
                                                                  "Pickle files (*.pkl)")
        if not (okPressed):
            return None

        with open(f_in_name, 'rb') as fid:
            f_name = pickle.load(fid)
            self.__f_file = f_name

            f_dir = pickle.load(fid)
            self.__f_dir_data = f_dir

            mode_orig = pickle.load(fid)
            self.__mode = mode_orig

            star_obj = pickle.load(fid)
            self.__widg_central._star = star_obj

            cryspy_obj = pickle.load(fid)
            self.__widg_central._object = cryspy_obj

            glob_const_obj = pickle.load(fid)
            self.__widg_central._objects = glob_const_obj

        self.__widg_central.refresh_wind()

    def open_folder(self) -> NoReturn:
        os.startfile(self.__f_dir_data)

    def open(self) -> NoReturn:
        f_name, okPressed = QtWidgets.QFileDialog.getOpenFileName(self, 'Select a cif file:', self.__f_dir_data,
                                                                  "All files (*.*)")
        if not (okPressed):
            return None
        self.__widg_central._star = None
        self.__widg_central._object = None
        self.__f_file = f_name
        self.setWindowTitle(f'CrysPy editor: {f_name:}')
        self.__f_dir_data = os.path.dirname(f_name)
        os.chdir(os.path.dirname(f_name))
        mode_orig = str(self.__mode)
        self.to_star()
        if mode_orig == "cryspy":
            self.to_cryspy()
        elif mode_orig != "star":
            self.__mode = "star"
            self.to_cryspy()


class CWidget(QtWidgets.QSplitter):
    def __init__(self, width:int, height:int, w_function:WFunction) -> NoReturn:
        self.index_curent_item = None
        self.info_width = width
        self.info_height = height
        self.w_function = w_function
        super(CWidget, self).__init__()
        self._star = None
        self._object = None
        self._objects = []
        self.additional_thread = MyThread()
        self.additional_thread.signal_end.connect(self.end_of_calc_in_thread)
        self.additional_thread.signal_refresh.connect(self.refresh_wind)
        self.additional_thread.signal_start.connect(
            self.start_of_calc_in_thread)
        
        self.init_widget()
        w_cpanel = self.widget(0)
        self.additional_thread.w_cpanel = w_cpanel

    def init_widget(self):
        """
        make central layout
        """
        width_m_1 = self.info_width / 6.
        width_m_2 = (3 * self.info_width) / 6.
        width_m_3 = (2 * self.info_width) / 6.
        width_v_1 = self.info_height * 0.75
        width_v_2 = self.info_height * 0.25


        w_cpanel = self.form_w_cpanel()

        self.w_output = QtWidgets.QLabel()
        self.w_output.setSizePolicy(QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding,
                                                          QtWidgets.QSizePolicy.Expanding))
        self.w_output.setFont(QtGui.QFont("Courier", 8, QtGui.QFont.Normal))
        self.w_output.setTextInteractionFlags(QtCore.Qt.TextSelectableByMouse)
        self.w_output.setAlignment(QtCore.Qt.AlignTop)
        self.w_output.setWordWrap(True)
        self.w_output.setStyleSheet("background-color:white;")

        self.w_tab = QtWidgets.QStackedWidget()

        self.w_2 = QtWidgets.QWidget()
        self.w_2.setLayout(QtWidgets.QVBoxLayout())
        self.w_da = pg_da.DockArea()
        #self.w_3.setLayout(QtWidgets.QVBoxLayout())

        self.layout_11 = QtWidgets.QVBoxLayout()
        self.layout_12 = QtWidgets.QVBoxLayout()
        self.layout_13 = QtWidgets.QVBoxLayout()


        layout_1 = QtWidgets.QVBoxLayout()
        layout_1.addLayout(self.layout_11)
        layout_1.addLayout(self.layout_12)

        w_1 = QtWidgets.QWidget()
        w_1.setLayout(layout_1)

        self.w_tab.addWidget(self.w_2)
        self.w_tab.addWidget(self.w_da)
        self.w_tab.addWidget(w_1)

        area = QtWidgets.QScrollArea()
        area.setWidgetResizable(True)
        area.setWidget(self.w_output)



        self.w_cb_to_data = QtWidgets.QCheckBox()
        self.w_cb_to_data.setCheckState(0)
        self.w_cb_to_data.stateChanged.connect(self.w_tab.setCurrentIndex)
        self.w_cb_to_data.setTristate(on=True)

        l_h_2 = QtWidgets.QHBoxLayout()
        l_h_21 = QtWidgets.QVBoxLayout()
        l_h_21.addWidget(self.w_tab)
        l_h_21.addWidget(self.w_cb_to_data)

        l_h_2.addLayout(l_h_21, stretch=2)
        #l_h_2.addLayout(self.layout_13, stretch=1)
        w_h_2 = QtWidgets.QWidget()
        w_h_2.setLayout(l_h_2)
        widg_methods = QtWidgets.QWidget()
        widg_methods.setLayout(self.layout_13)

        splitter_vert = QtWidgets.QSplitter()
        splitter_vert.setOrientation(QtCore.Qt.Vertical)
        splitter_vert.addWidget(w_h_2)
        splitter_vert.addWidget(area)
        splitter_vert.setSizes([width_v_1, width_v_2])


        self.addWidget(w_cpanel)
        self.addWidget(splitter_vert)
        self.addWidget(widg_methods)
        self.setSizes([width_m_1, width_m_2, 0])

    def form_w_cpanel(self,
                      obj:Union[GlobalConstr, Global]=None, 
                      objects:List[Union[GlobalConstr, DataConstr, LoopConstr, ItemConstr, int, float, str, bool]]=()
                      ) -> QtWidgets.QTreeWidget:
        if obj is None:
            obj = self._object
        if len(objects) == 0:
            objects = self._objects
        if obj is None:
            obj = GlobalConstr()
        
        w_cpanel = CPanel(self.onItemClicked, self.add_output_object, self.delete_output_object,
                               object_global=obj, objects=objects, functions=L_FUNCTION_ALL)
        if isinstance(obj, Global):
            self._star = obj
        elif isinstance(obj, GlobalConstr):
            self._object = obj 

        return w_cpanel

    @QtCore.pyqtSlot(QtWidgets.QTreeWidgetItem, int)
    def onItemClicked(self, it, col):
        self.form_tab(it._object)

    def replace_object_global(self, obj:Union[GlobalConstr, Global]=None) -> NoReturn:
        w_cpanel = self.widget(0)
        w_cpanel.replace_object_global(obj)

        if isinstance(obj, Global):
            self._star = obj
        elif isinstance(obj, GlobalConstr):
            self._object = obj 

    def delete_output_object(self, ind: int=None):
        if ind is None:
            for ind in reversed(range(len(self._objects))):
                del self._objects[ind]
                w_cpanel = self.widget(0)
                w_cpanel.delete_output_object(ind)
        else:
            del self._objects[ind]
            w_cpanel = self.widget(0)
            w_cpanel.delete_output_object(ind)

    def set_output_objects(self, objects:List[Union[GlobalConstr,DataConstr, LoopConstr, ItemConstr, int, float, str, bool]]):
        self._objects = objects
        w_cpanel = self.widget(0)
        w_cpanel.set_output_objects(objects)

    def add_output_object(self, object:Union[GlobalConstr,DataConstr, LoopConstr, ItemConstr, int, float, str, bool]):
        self._objects.append(object)
        w_cpanel = self.widget(0)
        w_cpanel.add_output_object(object)

    def form_tab(self, obj):
        layout_11 = self.layout_11
        layout_12 = self.layout_12
        layout_13 = self.layout_13
        layout_2 = self.w_2.layout()
        w_da = self.w_da
        w_da.clear()
        layout_3 = QtWidgets.QVBoxLayout()
        w_output = self.w_output
        del_layout(layout_11)
        del_layout(layout_12)
        del_layout(layout_13)
        del_layout(layout_2)
        del_layout(layout_3)

        thread = self.additional_thread

        flag_done = False
        docks = ()
        if isinstance(obj, Callable):
            self.w_function.set_function(obj, thread)
            flag_done = True
        elif (isinstance(obj, str) | isinstance(obj, numpy.ndarray) | 
              isinstance(obj, int) | isinstance(obj, float) | isinstance(obj, list)):
            w_for_string(obj, layout_11, layout_12,
                         layout_13, layout_2, layout_3, w_output, thread)
            flag_done = True


        if not(flag_done):
            #if isinstance(obj, Pd2dMeas):
            #    w_for_pd2d_meas(obj, layout_11, layout_12, layout_13,
            #                    layout_2, layout_3, w_output, thread, self.w_function)
            #    flag_done = True
            #if isinstance(obj, Pd2dProc):
            #    w_for_pd2d_proc(obj, layout_11, layout_12, layout_13,
            #                    layout_2, layout_3, w_output, thread, self.w_function)
            #    flag_done = True
            pass

        if not(flag_done):
            docks = w_for_presentation(obj, thread)
            if isinstance(obj, (Pd2dMeas, Pd2dProc, Pd2d, RhoChi, Pd)):
                pass
            elif isinstance(obj, GlobalConstr):
                w_for_global_constr(obj, layout_11, layout_12,
                                    layout_13, layout_2, layout_3, w_output, thread, self.w_function)
            elif isinstance(obj, DataConstr):
                w_for_data_constr(obj, layout_11, layout_12,
                                  layout_13, layout_2, layout_3, w_output, thread, self.w_function)
            elif isinstance(obj, LoopConstr):
                w_for_loop_constr(obj, layout_11, layout_12,
                                  layout_13, layout_2, layout_3, w_output, thread, self.w_function)
            elif isinstance(obj, ItemConstr):
                w_for_item_constr(obj, layout_11, layout_12,
                                  layout_13, layout_2, layout_3, w_output, thread, self.w_function)
            elif isinstance(obj, Global):
                pass
            elif isinstance(obj, Data):
                pass
            elif isinstance(obj, Loop):
                w_for_loop(obj, layout_11, layout_12,
                           layout_13, layout_2, layout_3, w_output, thread, self.w_function)
            elif isinstance(obj, Item):
                w_for_item(obj, layout_11, layout_12,
                           layout_13, layout_2, layout_3, w_output, thread, self.w_function)

        for i_dock, dock in enumerate(docks):
            if ((i_dock == 0)|(i_dock == 1)):
                dock.setStretch(x=10, y=10)
                w_da.addDock(dock, "right")
            elif (i_dock == 2):
                dock.setStretch(x=1, y=1)
                w_da.addDock(dock, "bottom")
            else:
                dock.setStretch(x=1, y=1)
                w_da.addDock(dock, "right", docks[i_dock-1])
                
                
        if (layout_3.count() != 0):
            w_3 = QtWidgets.QWidget()
            w_3.setLayout(layout_3)
            dock = pg_da.Dock("layout_3", widget=w_3)
            w_da.addDock(dock)
        if (layout_3.count() != 0) or (len(docks)!=0):
            self.w_cb_to_data.setText("RCIF/Presentation/Tables")
            self.w_cb_to_data.setCheckState(1)
            self.w_cb_to_data.show()
        elif (layout_11.count()+layout_12.count()) != 0:
            self.w_cb_to_data.show()
            self.w_cb_to_data.setCheckState(2)
            self.w_cb_to_data.setTristate(on=False)
            self.w_cb_to_data.setText("RCIF/Tables")
            #self.w_tab.setCurrentIndex(0)
        else:
            self.w_cb_to_data.hide()
            self.w_cb_to_data.setCheckState(0)
        
    def start_of_calc_in_thread(self):
        w_cpanel = self.widget(0)
        w_cpanel.setStyleSheet("background-color:white;")
        cur_item = w_cpanel.currentItem()
        self.index_curent_item = tuple(find_tree_item_position(w_cpanel, cur_item))
        
        ls_out = [f"The calculations are running.\n"]
        self.w_output.setText("\n".join(ls_out))

    def end_of_calc_in_thread(self):
        self.w_function.calculation_finished()

        w_cpanel = self.widget(0)
        w_cpanel.setStyleSheet("background-color:light gray;")

        thread = self.additional_thread
        function = thread.function
        function_name = function.__name__
        output = thread.output
        ls_out = []
        ls_out.append(
            f"The function '{function_name:}' is perfomed.\n\nResult is \n")
        ls_out.append(str(output))
        self.w_output.setText("\n".join(ls_out))

        if isinstance(output, tuple):
            for out_1 in output:
                self.add_output_object(out_1)
        else:
            self.add_output_object(output)
        
        self.refresh_wind()
        previous_item = self.index_curent_item 
        if previous_item  is not None:
            w_cpanel = self.widget(0)
            n_main = previous_item[0]
            if n_main < w_cpanel.columnCount():
                w_item = w_cpanel.itemAt(n_main, 0)
                if len(previous_item) > 1:
                    for n_ind in previous_item[1:]:
                        if n_ind< w_item.childCount():
                            w_item = w_item.child(n_ind)
                        else:
                            break
                self.form_tab(w_item._object)
        

    def refresh_wind(self):
        w_cpanel = self.form_w_cpanel()
        self.replaceWidget(0, w_cpanel)


def main_w(l_arg=[]):
    app = QtWidgets.QApplication(l_arg)
    #app.setStyle(QtWidgets.QStyleFactory.create('Fusion'))
    app.setStartDragDistance(100)
    if len(l_arg) >= 2:
        f_dir_data = os.path.abspath(l_arg[1])
    else:
        f_dir_data = os.getcwd()
    main_wind_1 = CBuilder(f_dir_data)
    sys.exit(app.exec_())


if __name__ == '__main__':
    l_arg = sys.argv
    main_w(l_arg)
