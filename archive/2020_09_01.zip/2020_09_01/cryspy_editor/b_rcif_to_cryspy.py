import os
import sys
import copy
import json
import importlib
import pycifstar

L_ITEM_CLASS = []
L_LOOP_CLASS = []
L_DATA_CLASS = []
L_GLOBAL_CLASS = []
L_FUNCTION_ALL = []


try:
    FLAG_CRYSPY = True
    import cryspy
    from cryspy.common.cl_global_constr import GlobalConstr
    from cryspy.common.cl_data_constr import DataConstr
    L_ITEM_CLASS.extend(cryspy.L_ITEM_CONSTR_CLASS)
    L_LOOP_CLASS.extend(cryspy.L_LOOP_CONSTR_CLASS)
    L_DATA_CLASS.extend(cryspy.L_DATA_CONSTR_CLASS)
    L_GLOBAL_CLASS.extend(cryspy.L_GLOBAL_CONSTR_CLASS)
    L_FUNCTION_ALL.extend(cryspy.L_FUNCTION)
except ImportError:
    FLAG_CRYSPY = False

try:
    FLAG_MAGREF = True

    from magref.classes.cl_cryst_field import CrystField
    from magref.classes.cl_coefficient_stevens import CoefficientStevens
    from magref.classes.cl_coefficient_wybourne import CoefficientWybourne
    from magref.classes.cl_inelastic_parameter import InelasticParameter
    from magref.classes.cl_ion_type import IonType
    from magref.classes.cl_inelastic_background import InelasticBackgroundL
    from magref.classes.cl_meas_elastic import MeasElasticL
    from magref.classes.cl_meas_inelastic import MeasInelasticL
    from magref.classes.cl_meas_inelastic_peak import MeasInelasticPeakL
    from magref.classes.cl_point_site import PointSiteL
    from magref.classes.cl_point_type import PointTypeL
    from magref.classes.cl_refinement import RefinementL
    from magref.scripts.cl_cryst_ref import CrystRef

    L_ITEM_CLASS.extend([CoefficientStevens, CoefficientWybourne, InelasticParameter, IonType])
    L_LOOP_CLASS.extend([InelasticBackgroundL, MeasElasticL, MeasInelasticL, MeasInelasticPeakL, 
                         PointSiteL, PointTypeL, RefinementL])
    L_DATA_CLASS.extend([CrystField])
    L_GLOBAL_CLASS.append(CrystRef)

except ImportError:
    FLAG_MAGREF = False


#try:
#    FLAG_MEM = True
#
#    from lib_mem.mem.cl_density_points_number import DensityPointsNumber
#    from lib_mem.mem.cl_density_point import DensityPointL
#    from lib_mem.mem.cl_density import Density
#    from lib_mem.mem.cl_compting_parameters import ComputingParameters
#
#    from lib_mem.scripts.cl_mem_tensor import MemTensor
#
#    L_ITEM_CLASS.extend([ComputingParameters, DensityPointsNumber])
#    L_LOOP_CLASS.extend([DensityPointL])
#    L_DATA_CLASS.extend([Density])
#    L_GLOBAL_CLASS.append(MemTensor)
#except ImportError:
#    FLAG_MEM = False
FLAG_MEM = False

f_setup = os.path.join(os.path.dirname(__file__), 'setup.json')
d_setup = json.load(open(f_setup, 'r'))
dir_additional_libraries = d_setup['directory_additional_libraries']
for _additional_library in dir_additional_libraries:
    if os.path.isdir(_additional_library):
        l_library = os.listdir(_additional_library)
        for _library in l_library:
            sys.path.insert(1, _additional_library)
            additional_module = importlib.import_module(_library)
            dir_module = dir(additional_module)
            if 'L_ITEM_CONSTR_CLASS' in dir_module: L_ITEM_CLASS.extend(additional_module.L_ITEM_CONSTR_CLASS)
            if 'L_LOOP_CONSTR_CLASS' in dir_module: L_LOOP_CLASS.extend(additional_module.L_LOOP_CONSTR_CLASS)
            if 'L_DATA_CONSTR_CLASS' in dir_module: L_DATA_CLASS.extend(additional_module.L_DATA_CONSTR_CLASS)
            if 'L_GLOBAL_CONSTR_CLASS' in dir_module: L_GLOBAL_CLASS.extend(additional_module.L_GLOBAL_CONSTR_CLASS)
            if 'L_FUNCTION' in dir_module: L_FUNCTION_ALL.extend(additional_module.L_FUNCTION)



def is_in_rcif_block(rcif_block, cryspy_obj):
    ls_cryspy = cryspy_obj.to_cif.split("\n")
    l_name = [_.strip().split()[0] for _ in ls_cryspy if _.startswith("_")]
    l_flag = [rcif_block.is_value(_name) for _name in l_name]
    return any(l_flag), all(l_flag)
    

def rcif_to_cryspy(rcif):
    l_global_obj = []
    l_defined_classes = []

    if len(rcif.items)+len(rcif.loops) > 0:
        str_rcif_items = str(rcif.items)
        l_optional_classes = []
        for _item_class in L_ITEM_CLASS:
            item_obj = _item_class.from_cif(str_rcif_items)
            if item_obj is not None:
                l_optional_classes.append(_item_class)
                l_global_obj.append(item_obj)
                if _item_class not in l_defined_classes:
                    l_defined_classes.append(_item_class)
        for _loop_obj in rcif.loops:
            for _loop_class in L_LOOP_CLASS:
                loop_obj = _loop_class.from_cif(str(_loop_obj))
                
                if loop_obj is None:
                    pass
                elif len(loop_obj) != 0:
                    l_optional_classes.append(_loop_class)
                    l_global_obj.append(loop_obj)
                    if _loop_class not in l_defined_classes:
                        l_defined_classes.append(_loop_class)

    for _data in rcif.datas:
        flag = False
        
        str_data = str(_data)
        for _data_class in L_DATA_CLASS:
            data_obj = _data_class.from_cif(str_data)
            if data_obj is not None:
                l_global_obj.append(data_obj)
                if not(_data_class in l_defined_classes):
                    l_defined_classes.append(_data_class)
                flag = True
        if not(flag):
            str_data_items = str(_data.items)
            l_data_item_obj, l_data_loop_obj = [], []
            l_optional_classes = []
            for _item_class in L_ITEM_CLASS:
                item_obj = _item_class.from_cif(str_data_items)
                if item_obj is not None:
                    l_optional_classes.append(_item_class)
                    l_data_item_obj.append(item_obj)
            for _loop_obj in _data.loops:
                for _loop_class in L_LOOP_CLASS:
                    loop_obj = _loop_class.from_cif(str(_loop_obj))

                    if loop_obj is None:
                        pass
                    elif len(loop_obj) != 0:
                        l_optional_classes.append(_loop_class)
                        l_data_loop_obj.extend(loop_obj)

            if ((len(l_data_item_obj) != 0) | (len(l_data_loop_obj) != 0)):
                _data_class = DataConstr
                data_obj = DataConstr(data_name=_data.name, optional_classes=list(set(l_optional_classes)))
                data_obj.optional_objs = l_data_item_obj + l_data_loop_obj
                l_global_obj.append(data_obj)
                l_defined_classes.append(_data_class)
            
    global_constr = GlobalConstr(global_name="", mandatory_classes=l_defined_classes)
    global_constr.mandatory_objs = l_global_obj 
    return global_constr


