import os
from typing import Union, List, Callable, Any, NoReturn
from PyQt5 import QtCore, QtGui, QtWidgets
from cryspy import GlobalConstr, DataConstr, LoopConstr, ItemConstr, Fitable
from pycifstar import Global, Data, Loop, Item
import numpy
import json
from cryspy_editor.b_rcif_to_cryspy import L_GLOBAL_CLASS, L_DATA_CLASS, L_LOOP_CLASS, L_ITEM_CLASS

class CDragList(QtWidgets.QListWidget):
    def __init__(self) -> NoReturn:
        super(CDragList, self).__init__()

        self.setSizePolicy(QtWidgets.QSizePolicy(
                QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding))
        self.attached_object = None
        self.setDragEnabled(True)
        self.w_output = None

    def mouseMoveEvent(self, event):
        w_item = self.itemAt(event.pos())
        if w_item is None:
            return

        drag = QtGui.QDrag(self)
        dragMimeData = QtCore.QMimeData()  
        dragMimeData.object_to_send = w_item.attached_object
        dragMimeData.setText(f"{w_item.text():}")
        drag.setMimeData(dragMimeData) 
        drag.exec_(QtCore.Qt.MoveAction)


    def set_object_with_internal_attributes(self, object_with_internal_attributes: Union[ItemConstr, LoopConstr],
                                            w_output:QtWidgets.QLabel)->NoReturn:
        l_attr =  object_with_internal_attributes.INTERNAL_ATTRIBUTE 
        obj = object_with_internal_attributes
        self.w_output = w_output
        if l_attr is None:
            return 
        l_attr = list(l_attr)
        l_attr.sort()
        if len(l_attr) != 0:
            self.show()
            for _attr in l_attr:
                val = getattr(obj, _attr)
                if isinstance(val, float):
                    s_val = f"{_attr:}: {round(val, 5):}"
                elif isinstance(val, Fitable):
                    if val.refinement:
                        s_val = f"{_attr:}: {str(val):}"
                    else:
                        s_val = f"{_attr:}: {round(float(val), 5):}"
                elif len(str(val).split("\n")) > 1:
                    s_val = f"{_attr:}: ..."
                elif len(str(val)) > 10:
                    try:
                        s_val = f"{_attr:}: {round(float(val), 5):}"
                    except:
                        s_val = f"{_attr:}: {str(val)[:7]:}..."
                else:
                    s_val = f"{_attr:}: {str(val):}"

                _list_widget_item = QtWidgets.QListWidgetItem(s_val)
                _list_widget_item.attached_object = val
                #_list_widget_item.setToolTip(get_attribute_with_help(obj, _attr))
                self.addItem(_list_widget_item)
            self.itemDoubleClicked.connect(self.double_click_on_item)
        else:
            self.hide()
            
    def double_click_on_item(self, widget:QtWidgets.QListWidgetItem) -> NoReturn:
        obj = widget.attached_object
        if self.w_output is not None:
            self.w_output.setText(str(obj))


    def open_menu(self, position):
        w_item = self.itemAt(position)
        if w_item is not None:
            menu = QtWidgets.QMenu()
            test_action = QtWidgets.QAction('Test action', menu)
            menu.addAction(test_action)
            menu.exec_(self.viewport().mapToGlobal(position))
