import numpy
import pyqtgraph as pg
import pyqtgraph.dockarea as pg_da


from PyQt5 import QtWidgets, QtGui, QtCore

from cryspy import AtomSiteL, Crystal, Cell, SpaceGroup, PdInstrResolution, \
                   AtomSiteSusceptibilityL, Diffrn, DiffrnReflnL, PdProcL, \
                   PdBackgroundL, PdPeakL, Pd, PdMeasL, RhoChi, Chi2, \
                   RefineLs, Pd2dMeas, Pd2dProc, Pd2d
from typing import NoReturn, Union

pg.setConfigOption('background', 'w')
pg.setConfigOption('foreground', 'k')

pg_pen_black = pg.mkPen("k", width=5)
pg_pen_black_thick = pg.mkPen("k", width=2)


def matrix_widget(win:pg.GraphicsLayoutWidget,
                  data, x_step, y_step, x_point_0, y_point_0):
    win.clear()
    #win.setWindowTitle('pyqtgraph example: Image Analysis')
    
    # A plot area (ViewBox + axes) for displaying the image
    p1 = win.addPlot(title="")
    
    # Item for displaying image data
    img = pg.ImageItem()
    p1.addItem(img)
    
    ## Custom ROI for selecting an image region
    #roi = pg.ROI([-8, 14], [6, 5])
    #roi.addScaleHandle([0.5, 1], [0.5, 0.5])
    #roi.addScaleHandle([0, 0.5], [0.5, 0.5])
    #p1.addItem(roi)
    #roi.setZValue(10)  # make sure ROI is drawn above image
    
    # Isocurve drawing
    iso = pg.IsocurveItem(level=0.8, pen=pg.mkPen("g", width=2))
    iso.setParentItem(img)
    iso.setZValue(5)
    
    # Contrast/color control
    hist = pg.HistogramLUTItem()
    hist.setImageItem(img)
    hist.setHistogramRange(data.mean()-3*numpy.std(data), data.mean()+3*numpy.std(data))
    win.addItem(hist)
    
    # Draggable line for setting isocurve level
    isoLine = pg.InfiniteLine(angle=0, movable=True, pen=pg.mkPen("g", width=2))
    hist.vb.addItem(isoLine)
    hist.vb.setMouseEnabled(y=True) # makes user interaction a little easier
    isoLine.setValue(0.8)
    isoLine.setZValue(1000) # bring iso line above contrast controls

    ## Another plot area for displaying ROI data
    #win.nextRow()
    #p2 = win.addPlot(colspan=2)
    #p2.setMaximumHeight(250)
    #win.resize(800, 800)
    #win.show()
    
    
    # Generate image data
    img.setImage(data)
    hist.setLevels(data.mean()-1*numpy.std(data), data.mean()+1*numpy.std(data))
    
    # build isocurves from smoothed data
    iso.setData(pg.gaussianFilter(data, (2, 2)))
    
    # set position and scale of image
    img.scale(x_step, y_step)
    img.translate(x_point_0, y_point_0)

    # zoom to fit imageo
    p1.autoRange()  
    
    
    ## Callbacks for handling user interaction
    #def updatePlot():
    #    selected = roi.getArrayRegion(data, img)
    #    p2.plot(selected.mean(axis=0), clear=True)
    
    #roi.sigRegionChanged.connect(updatePlot)
    #updatePlot()
    
    def updateIsocurve():
        iso.setLevel(isoLine.value())
    
    isoLine.sigDragged.connect(updateIsocurve)
    
    def imageHoverEvent(event):
        """Show the position, pixel, and value under the mouse cursor.
        """
        if event.isExit():
            p1.setTitle("")
            return
        pos = event.pos()
        i, j = pos.y(), pos.x()
        i = int(numpy.clip(i, 0, data.shape[0] - 1))
        j = int(numpy.clip(j, 0, data.shape[1] - 1))
        val = data[i, j]
        ppos = img.mapToParent(pos)
        x, y = ppos.x(), ppos.y()
        p1.setTitle("pos: (%0.1f, %0.1f)  pixel: (%d, %d)  value: %g" % (x, y, i, j, val))
    
    # Monkey-patch the image to use our custom hover function. 
    # This is generally discouraged (you should subclass ImageItem instead),
    # but it works for a very simple use like this. 
    img.hoverEvent = imageHoverEvent
    return 

def add_2nd_axis_to_plot(p1:pg.PlotItem, label_axis_1:str="", 
                         label_axis_2:str=""):
    p1.setLabels(left=label_axis_1)
    ## create a new ViewBox, link the right axis to its coordinate system
    p2 = pg.ViewBox()
    p1.showAxis('right')
    p1.scene().addItem(p2)
    p1.getAxis('right').linkToView(p2)
    p2.setXLink(p1)
    p1.getAxis('right').setLabel(label_axis_2, color='#0000ff')

    ## Handle view resizing 
    def updateViews():
        ## view has resized; update auxiliary views to match
        p2.setGeometry(p1.vb.sceneBoundingRect())
        ## need to re-update linked axes since this was called
        ## incorrectly while views had different shapes.
        ## (probably this should be handled in ViewBox.resizeEvent)
        p2.linkedViewChanged(p1.vb, p2.XAxis)
    updateViews()
    p1.vb.sigResized.connect(updateViews)
    return p2



def dock_pd_instr_resolution(obj:PdInstrResolution):
    tth = numpy.linspace(1, 120, 119)
    docks = []
    if obj.is_defined:
        h_pv, eta, h_g, h_l, a_g, b_g, a_l, b_l = obj.calc_resolution(tth)

        widget = pg.GraphicsLayoutWidget(title="sum/diff")
        p1 = widget.addPlot(x=tth, y=h_g, name="h_g", title="Resolution", 
                pen=pg_pen_black)
        p1.plot(x=tth, y=h_l, name="h_l", pen=pg_pen_black)
        docks.append(pg_da.Dock("Instrumental resolution", widget=widget))
    return docks

def dock_meas(obj:PdMeasL):
    np_x_1 = numpy.array(obj.ttheta, dtype = float)
    np_y_u_1 = numpy.array(obj.intensity_up, dtype = float)
    np_y_su_1 = numpy.array(obj.intensity_up_sigma, dtype = float)
    np_y_d_1 = numpy.array(obj.intensity_down, dtype = float)
    np_y_sd_1 = numpy.array(obj.intensity_down_sigma, dtype = float)

    if numpy.all(numpy.isnan(np_y_u_1)):
        np_y_s_1 = numpy.array(obj.intensity, dtype = float)
        np_y_ss_1 = numpy.array(obj.intensity_sigma, dtype = float)
        np_y_m_1 = 0*np_y_s_1
        np_y_sm_1 = np_y_ss_1
    else:
        np_y_s_1 = np_y_u_1 + np_y_d_1
        np_y_ss_1 = numpy.sqrt(numpy.square(np_y_su_1) + numpy.square(np_y_sd_1))
        np_y_m_1 = np_y_u_1 - np_y_d_1
        np_y_sm_1 = np_y_ss_1

    widget = pg.PlotWidget()
    p1 = widget.plotItem

    p2 = add_2nd_axis_to_plot(p1, label_axis_1="Intensity (a.u.)", 
                                  label_axis_2="Intensity (a.u.)")
                
    err_s = pg.ErrorBarItem(x=np_x_1, y=np_y_s_1, top=np_y_ss_1, 
                                      bottom=np_y_ss_1, beam=0.5)
            
    err_m = pg.ErrorBarItem(x=np_x_1, y=np_y_m_1, top=np_y_sm_1, 
                                      bottom=np_y_sm_1, beam=0.5)
            
    p1.plot(x=np_x_1, y=np_y_s_1, name="sum", title="Sum",
                         symbol='o', pen={'color': 0.8, 'width': 2})
    p1.addItem(err_s)
            
    p2.addItem(pg.PlotCurveItem(x=np_x_1, y=np_y_m_1, name="diff", 
                                title="Difference", pen=pg_pen_black_thick))
    p2.addItem(pg.ScatterPlotItem(x=np_x_1, y=np_y_m_1, 
                         symbol='o', pen={'color': 0.8, 'width': 2}))

    p2.addItem(err_m)

    [x_range_12, y_range_12] = p1.viewRange()
    y_range = y_range_12[1]-y_range_12[0]
    p2.setRange(yRange=(-0.25*y_range, 0.75*y_range))




    widget_2 = pg.PlotWidget()
    p3 = widget_2.plotItem

    p4 = add_2nd_axis_to_plot(p3, label_axis_1="Intensity (a.u.)", 
                                label_axis_2="Intensity (a.u.)")


    err_u = pg.ErrorBarItem(x=np_x_1, y=np_y_u_1, top=np_y_su_1, 
                                      bottom=np_y_su_1, beam=0.5)
    err_d = pg.ErrorBarItem(x=np_x_1, y=np_y_d_1, top=np_y_sd_1, 
                                      bottom=np_y_sd_1, beam=0.5)

    p3.plot(x=np_x_1, y=np_y_u_1, name="up", title="Up",
                         symbol='o', pen={'color': 0.8, 'width': 2})
    p3.addItem(err_u)

    p4.addItem(pg.PlotCurveItem(x=np_x_1, y=np_y_d_1, name="down", title="Down",
                                pen=pg_pen_black_thick))
    p4.addItem(pg.ScatterPlotItem(x=np_x_1, y=np_y_d_1,
                         symbol='o', pen={'color': 0.8, 'width': 2}))
    p4.addItem(err_d)


    dock_1 = pg_da.Dock("Sum/Diff.", widget=widget)
    dock_2 = pg_da.Dock("Up/Down", widget=widget_2)
    return (dock_1, dock_2, )

def dock_proc(obj:PdProcL):
    np_x_1 = numpy.array(obj.ttheta, dtype = float)
    np_y_u_1 = numpy.array(obj.intensity_up, dtype = float)
    np_y_su_1 = numpy.array(obj.intensity_up_sigma, dtype = float)
    np_y_d_1 = numpy.array(obj.intensity_down, dtype = float)
    np_y_sd_1 = numpy.array(obj.intensity_down_sigma, dtype = float)
    np_y_b_1 = numpy.array(obj.intensity_bkg_calc, dtype = float)
    np_y_u_2 = numpy.array(obj.intensity_up_total, dtype = float)
    np_y_d_2 = numpy.array(obj.intensity_down_total, dtype = float)
    np_y_s_1 = numpy.array(obj.intensity, dtype = float)
    np_y_ss_1 = numpy.array(obj.intensity_sigma, dtype = float)
    np_y_m_1 = np_y_u_1 - np_y_d_1
    np_y_sm_1 = np_y_ss_1
    np_y_s_2 = numpy.array(obj.intensity_total, dtype = float)
    np_y_m_2 = numpy.array(obj.intensity_diff_total, dtype = float)

    #np_x_2 = numpy.array(peak.ttheta, dtype = float)
    #np_xysm_1 = numpy.vstack((np_x_1, np_y_s_1, np_y_ss_1, np_y_s_2)).transpose()
    #np_xb_1 = numpy.vstack((np_x_1, 2*np_y_b_1)).transpose()
 
    widget = pg.PlotWidget()
    p1 = widget.plotItem

    p2 = add_2nd_axis_to_plot(p1, label_axis_1="Intensity (a.u.)", 
                                label_axis_2="Difference")
            
    err1 = pg.ErrorBarItem(x=np_x_1, y=np_y_s_1, top=np_y_ss_1, 
                                      bottom=np_y_ss_1, beam=0.5)
            
            
    p1.plot(x=np_x_1, y=np_y_s_1, name="exp", title="model",
                         symbol='o', pen={'color': 0.8, 'width': 2})
    p1.plot(x=np_x_1, y=np_y_s_2, name="model", title="model", 
                pen=pg_pen_black)
    p1.addItem(err1)
            
    p2.addItem(pg.PlotCurveItem(x=np_x_1, y=np_y_s_1-np_y_s_2, 
                                        pen=pg_pen_black_thick))

    widget_2 = pg.PlotWidget()
    p3 = widget_2.plotItem

    p4 = add_2nd_axis_to_plot(p3, label_axis_1="Intensity (a.u.)", 
                              label_axis_2="Difference")


    err1 = pg.ErrorBarItem(x=np_x_1, y=np_y_m_1, top=np_y_sm_1, 
                                      bottom=np_y_ss_1, beam=0.5)

    p3.plot(x=np_x_1, y=np_y_m_1, name="exp", title="model",
                         symbol='o', pen={'color': 0.8, 'width': 2})
    p3.plot(x=np_x_1, y=np_y_m_2, name="model", title="model", 
                pen=pg_pen_black)
    p3.addItem(err1)
            
    p4.addItem(pg.PlotCurveItem(x=np_x_1, y=np_y_m_1-np_y_m_2, 
                                        pen=pg_pen_black_thick))
    
    [x_range_12, y_range_12] = p1.viewRange()
    y_range = y_range_12[1]-y_range_12[0]
    p2.setRange(yRange=(-0.15*y_range, 0.85*y_range))
    p3.setYRange(-0.50*y_range, 0.50*y_range)
    p4.setRange(yRange=(-0.15*y_range, 0.85*y_range))


    dock_1 = pg_da.Dock("Sum", widget=widget)
    dock_2 = pg_da.Dock("Difference", widget=widget_2)
            
    return (dock_1, dock_2, )

def dock_cell(obj:Cell):
    docks = []
    s_str = obj.report_cell()
    if s_str is not None:
        widget = QtWidgets.QLabel()
        area = QtWidgets.QScrollArea()
        area.setWidgetResizable(True)
        area.setWidget(widget)

        widget.setStyleSheet("background-color:white;")
        #widget.setFont(QtGui.QFont("Courier", 12, QtGui.QFont.Bold))
        widget.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)
        widget.setText(s_str)

        dock_1 = pg_da.Dock("Cell", widget=area)
        docks.append(dock_1)
    return tuple(docks)

def dock_space_group(obj:SpaceGroup):
    docks = []
    s_str = obj.report_space_group()
    if s_str is not None:
        widget = QtWidgets.QLabel()
        area = QtWidgets.QScrollArea()
        area.setWidgetResizable(True)
        area.setWidget(widget)

        widget.setStyleSheet("background-color:white;")
        #widget.setFont(QtGui.QFont("Courier", 12, QtGui.QFont.Bold))
        widget.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)
        widget.setText(s_str)

        dock_1 = pg_da.Dock("Space Group", widget=area)
        docks.append(dock_1)
    return tuple(docks)

def dock_crystal(obj:Crystal):
    docks = []
    cell = obj.cell
    space_group = obj.space_group
    if cell is not None:
        docks.extend(list(dock_cell(cell)))
    if space_group is not None:
        docks.extend(list(dock_space_group(space_group)))
    s_str = obj.report_main_axes_of_magnetization_ellipsoids()
    if s_str is not None:
        widget = QtWidgets.QLabel()
        area = QtWidgets.QScrollArea()
        area.setWidgetResizable(True)
        area.setWidget(widget)

        widget.setStyleSheet("background-color:white;")
        #widget.setFont(QtGui.QFont("Courier", 12, QtGui.QFont.Bold))
        widget.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)
        widget.setText(s_str)

        dock_1 = pg_da.Dock("Magnetization", widget=area)
        docks.append(dock_1)
    return tuple(docks)

def dock_pd(obj:Pd):
    f_proc, f_meas, f_bkgr, f_peak = False, False, False, False
    proc, meas, bkgr, peak = None, None, None, None
    meas = obj.meas
    f_meas = meas is not None
    bkgr = obj.background
    f_bkgr = bkgr is not None
    chi2 = obj.chi2
    f_chi2 = chi2 is not None
    refine_ls = obj.refine_ls
    f_refine_ls = refine_ls is not None
    for int_obj in obj.optional_objs:
        if isinstance(int_obj, PdProcL):
            proc, f_proc = int_obj, True
        elif isinstance(int_obj, PdPeakL):
            peak, f_peak = int_obj, True

    docks = ()
    if (f_proc & f_peak):
        docks = dock_proc(proc)
    elif f_meas:
        docks = dock_meas(meas)
    if f_chi2:
        docks_2 = dock_chi2(chi2)
        docks = tuple(list(docks)+list(docks_2))
    if f_refine_ls:
        docks_2 = dock_refine_ls(refine_ls)
        docks = tuple(list(docks)+list(docks_2))
    return docks

def dock_pd2d(obj:Pd2d):
    f_proc, f_meas, f_bkgr, f_peak = False, False, False, False
    proc, meas, bkgr, peak = None, None, None, None
    meas = obj.meas
    f_meas = meas is not None
    bkgr = obj.background
    f_bkgr = bkgr is not None
    chi2 = obj.chi2
    f_chi2 = chi2 is not None
    refine_ls = obj.refine_ls
    f_refine_ls = refine_ls is not None

    proc = obj.proc
    f_proc = proc is not None


    docks = []
    #print("f_meas, f_proc: ", f_meas, f_proc)
    if f_proc:
        docks.extend(list(dock_pd2d_proc(proc)))
    elif f_meas:
        docks.extend(list(dock_pd2d_meas(meas)))
    if f_chi2:
        docks.extend(list(dock_chi2(chi2)))
    if f_refine_ls:
        docks.extend(list(dock_refine_ls(refine_ls)))
    return tuple(docks)


def dock_refine_ls(obj:RefineLs):
    docks = []
    if ((obj.number_reflns is not None)&(obj.goodness_of_fit_all is not None)):
        text = f"Points: {obj.number_reflns:}\nGoF: {obj.goodness_of_fit_all:.2f}"
        widget = QtWidgets.QLabel(text)
        docks.append(pg_da.Dock("RefineLs", widget=widget))
    return tuple(docks)
    

def dock_chi2(obj:Chi2):
    docks = []
    layout = QtWidgets.QGridLayout()
    cb_s = QtWidgets.QCheckBox("sum")
    if obj.sum is not None:
        cb_s.setCheckState(2*int(obj.sum))
    cb_s.stateChanged.connect(lambda x: setattr(obj, "__sum", bool(x/2)))
    layout.addWidget(cb_s, 0, 0)

    cb_m = QtWidgets.QCheckBox("diff")
    if obj.diff is not None:
        cb_m.setCheckState(2*int(obj.diff))
    cb_m.stateChanged.connect(lambda x: setattr(obj, "__diff", bool(x/2)))
    layout.addWidget(cb_m, 1, 0)

    cb_u = QtWidgets.QCheckBox("up")
    if obj.up is not None:
        cb_u.setCheckState(2*int(obj.up))
    cb_u.stateChanged.connect(lambda x: setattr(obj, "__up", bool(x/2)))
    layout.addWidget(cb_u, 0, 1)

    cb_d = QtWidgets.QCheckBox("down")
    if obj.down is not None:
        cb_d.setCheckState(2*int(obj.down))
    cb_d.stateChanged.connect(lambda x: setattr(obj, "__down", bool(x/2)))
    layout.addWidget(cb_d, 1, 1)

    widget = QtWidgets.QWidget()
    widget.setLayout(layout)
    dock_1 = pg_da.Dock("Chi2", widget=widget)
    docks.append(dock_1)
    return tuple(docks)

def dock_rhochi(obj:RhoChi, thread:QtCore.QThread):
    #crystals = obj.crystals
    experiments = obj.experiments
    docks = []
    #for crystal in crystals:
    #    docks.extend(list(dock_crystal(crystal)))
    if experiments is not None:
        for experiment in experiments:
            if isinstance(experiment, Pd):
                docks.extend(list(dock_pd(experiment)))
            elif isinstance(experiment, Pd2d):
                docks.extend(list(dock_pd2d(experiment)))
            
    if obj.is_defined:
        l_var_str = [str(_) for _ in obj.get_variables()]
        if len(l_var_str) != 0:
            widget_list = QtWidgets.QListWidget()
            widget_list.addItems(l_var_str)
            docks.append(pg_da.Dock("Variables", widget=widget_list))

            
    layout = QtWidgets.QVBoxLayout()
    cb_1 = QtWidgets.QPushButton("Calculate chi square")
    cb_1.clicked.connect(lambda : run_function(obj.calc_chi_sq, (True, ), thread))
    cb_1.setSizePolicy(QtWidgets.QSizePolicy.Expanding, 
                      QtWidgets.QSizePolicy.Expanding)
    cb_1.setStyleSheet("background-color:green;")

    cb_2 = QtWidgets.QPushButton("Run refinement")
    cb_2.clicked.connect(lambda : run_function(obj.refine, (False, "BFGS",), 
                                               thread))
    cb_2.setSizePolicy(QtWidgets.QSizePolicy.Expanding, 
                      QtWidgets.QSizePolicy.Expanding)
    cb_2.setStyleSheet("background-color:red;")
    layout.addWidget(cb_1)
    layout.addWidget(cb_2)
    widget = QtWidgets.QWidget()
    widget.setLayout(layout)
    docks.append(pg_da.Dock("Signal", widget=widget))
    
    
    return tuple(docks)


def run_function(func, args, thread:QtCore.QThread):
    thread.function = func
    thread.arguments = args
    thread.start()


def dock_pd2d_meas(obj:Pd2dMeas):
    docks = []
    ttheta = obj.ttheta
    phi = obj.phi
    intensity_up = obj.intensity_up
    intensity_up_sigma = obj.intensity_up_sigma
    intensity_down = obj.intensity_down
    intensity_down_sigma = obj.intensity_down_sigma
    if ((intensity_up is None) & (intensity_down is None)):
        return tuple(docks)
    int_s =  numpy.nan_to_num(intensity_up + intensity_down)
    int_m =  numpy.nan_to_num(intensity_up - intensity_down)
    ttheta_step = ttheta[1]-ttheta[0]
    phi_step = phi[1]-phi[0]
    data = int_m

    x_step = ttheta_step
    y_step = phi_step
    x_point_0 = int(ttheta[0]/ttheta_step)
    y_point_0 = int(phi[0]/phi_step)
    
    win = pg.GraphicsLayoutWidget()

    win_1d = pg.GraphicsLayoutWidget()


    z_sum_e = intensity_up.transpose()+intensity_down.transpose()
    # z_sum_s_sq = (intensity_up_sigma.transpose())**2+(intensity_down_sigma.transpose())**2
    _z_1_e = numpy.where(numpy.isnan(z_sum_e), 0., z_sum_e).sum(axis=0)
    # _z_1_s = numpy.sqrt(numpy.where(numpy.isnan(z_sum_e), 0., z_sum_s_sq).sum(axis=0))
    _n_1 = numpy.where(numpy.isnan(z_sum_e), 0., 1.).sum(axis=0)
    z_1_sum_e = _z_1_e/_n_1
    # z_1_sum_s = _z_1_s/_n_1
        
    z_diff_e = intensity_up.transpose()-intensity_down.transpose()
    _z_1_e = numpy.where(numpy.isnan(z_diff_e), 0., z_diff_e).sum(axis=0)
    _n_1 = numpy.where(numpy.isnan(z_diff_e), 0., 1.).sum(axis=0)
    z_1_diff_e = _z_1_e/_n_1
    # z_1_diff_s = _z_1_s/_n_1
    
    p1 = win_1d.addPlot()

    vb_p2 = add_2nd_axis_to_plot(p1, label_axis_1="Intensity (a.u.)", 
                                  label_axis_2="Intensity (a.u.)")

    p1.plot(ttheta, z_1_sum_e, symbol='o', pen={'color': 0.8, 'width': 2})
    p2 = pg.ScatterPlotItem(ttheta, z_1_diff_e, symbol='o', 
                                pen={'color': 0.2, 'width': 2})
    p3 = pg.PlotCurveItem(x=ttheta, y=z_1_diff_e, pen=pg_pen_black_thick)
    vb_p2.addItem(p2)
    vb_p2.addItem(p3)

    [x_range_12, y_range_12] = p1.viewRange()
    y_range = y_range_12[1]-y_range_12[0]
    vb_p2.setRange(yRange=(-0.25*y_range, 0.75*y_range))



    cb_s = QtWidgets.QPushButton("2D sum")
    cb_s.clicked.connect(lambda: matrix_widget(win, int_s, x_step, y_step, 
                                               x_point_0, y_point_0))

    cb_m = QtWidgets.QPushButton("2D diff")
    cb_m.clicked.connect(lambda: matrix_widget(win, int_m, x_step, y_step, 
                                               x_point_0, y_point_0))

    matrix_widget(win, int_m, x_step, y_step, x_point_0, y_point_0)

    layout = QtWidgets.QGridLayout()
    layout.addWidget(cb_s, 0, 0)
    layout.addWidget(cb_m, 0, 1)
    layout.addWidget(win, 1, 0, 1, 2)
    widget = QtWidgets.QWidget()
    widget.setLayout(layout)
    #win = matrix_widget(data, x_step, y_step, x_point_0, y_point_0)

    #docks.append(pg_da.Dock("2D measurements: sum", widget=imv_s))

    docks.append(pg_da.Dock("Projection of sum and difference", widget=win_1d))
    docks.append(pg_da.Dock("Plot", widget=widget))
    return tuple(docks)
    
def dock_pd2d_proc(obj:Pd2dProc):
    docks = []
    ttheta = obj.ttheta
    phi = obj.phi
    
    intensity_up = obj.intensity_up
    intensity_up_sigma = obj.intensity_up_sigma
    intensity_down = obj.intensity_down
    intensity_down_sigma = obj.intensity_down_sigma
    intensity_up_total = obj.intensity_up_total
    intensity_down_total = obj.intensity_down_total
    
    if ((intensity_up_total is None) & (intensity_down_total is None)):
        return tuple(docks)

    
    z_sum = intensity_up_total+intensity_down_total
    z_sum_e = intensity_up+intensity_down
    z_sum_s_sq = (intensity_up_sigma)**2+(intensity_down_sigma)**2
    _z_1_e = numpy.where(numpy.isnan(z_sum_e), 0., z_sum_e).sum(axis=1)
    _z_1 = numpy.where(numpy.isnan(z_sum_e), 0., z_sum).sum(axis=1)
    _z_1_s = numpy.sqrt(numpy.where(numpy.isnan(z_sum_e), 0., z_sum_s_sq).sum(axis=1))
    _n_1 = numpy.where(numpy.isnan(z_sum_e), 0., 1.).sum(axis=1)
    z_1_sum = _z_1/_n_1
    z_1_sum_e = _z_1_e/_n_1
    z_1_sum_s = _z_1_s/_n_1


    z_diff = intensity_up_total-intensity_down_total
    z_diff_e = intensity_up-intensity_down
    _z_1_e = numpy.where(numpy.isnan(z_diff_e), 0., z_diff_e).sum(axis=1)
    _z_1 = numpy.where(numpy.isnan(z_diff_e), 0., z_diff).sum(axis=1)
    _n_1 = numpy.where(numpy.isnan(z_diff_e), 0., 1.).sum(axis=1)
    z_1_diff = _z_1/_n_1
    z_1_diff_e = _z_1_e/_n_1
    z_1_diff_s = _z_1_s/_n_1
    
    z_sum_e_0 = numpy.nan_to_num(z_sum_e)
    z_diff_e_0 = numpy.nan_to_num(z_diff_e)
    
    ttheta_step = ttheta[1]-ttheta[0]
    phi_step = phi[1]-phi[0]
    x_step = ttheta_step
    y_step = phi_step
    x_point_0 = int(ttheta[0]/ttheta_step)
    y_point_0 = int(phi[0]/phi_step)
    
    win = pg.GraphicsLayoutWidget()

    err_s = pg.ErrorBarItem(x=ttheta, y=z_1_sum_e, top=z_1_sum_s, 
                                      bottom=z_1_sum_s, beam=0.5)
    err_m = pg.ErrorBarItem(x=ttheta, y=z_1_diff_e, top=z_1_diff_s, 
                                      bottom=z_1_diff_s, beam=0.5)


    win_1d_s = pg.GraphicsLayoutWidget()
    p1 = win_1d_s.addPlot()
    vb_p2 = add_2nd_axis_to_plot(p1, label_axis_1="Intensity (a.u.)", 
                                  label_axis_2="Intensity (a.u.)")
    p1.plot(ttheta, z_1_sum_e, symbol='o', pen={'color': 0.8, 'width': 2})
    p1.plot(ttheta, z_1_sum, pen=pg_pen_black)
    p1.addItem(err_s)
    p2 = pg.PlotCurveItem(ttheta, z_1_sum_e-z_1_sum, pen=pg_pen_black_thick)
    vb_p2.addItem(p2)

    win_1d_m = pg.GraphicsLayoutWidget()
    p3 = win_1d_m.addPlot()
    vb_p4 = add_2nd_axis_to_plot(p3, label_axis_1="Intensity (a.u.)", 
                                  label_axis_2="Intensity (a.u.)")
    p3.plot(ttheta, z_1_diff_e, symbol='o', pen={'color': 0.8, 'width': 2})
    p3.plot(ttheta, z_1_diff, pen=pg_pen_black)
    p3.addItem(err_m)
    p4 = pg.PlotCurveItem(ttheta, z_1_diff_e-z_1_diff, pen=pg_pen_black_thick)
    vb_p4.addItem(p4)
    
    [x_range_12, y_range_12] = p1.viewRange()
    y_range = y_range_12[1]-y_range_12[0]
    vb_p2.setRange(yRange=(-0.15*y_range, 0.85*y_range))
    p3.setYRange(-0.50*y_range, 0.50*y_range)
    vb_p4.setRange(yRange=(-0.15*y_range, 0.85*y_range))


    cb_s = QtWidgets.QPushButton("2D sum model")
    cb_s.clicked.connect(lambda: matrix_widget(win, z_sum, x_step, y_step, 
                                               x_point_0, y_point_0))

    cb_s_e = QtWidgets.QPushButton("2D sum exp")
    cb_s_e.clicked.connect(lambda: matrix_widget(win, z_sum_e_0, x_step, y_step, 
                                               x_point_0, y_point_0))

    cb_m = QtWidgets.QPushButton("2D diff model")
    cb_m.clicked.connect(lambda: matrix_widget(win, z_diff, x_step, y_step, 
                                               x_point_0, y_point_0))

    cb_m_e = QtWidgets.QPushButton("2D diff exp")
    cb_m_e.clicked.connect(lambda: matrix_widget(win, z_diff_e_0, x_step, y_step, 
                                               x_point_0, y_point_0))

    matrix_widget(win, z_diff, x_step, y_step, x_point_0, y_point_0)

    layout = QtWidgets.QGridLayout()
    layout.addWidget(cb_s, 0, 0)
    layout.addWidget(cb_s_e, 0, 1)
    layout.addWidget(cb_m, 0, 2)
    layout.addWidget(cb_m_e, 0, 3)
    layout.addWidget(win, 1, 0, 1, 4)
    widget = QtWidgets.QWidget()
    widget.setLayout(layout)
    #win = matrix_widget(data, x_step, y_step, x_point_0, y_point_0)

    #docks.append(pg_da.Dock("2D measurements: sum", widget=imv_s))

    docks.append(pg_da.Dock("Projection of sum", widget=win_1d_s))
    docks.append(pg_da.Dock("Projection of difference", widget=win_1d_m))
    docks.append(pg_da.Dock("Plot", widget=widget))
    return tuple(docks)


def w_for_presentation(obj: Union[Cell, AtomSiteL, Crystal, SpaceGroup, 
                                  PdInstrResolution, AtomSiteSusceptibilityL], 
                       thread:QtCore.QThread) -> tuple:
    #print("type(obj): ", type(obj))
    #print("obj.is_defined: ", obj.is_defined)
    if obj is None:
        return ()
    #try:
    #    if not(obj.is_defined):
    #        return ()
    #except:
    #    return ()
    #    
    if isinstance(obj, AtomSiteL):
        pass
    elif isinstance(obj, PdBackgroundL):
        np_x = numpy.array(obj.ttheta, dtype = float)
        np_y = numpy.array(obj.intensity, dtype = float)

        widget = pg.GraphicsLayoutWidget(title="background")

        p1 = widget.addPlot(x=np_x, y=np_y, name="background", 
                            title="Background", 
                fillLevel=0, fillBrush=(255,255,255,30),
                        symbol='o', pen={'color': 0.8, 'width': 2})
        p1.plot(x=np_x, y=np_y, name="line", title="", 
                fillLevel=0, fillBrush=(255,255,255,30),
                pen=pg_pen_black)

        dock_1 = pg_da.Dock("Backgraound", widget=widget)
        return (dock_1, )

    elif isinstance(obj, PdPeakL):
        np_x = numpy.array(obj.ttheta, dtype = float)
        np_y = numpy.array(obj.width_ttheta, dtype = float)

        widget = pg.GraphicsLayoutWidget(title="peaks")

        p1 = widget.addPlot(x=np_x, y=np_y, name="peaks", title="Width of peaks",
                        symbol='o', pen={'color': 0.8, 'width': 2})
        p1.plot(x=np_x, y=np_y, name="line", title="")

        dock_1 = pg_da.Dock("Peaks", widget=widget)
        return (dock_1, )

    elif isinstance(obj, PdMeasL):
        docks = dock_meas(obj)
        return docks 

    elif isinstance(obj, PdProcL):
        docks = dock_proc(obj)
        return docks 
    
    elif isinstance(obj, Pd):
        docks = dock_pd(obj)
        return docks

    
    elif isinstance(obj, Cell):
        docks = dock_cell(obj)
        return docks
    elif isinstance(obj, SpaceGroup):
        docks = dock_space_group(obj)
        return docks
    elif isinstance(obj, Crystal):
        docks = dock_crystal(obj)
        return docks
    elif isinstance(obj, PdInstrResolution):
        docks = dock_pd_instr_resolution(obj)
        return docks 
    elif isinstance(obj, Chi2):
        docks = dock_chi2(obj)
        return docks 
    elif isinstance(obj, RefineLs):
        docks = dock_refine_ls(obj)
        return docks 
    elif isinstance(obj, Pd2dMeas):
        docks = dock_pd2d_meas(obj)
        return docks 
    elif isinstance(obj, Pd2dProc):
        docks = dock_pd2d_proc(obj)
        return docks 
    elif isinstance(obj, Pd2d):
        docks = dock_pd2d(obj)
        return docks 

    elif isinstance(obj, AtomSiteSusceptibilityL):
        pass
        #widget = WGraph3D()
        #_i_pos = 0.
        #phi, theta = numpy.meshgrid(numpy.linspace(0, 360, 5), numpy.linspace(-90, 90, 5))
        #phi, theta = phi.flatten(), theta.flatten()
        #for _item in obj.item:
        #    chi_11, chi_12, chi_13 = float(_item.chi_11), float(_item.chi_12), float(_item.chi_13)
        #    chi_22, chi_23, chi_33 = float(_item.chi_22), float(_item.chi_23), float(_item.chi_33)
        #    hx = numpy.cos(phi*3.141592654/180.)*numpy.cos(theta*3.141592654/180.)
        #    hy = numpy.sin(phi*3.141592654/180.)*numpy.cos(theta*3.141592654/180.)
        #    hz = numpy.sin(theta*3.141592654/180.)
        #    mx = chi_11*hx + chi_12*hy + chi_13*hz  
        #    my = chi_12*hx + chi_22*hy + chi_23*hz 
        #    mz = chi_13*hx + chi_23*hy + chi_33*hz 
        #    for _mx, _my, _mz in zip(mx, my, mz):
        #        widget.plot_quiver(_i_pos, _i_pos, 0, mx, my, mz)
        #    widget.plot_scatters(_i_pos+mx.min(), _i_pos+my.min(), 0+mz.min(), s=1)
        #    widget.plot_scatters(_i_pos+mx.max(), _i_pos+my.max(), 0+mz.max(), s=1)
        #    _i_pos += 0.7*(mx.max()+my.max())
        #layout_presentation.addWidget(widget)
    elif isinstance(obj, (Diffrn, DiffrnReflnL)):
        if isinstance(obj, Diffrn):
            obj2 = obj.diffrn_refln
        else:
            obj2 = obj
        item = obj2.item
        if len(item)==0:
            return ()
        _item = item[0]
        fr_e, fr_s, fr_m = _item.fr, _item.fr_sigma, _item.fr_calc
        if ((fr_e is None) | (fr_s is None) | (fr_m is None)):
            return ()

        fr_e = numpy.array([_.fr for _ in item], dtype=float)
        fr_s = numpy.array([_.fr_sigma for _ in item], dtype=float)
        fr_m = numpy.array([_.fr_calc for _ in item], dtype=float)
        
        widget = pg.GraphicsLayoutWidget(title="Flip Ratio")

        err1 = pg.ErrorBarItem(x=fr_m, y=fr_e, top=fr_s, 
                                      bottom=fr_s, beam=0.5)
        p1 = widget.addPlot(x=fr_m, y=fr_e, name="fr", title="FR",
                        symbol='o', pen={'color': 0.8, 'width': 2})
        p1.plot(x=fr_e, y=fr_e, name="line", title="", 
                pen=pg_pen_black)
        p1.addItem(err1)
        
        dock_1 = pg_da.Dock("Reflections", widget=widget)
        return (dock_1, )
        
    elif isinstance(obj, RhoChi):
        docks = dock_rhochi(obj, thread)
        return docks
    return ()