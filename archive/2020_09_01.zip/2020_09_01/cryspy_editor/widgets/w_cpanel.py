import os
from typing import Union, List, Callable, Any, NoReturn
from PyQt5 import QtCore, QtGui, QtWidgets
from cryspy import GlobalConstr, DataConstr, LoopConstr, ItemConstr
from pycifstar import Global, Data, Loop, Item
import numpy
import json
from cryspy_editor.b_rcif_to_cryspy import L_GLOBAL_CLASS, L_DATA_CLASS, L_LOOP_CLASS, L_ITEM_CLASS

class CPanel(QtWidgets.QTreeWidget):
    def __init__(self, 
                 func_object_clicked: Callable[[Any], Any], 
                 func_add_output_object: Callable[[Any], Any], 
                 func_delete_output_object: Callable[[Any], Any], 
                 object_global: Union[GlobalConstr, Global]=None,
                 objects:List[Union[GlobalConstr, DataConstr, LoopConstr, ItemConstr, int, float, str, bool]]=(),
                 functions:List[Callable[[Any], Any]]=()) -> NoReturn:
        super(CPanel, self).__init__()

        self.setSizePolicy(QtWidgets.QSizePolicy(
                QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding))
        self.setColumnCount(1)
        self.setHeaderHidden(True)

        self.func_object_clicked = func_object_clicked
        self.func_add_output_object = func_add_output_object
        self.func_delete_output_object = func_delete_output_object

        self.set_object_global(object_global)
        self.set_output_objects(objects)

        wi = QtWidgets.QTreeWidgetItem()
        wi.setText(0, "Functions")
        wi._object = None
        if len(functions) != 0:
            for _func in functions:
                wii = QtWidgets.QTreeWidgetItem()
                wii.setText(0, _func.__name__)
                wii._object = _func
                wi.addChild(wii)
        self.addTopLevelItem(wi)

        self.itemClicked.connect(func_object_clicked)
        self.expandAll()
        self.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.customContextMenuRequested.connect(self.open_menu)

        self.setAcceptDrops(True)
        self.setDragEnabled(True)
        

    def dragEnterEvent(self, event):
        if event.mimeData().hasText():
            event.acceptProposedAction()

    def dropEvent(self, event):
        #FIXME It doesnot work, why
        print("HERE2")
        pos = event.pos()
        mime_data = event.mimeData()
        s_cont = mime_data.text()
        object = mime_data.object_to_send 
        w_given = self.itemAt(pos)
        print("s_cont:", s_cont)
        print("object:", object)
        print("w_given:", w_given)
        event.acceptProposedAction()


    def mouseMoveEvent(self, event):
        w_tree_item = self.itemAt(event.pos())
        if w_tree_item is None:
            return
        object_to_send = w_tree_item._object
        string_to_send = type(object_to_send).__name__

        drag = QtGui.QDrag(self)
        dragMimeData = QtCore.QMimeData()  
        dragMimeData.object_to_send = object_to_send

        dragMimeData.setText(string_to_send)
        drag.setMimeData(dragMimeData) 
        drag.exec_(QtCore.Qt.MoveAction)

    def set_object_global(self, object_global: Union[GlobalConstr, Global]=None)->NoReturn:
        if object_global is None:
            object_global = GlobalConstr()

        flag = True
        if isinstance(object_global, GlobalConstr):
            wi = make_tree_widget_item_for_global_constr(object_global)
        elif isinstance(object_global, Global):
            wi = make_tree_widget_item_for_global(object_global)
        else:
            flag = False

        if flag:
            if self.topLevelItemCount() == 3:
                ind = 0
                w_del = self.itemFromIndex(ind)
                self.removeItemWidget(w_del, ind)
                self.insertTopLevelItem(ind, wi)
            else:
                self.addTopLevelItem(wi)

    def set_output_objects(self, objects:List[Union[GlobalConstr, DataConstr, LoopConstr, ItemConstr, int, float, str, bool]]=()) -> NoReturn:

        self.w_objects = QtWidgets.QTreeWidgetItem()
        self.w_objects.setText(0, "Output objects")
        self.w_objects._object = None
        if len(objects) != 0:
            for _obj in objects:
                self.add_output_object(_obj)
        if self.topLevelItemCount() == 3:
            ind = 1
            w_del = self.itemFromIndex(ind)
            self.removeItemWidget(w_del, ind)
            self.insertTopLevelItem(ind, self.w_objects)
        else:
            self.addTopLevelItem(self.w_objects)

    def delete_output_object(self, ind: int) -> NoReturn:
        flag = True
        w_item = self.w_objects.takeChild(ind)
        self.w_objects.removeChild(w_item)

    def add_output_object(self, object:Union[GlobalConstr, DataConstr, LoopConstr, ItemConstr, int, float, str, bool, numpy.ndarray, list]=None) -> NoReturn:
        flag = True
        if isinstance(object, GlobalConstr):
            wii = make_tree_widget_item_for_global_constr(object)
        elif isinstance(object, DataConstr):
            wii = make_tree_widget_item_for_data_constr(object)
        elif isinstance(object, LoopConstr):
            wii = make_tree_widget_item_for_loop_constr(object)
        elif isinstance(object, ItemConstr):
            wii = make_tree_widget_item_for_item_constr(object)
        elif isinstance(object, Global):
            wii = make_tree_widget_item_for_global(object)
        elif isinstance(object, Data):
            wii = make_tree_widget_item_for_data(object)
        elif isinstance(object, Loop):
            wii = make_tree_widget_item_for_loop(object)
        elif isinstance(object, Item):
            wii = make_tree_widget_item_for_item(object)
        elif (isinstance(object, str) | isinstance(object, numpy.ndarray) | 
              isinstance(object, int) | isinstance(object, float) | isinstance(object, list)):
            wii = make_tree_widget_item_for_string(object)
        else:
            flag = False
        if flag:
            self.w_objects.addChild(wii)

    def replace_object_global(self, object:Union[GlobalConstr, Global]) -> NoReturn:

        flag = True
        if isinstance(object, GlobalConstr):
            wi = make_tree_widget_item_for_global_constr(object)
        elif isinstance(object, Global):
            wi = make_tree_widget_item_for_global(object)
        else: 
            flag = False

        if flag:
            ind = 0
            w_del = self.takeTopLevelItem(ind)
            self.removeItemWidget(w_del, ind)
            self.insertTopLevelItem(ind, wi)
            self.expandAll()


    def open_menu(self, position):
        func_add_output_object = self.func_add_output_object
        func_delete_output_object = self.func_delete_output_object
        w_item = self.itemAt(position)
        if w_item is not None:
            l_ind = find_tree_item_position(self, w_item)
            if ((l_ind[0] == 0) | (l_ind[0] == 1)):
                menu = QtWidgets.QMenu()
                if l_ind[0] == 0:
                    save_as_object = QtWidgets.QAction('Save as ...', menu)
                    save_as_object.triggered.connect(lambda x: self.save_as_object(w_item._object))
                    menu.addAction(save_as_object)
                if l_ind[0] == 1:
                    add_objects = QtWidgets.QAction('Add objects by python script', menu)
                    add_objects.triggered.connect(lambda x: self.show_modal_window(func_add_output_object))
                    menu.addAction(add_objects)
                    if len(l_ind) > 1:
                        save_as_object = QtWidgets.QAction('Save as ...', menu)
                        save_as_object.triggered.connect(lambda x: self.save_as_object(w_item._object))
                        menu.addAction(save_as_object)

                        ind = l_ind[1]
                        delete_object = QtWidgets.QAction('Delete Object', menu)
                        delete_object.triggered.connect(lambda x: func_delete_output_object(ind))
                        menu.addAction(delete_object)
                    else:
                        delete_objects = QtWidgets.QAction('Delete Objects', menu)
                        delete_objects.triggered.connect(lambda x: func_delete_output_object())
                        menu.addAction(delete_objects)

                if ((len(l_ind) > 1) & (isinstance(w_item._object, (DataConstr, LoopConstr, ItemConstr)))):
                    delete_object = QtWidgets.QAction('Delete object', menu)
                    delete_object.triggered.connect(lambda x: self.delete_object(w_item))
                    menu.addAction(delete_object)

                if (isinstance(w_item._object, (GlobalConstr, DataConstr))):
                    if type(w_item._object) in [GlobalConstr, DataConstr]:
                        add_item_menu = QtWidgets.QMenu("add item")
                        for _item_cls in L_ITEM_CLASS:
                            add_item_object = QtWidgets.QAction(f'{_item_cls.__name__:}', add_item_menu)
                            add_item_object.attached_class = _item_cls
                            add_item_object.triggered.connect(lambda x: self.signal_to_add_object(w_item))
                            add_item_menu.addAction(add_item_object)
                        menu.addMenu(add_item_menu)

                        add_loop_menu = QtWidgets.QMenu("add loop")
                        for _loop_cls in L_LOOP_CLASS:
                            add_loop_object = QtWidgets.QAction(f'{_loop_cls.__name__:}', add_loop_menu)
                            add_loop_object.attached_class = _loop_cls
                            add_loop_object.triggered.connect(lambda x: self.signal_to_add_object(w_item))
                            add_loop_menu.addAction(add_loop_object)
                        menu.addMenu(add_loop_menu)

                        if type(w_item._object) is GlobalConstr:
                            add_data_menu = QtWidgets.QMenu("add data")
                            for _data_cls in L_DATA_CLASS:
                                add_data_object = QtWidgets.QAction(f'{_data_cls.__name__:}', add_data_menu)
                                add_data_object.attached_class = _data_cls
                                add_data_object.triggered.connect(lambda x: self.signal_to_add_object(w_item))
                                add_data_menu.addAction(add_data_object)
                            menu.addMenu(add_data_menu)
                    else:
                        obj = w_item._object
                        add_object_menu = QtWidgets.QMenu("add object")
                        for _i, _cls in enumerate(obj.mandatory_classes+obj.optional_classes):
                            if _i == len(obj.mandatory_classes):
                                add_object_menu.addSeparator()
                            add_object = QtWidgets.QAction(f'{_cls.__name__:}', add_object_menu)
                            add_object.attached_class = _cls
                            add_object.triggered.connect(lambda x: self.signal_to_add_object(w_item))
                            add_object_menu.addAction(add_object)
                        menu.addMenu(add_object_menu)

                menu.exec_(self.viewport().mapToGlobal(position))

    def signal_to_add_object(self, widget: QtWidgets.QTreeWidgetItem) -> NoReturn:
        sender = self.sender()
        attached_class = sender.attached_class
        obj = widget._object
        obj_new = attached_class()
        if type(obj) in [GlobalConstr, DataConstr]:
            obj.optional_objs.append(obj_new)
        elif type(obj_new) in obj.mandatory_classes:
            obj.mandatory_objs.append(obj_new)
        elif type(obj_new) in obj.optional_classes:
            obj.optional_objs.append(obj_new)

        if isinstance(obj_new, DataConstr):
            wi = make_tree_widget_item_for_data_constr(obj_new)
            widget.addChild(wi)
        elif isinstance(obj_new, LoopConstr):
            wi = make_tree_widget_item_for_loop_constr(obj_new)
            widget.addChild(wi)
        elif isinstance(obj_new, ItemConstr):
            wi = make_tree_widget_item_for_item_constr(obj_new)
            widget.addChild(wi)


    def delete_object(self, widget: QtWidgets.QTreeWidgetItem) -> NoReturn:
        widget_parent = widget.parent()
        obj = widget._object
        obj_parent = widget_parent._object

        flag = False

        if isinstance(obj_parent, (GlobalConstr, DataConstr)):
            if obj in obj_parent.mandatory_objs:
                obj_parent.mandatory_objs.remove(obj)
                flag = True
            if obj in obj_parent.optional_objs:
                obj_parent.optional_objs.remove(obj)
                flag = True
            if obj in obj_parent.internal_objs:
                obj_parent.internal_objs.remove(obj)
                flag = True

        if flag:
            widget_parent.removeChild(widget)

    def show_modal_window(self, func: Callable):
        modal_window = WPythonScript(self, QtCore.Qt.Window)
        modal_window.init_widgets(func)
        modal_window.show()


    def save_as_object(self, object: Union[Global, GlobalConstr, Data, DataConstr, Loop, LoopConstr, Item, ItemConstr,
                                           numpy.ndarray, str, float, int])-> NoReturn:
        f_name, okPressed = QtWidgets.QFileDialog.getSaveFileName(self, 'Select a file:', "",
                                                                  "All files (*.*)")
        if not (okPressed):
            return None
        flag_write = True
        if isinstance(object, (GlobalConstr, DataConstr, LoopConstr, ItemConstr)):
            s_out = object.to_cif()
        elif isinstance(object, numpy.ndarray):
            s_out = str(object)
        else:
            s_out = str(object)
        if flag_write:
            with open(f_name, "w") as fid:
                fid.write(s_out) 


class WPythonScript(QtWidgets.QWidget):
    def __init__(self, *arg):
        super(WPythonScript, self).__init__(*arg)
        self.setWindowTitle("Define objects by python script")
        self.setWindowModality(QtCore.Qt.WindowModal)
        self.setAttribute(QtCore.Qt.WA_DeleteOnClose, True)

    def init_widgets(self, func:Callable):
        s_text = """import numpy
l_new_objects = []
#h, k = numpy.meshgrid(range(2), range(2))
#l_new_objects.append(h.flatten())
#l_new_objects.append(k.flatten())
        """
        layout = QtWidgets.QGridLayout()
        self.w_address = QtWidgets.QLabel(f".")
        self.w_address.setSizePolicy(QtWidgets.QSizePolicy(
                QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed))
        w_pb_load = QtWidgets.QPushButton("Load from file")
        w_pb_load.setSizePolicy(QtWidgets.QSizePolicy(
                      QtWidgets.QSizePolicy.Fixed, QtWidgets.QSizePolicy.Fixed))
        w_pb_load.clicked.connect(self.load_script)

        w_pb_save = QtWidgets.QPushButton("Save script")
        w_pb_save.setSizePolicy(QtWidgets.QSizePolicy(
                    QtWidgets.QSizePolicy.Fixed, QtWidgets.QSizePolicy.Fixed))
        w_pb_save.clicked.connect(self.save_script)
        w_pb_ok = QtWidgets.QPushButton("Calculate")
        w_pb_ok.setSizePolicy(QtWidgets.QSizePolicy(
                    QtWidgets.QSizePolicy.Fixed, QtWidgets.QSizePolicy.Fixed))
        w_pb_ok.clicked.connect(lambda x: self.eval_outputs(func))
        self.w_pte_script = QtWidgets.QPlainTextEdit(s_text)
        self.w_pte_script.setSizePolicy(QtWidgets.QSizePolicy(
                    QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding))
        layout.addWidget(self.w_address, 0, 0)
        layout.addWidget(w_pb_load, 0, 1)
        layout.addWidget(self.w_pte_script, 1, 0, 1, 2)
        layout.addWidget(w_pb_ok, 2, 1)
        layout.addWidget(w_pb_save, 3, 1)
        self.setLayout(layout)

    def load_script(self):
        s_dir_data = self.w_address.text()
        f_file_data_new, okPressed = QtWidgets.QFileDialog.getOpenFileName(self, 'Select a py file:',
                                                                           s_dir_data, "Python script (*.py)")
        if not (okPressed):
            return None
        self.w_address.setText(os.path.dirname(f_file_data_new))
        with open(f_file_data_new, "r") as fid:
            s_cont = fid.read()
        self.w_pte_script.setPlainText(s_cont)

    def save_script(self):
        s_dir_data = self.w_address.text()
        f_name, okPressed = QtWidgets.QFileDialog.getSaveFileName(self, 'Select a file:', s_dir_data,
                                                                  "Python script (*.py)")
        if not (okPressed):
            return None

        self.w_address.setText(os.path.dirname(f_name))
        s_cont = self.w_pte_script.toPlainText()

        with open(f_name, "w") as fid:
            fid.write(s_cont)
  
    def eval_outputs(self, func):
        s_cond = self.w_pte_script.toPlainText()
        global_env, local_env = {}, {}
        try:
            code_object = compile(s_cond, '<string>', 'exec')
            exec(code_object, global_env, local_env)
            l_output = local_env['l_new_objects']
        except SyntaxError:
            l_output = []
            QtWidgets.QMessageBox.warning(self, "Mistake", 'There is a problem with the syntax of the executed script')
        except ArithmeticError:
            l_output = []
            QtWidgets.QMessageBox.warning(self, "Mistake", 'There is an arithmetic error in the scrip')
        except Exception:
            l_output = []
            QtWidgets.QMessageBox.warning(self, "Mistake", 'An unspecified error occurred while script executing')
        for _output in l_output:
            func(_output)

def find_tree_item_position(w_main: QtWidgets.QTreeWidgetItem, 
                        child_item: QtWidgets.QTreeWidget) -> int:
    ind = w_main.indexOfTopLevelItem(child_item)
    if ind != -1:
        res = [ind]
    else:
        w_parent = child_item.parent()
        ind_child = w_parent.indexOfChild(child_item)
        res = find_tree_item_position(w_main, w_parent)
        res.append(ind_child)
    return res

def make_tree_widget_item_for_item(_obj: Union[Item, ItemConstr], label_obj:str="") -> QtWidgets.QTreeWidgetItem:
    wi = QtWidgets.QTreeWidgetItem()
    if label_obj == "":
        if isinstance(_obj, Item):
            _item_text = _obj.name
        elif isinstance(_obj, ItemConstr):
            _item_text = _obj.PREFIX
        else:
            _item_text = ""
    else:
        _item_text = label_obj

    wi.setText(0, f"{_item_text:}")
    wi._object = _obj
    #wi.setToolTip(0, _obj.__doc__)
    return wi 


def make_tree_widget_item_for_loop(_obj: Union[Loop, LoopConstr], label_obj:str="") -> QtWidgets.QTreeWidgetItem:
    wi = QtWidgets.QTreeWidgetItem()
    if label_obj == "":
        if isinstance(_obj, Loop):
            if _obj.name != "":
                _item_text = f"loop{_obj.prefix:}_{_obj.name:}"
            else:
                _item_text = f"loop{_obj.prefix:}"
        elif isinstance(_obj, LoopConstr):
            if _obj.loop_name != "":
                _item_text = f"loop_{_obj.prefix:}_{_obj.loop_name:}"
            else:
                _item_text = f"loop_{_obj.prefix:}"
    else:
        _item_text = label_obj

    wi.setText(0, f"{_item_text:}")

    wi._object = _obj
    #wi.setToolTip(0, _obj.__doc__)
    return wi 


def make_tree_widget_item_for_data(_obj: Data, label_obj:str="") -> QtWidgets.QTreeWidgetItem:
    if label_obj == "":
        _item_text = type(_obj).__name__ + f"_{_obj.name:}"
    else:
        _item_text = label_obj
    wi = QtWidgets.QTreeWidgetItem()
    wi.setText(0, f"{_item_text:}")
    #wi.setToolTip(0, _obj.__doc__)
    wi._object = _obj
    for _loop in _obj.loops:
        wii = make_tree_widget_item_for_loop(_loop)
        wi.addChild(wii)
    for _item in _obj.items:
        wii = make_tree_widget_item_for_item(_item)
        wi.addChild(wii)
    return wi 


def make_tree_widget_item_for_global(_obj: Global, label_obj:str="") -> QtWidgets.QTreeWidgetItem:
    if label_obj == "":
        _item_text = type(_obj).__name__ + f"_{_obj.name:}"
    else:
        _item_text = label_obj
    wi = QtWidgets.QTreeWidgetItem()
    wi.setText(0, f"{_item_text:}")
    #wi.setToolTip(0, _obj.__doc__)
    wi._object = _obj
    for _loop in _obj.loops:
        wii = make_tree_widget_item_for_loop(_loop)
        wi.addChild(wii)
    for _item in _obj.items:
        wii = make_tree_widget_item_for_item(_item)
        wi.addChild(wii)
    for _data in _obj.datas:
        wii = make_tree_widget_item_for_data(_data)
        wi.addChild(wii)
    return wi 


def make_tree_widget_item_for_item_constr(_obj: ItemConstr, label_obj:str="") -> QtWidgets.QTreeWidgetItem:
    wi = make_tree_widget_item_for_item(_obj, label_obj)
    l_int_attr = _obj.INTERNAL_ATTRIBUTE
    if l_int_attr is None:
        l_int_attr = []
    for _int_attr in l_int_attr:
        _int_obj = getattr(_obj, _int_attr)
        if isinstance(_int_obj, ItemConstr):
            wii = make_tree_widget_item_for_item_constr(_int_obj, _int_attr)
            wi.addChild(wii)
        elif isinstance(_int_obj, LoopConstr):
            wii = make_tree_widget_item_for_loop_constr(_int_obj, _int_attr)
            wi.addChild(wii)
    return wi 


def make_tree_widget_item_for_loop_constr(_obj: LoopConstr, label_obj:str="") -> QtWidgets.QTreeWidgetItem:
    wi = make_tree_widget_item_for_loop(_obj, label_obj)
    l_int_attr = _obj.INTERNAL_ATTRIBUTE
    if l_int_attr is None:
        l_int_attr = []
    for _int_attr in l_int_attr:
        _int_obj = getattr(_obj, _int_attr)
        if isinstance(_int_obj, ItemConstr):
            wii = make_tree_widget_item_for_item_constr(_int_obj, _int_attr)
            wi.addChild(wii)
        elif isinstance(_int_obj, LoopConstr):
            wii = make_tree_widget_item_for_loop_constr(_int_obj, _int_attr)
            wi.addChild(wii)
    return wi 


def make_tree_widget_item_for_data_constr(_obj: DataConstr, label_obj:str="") -> QtWidgets.QTreeWidgetItem:
    if label_obj == "":
        _item_text = type(_obj).__name__ + f"_{_obj.data_name:}"
    else:
        _item_text = label_obj
    wi = QtWidgets.QTreeWidgetItem()
    wi.setText(0, f"{_item_text:}")
    wi._object = _obj
    #wi.setToolTip(0, _obj.__doc__)
    l_obj = _obj.mandatory_objs + \
            _obj.optional_objs+_obj.internal_objs
    for _obj in l_obj:
        if isinstance(_obj, LoopConstr):
            wii = make_tree_widget_item_for_loop_constr(_obj)
            wi.addChild(wii)
        elif isinstance(_obj, ItemConstr):
            wii = make_tree_widget_item_for_item_constr(_obj)
            wi.addChild(wii)
    return wi 


def make_tree_widget_item_for_global_constr(_obj: GlobalConstr, label_obj:str="") -> QtWidgets.QTreeWidgetItem:
    if label_obj == "":
        _item_text = type(_obj).__name__ + f"_{_obj.global_name:}"
    else:
        _item_text = label_obj
    wi = QtWidgets.QTreeWidgetItem()
    wi.setText(0, f"{_item_text:}")
    wi._object = _obj
    #wi.setToolTip(0, _obj.__doc__)
    l_obj = _obj.mandatory_objs + _obj.optional_objs
    for _obj in l_obj:
        if isinstance(_obj, DataConstr):
            wii = make_tree_widget_item_for_data_constr(_obj)
            wi.addChild(wii)
        elif isinstance(_obj, LoopConstr):
            wii = make_tree_widget_item_for_loop_constr(_obj)
            wi.addChild(wii)
        elif isinstance(_obj, ItemConstr):
            wii = make_tree_widget_item_for_item_constr(_obj)
            wi.addChild(wii)
    return wi 


def make_tree_widget_item_for_string(object: Union[str, float, int, list, numpy.ndarray], label_obj:str="") -> QtWidgets.QTreeWidgetItem:
    wi = QtWidgets.QTreeWidgetItem()
    if label_obj == "":
        if isinstance(object, str):
            s_name = object.strip().split("\n")[0]
        else:
            s_name = object.__repr__().strip().split("\n")[0]
        if len(s_name) > 30: s_name = s_name[:30]
        s_type = type(object).__name__
        _item_text = f"{s_type:}_{s_name:}"
    else:
        _item_text = label_obj

    wi.setText(0, f"{_item_text:}")
    wi._object = object
    return wi 
