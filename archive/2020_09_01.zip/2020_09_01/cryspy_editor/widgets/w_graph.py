from PyQt5 import QtCore, QtGui, QtWidgets
from .w_function import WFunction
from .interactive_graph_3d import WGraph2D
    

class CGraph(QtWidgets.QMainWindow):
    def __init__(self, parent=None):
        super(CGraph, self).__init__(parent)

        lay = QtWidgets.QVBoxLayout(self)
        

        lay_h = QtWidgets.QHBoxLayout()
        self.graph_2d = WGraph2D(self)
        self.graph_toolbar = self.graph_2d.get_toolbar(self)

        lay.addWidget(self.graph_toolbar)
        self.w_function = WFunction()
        lay.addWidget(self.w_function)

        lay_h.addWidget(self.graph_2d)


        l_func = [self.plot, self.scatters, self.errorbar, self.clean]


        list_function = QtWidgets.QListWidget()
        qfont = QtGui.QFont()
        qfont.setBold(True)
        for func in l_func:
            l_param = [_ for _ in func.__code__.co_varnames[:func.__code__.co_argcount] if _ != "self"]
            s_par = ""
            if len(l_param) > 0:
                s_par = ", ".join(l_param)
            s_val = f"{func.__name__:}({s_par:})"

            list_function_item = QtWidgets.QListWidgetItem(s_val)
            list_function_item.setFont(qfont)
            list_function.addItem(list_function_item)
            list_function_item.attached_object = func
        list_function.setSizePolicy(QtWidgets.QSizePolicy.Fixed, QtWidgets.QSizePolicy.Expanding)
        list_function.setSortingEnabled(True)
        lay_h.addWidget(list_function)
        lay.addLayout(lay_h)

        list_function.clicked.connect(lambda : self.w_function.set_function(list_function.currentItem().attached_object, None))


        self.setWindowTitle("Graph")
        widg = QtWidgets.QWidget()
        widg.setLayout(lay)
        self.setCentralWidget(widg)


    def plot(self, x, y):
        self.graph_2d.plot_plot(x, y)
    def scatters(self, x, y):
        self.graph_2d.plot_scatters(x, y)
    def errorbar(self, x, y, yerr):
        self.graph_2d.plot_errorbar(x, y, yerr)
    def clean(self):
        for artist in self.graph_2d.figure.gca().lines + self.graph_2d.figure.gca().collections:
            artist.remove()
        self.graph_2d.draw()