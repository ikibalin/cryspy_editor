__author__ = 'ikibalin'
__version__ = "2019_09_10"

import os
import sys

import numpy

from PyQt5 import QtWidgets
from PyQt5 import QtGui
from PyQt5 import QtCore
 
import matplotlib
import matplotlib.backends.backend_qt5agg
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg, NavigationToolbar2QT

import matplotlib.figure 
import matplotlib.pyplot
 

class cwind_central(QtWidgets.QMainWindow):
    def __init__(self):
        super(cwind_central, self).__init__()
        self.title = "program 'Graph'"
        self.setWindowTitle(self.title)
        widget = WGraph3D(self, width=5, height=4)
        x, y, z = [1,0,2], [1,1,0], [1,2,0]
        widget.plot_scatters(x, y, z)
        x, y, z = [0,0,0], [2,2,0], [1,2,2]
        widget.plot_scatters(x, y, z, c="k")
        self.setCentralWidget(widget)
        self.show()
        


class WGraph3D(matplotlib.backends.backend_qt5agg.FigureCanvasQTAgg):
 
    def __init__(self, parent=None, width=5, height=4, dpi=100):

        self.figure = matplotlib.figure.Figure(figsize=(width, height), dpi = dpi)
        self.figure.subplots_adjust(left = 0.07, right = 0.97,
                                    top = 0.97, bottom = 0.07,
                                    wspace = 0.0, hspace = 0.0)
        super(WGraph3D, self).__init__(self.figure)
        
        self.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)
        self.ax_pri = self.figure.add_subplot(111, projection="3d")
  
        self.ax_pri.set_facecolor("w")    
        self.ax_pri.set_axis_off()    
        self.ax_pri.set_xticks([])    
        self.ax_pri.set_yticks([])    
        self.ax_pri.set_zticks([])   

    def plot_scatters(self, x, y, z, c="r", s=2000, depthshade=True):
        self.ax_pri.scatter(x, y, z, c=c, marker="o", s=s, depthshade=depthshade)
        self.draw()

    def plot_text(self, x, y, z, s, **kwards):
        self.ax_pri.text(x, y, z, s, **kwards)
        self.draw()

    def plot_plot(self, xs, ys, *args, **kwards):
        self.ax_pri.plot(xs, ys, *args, **kwards)
        self.draw()
        
    def plot_quiver(self, X, Y, Z, U, V, W, **kwards):
        self.ax_pri.quiver(X, Y, Z, U, V, W, **kwards)
        self.draw()
        


class WGraph2D(matplotlib.backends.backend_qt5agg.FigureCanvasQTAgg):
 
    def __init__(self, parent=None, width:float=5, height:float=4, dpi:int=100, n_plots:int=1):

        self.figure = matplotlib.figure.Figure(figsize=(width, height), dpi = dpi)
        self.figure.subplots_adjust(left = 0.07, right = 0.97,
                                    top = 0.97, bottom = 0.07,
                                    wspace = 0.0, hspace = 0.0)
        super(WGraph2D, self).__init__(self.figure)
        self.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)
        self.n_plots = n_plots

        if self.n_plots == 2:
            (self.ax_pri, self.ax_pri_2) = self.figure.subplots(2, 1, sharex='all')
            #self.grid = matplotlib.figure.GridSpec(4, 4)
            #self.ax_pri = self.figure.add_subplot(self.grid[:-1, :], xticklabels=[]) 
            #self.ax_pri_2 = self.figure.add_subplot(self.grid[-1, :], xticklabels=[])
        else:
            self.ax_pri = self.figure.add_subplot(111)
            self.ax_pri_2 = None

        #self.figure.canvas.mpl_connect("button_press_event", self.on_click_press)
        #self.figure.canvas.mpl_connect("button_release_event", self.on_click_release)
        self.xydata = None
        self.xy = None
        self.flag_toolbar = False

    def get_toolbar(self, parent=None):
        toolbar = NavigationToolbar2QT(self, parent)
        toolbar.update()
        self.flag_toolbar = True
        return toolbar

    def plot_scatters(self, x, y, c="r", s=200, n_plot:int=1):
        if n_plot == 1:
            self.ax_pri.scatter(x, y, c=c, marker="o", s=s)
        else:
            self.ax_pri_2.scatter(x, y, c=c, marker="o", s=s)
        self.draw()

    def plot_text(self, x, y, *args, n_plot:int=1, **kwards):
        if n_plot == 1:
            self.ax_pri.text(x, y, *args, **kwards)
        else:
            self.ax_pri_2.text(x, y, *args, **kwards)
        self.draw()

    def plot_plot(self, xs, ys, *args, n_plot:int=1, **kwards):
        if n_plot == 1:
            self.ax_pri.plot(xs, ys, *args, **kwards)
        else:
            self.ax_pri_2.plot(xs, ys, *args, **kwards)
        self.draw()
        
    def plot_quiver(self, X, Y, Z, U, V, W, n_plot:int=1, **kwards):
        if n_plot == 1:
            self.ax_pri.quiver(X, Y, Z, U, V, W, **kwards)
        else:
            self.ax_pri_2.quiver(X, Y, Z, U, V, W, **kwards)

        self.draw()

    def plot_errorbar(self, x, y, *arg, n_plot:int=1, **kwards):
        if n_plot == 1:
            self.ax_pri.errorbar(x, y, *arg, **kwards)
        else:
            self.ax_pri_2.errorbar(x, y, *arg, **kwards)
        self.draw()


    #def on_click_press(self, event):
    #    ax = event.inaxes
    #    if ax is None:
    #        return
    #    if event.button != 1:
    #        return          
    #    self.xydata = (event.xdata, event.ydata)        
    #    self.xy = (event.x, event.y)        
    #def on_click_release(self, event):
    #    ax = event.inaxes
    #    if ax is None:
    #        self.xydata = None
    #        self.xy = None
    #        return
    #    if event.button != 1:
    #        self.xydata = None
    #        self.xy = None
    #        return            
    #    if self.xydata is None:
    #        return
    #    xydata_1 = self.xydata        
    #    xydata_2 = (event.xdata, event.ydata)
    #    x_diff = abs(event.x-self.xy[0])
    #    y_diff = abs(event.y-self.xy[1])
    #    self.xydata = None        
    #    self.xy = None        
    #    xlim = (min([xydata_1[0], xydata_2[0]]), max([xydata_1[0], xydata_2[0]])) 
    #    ylim = (min([xydata_1[1], xydata_2[1]]), max([xydata_1[1], xydata_2[1]]))
    #    if self.flag_toolbar:
    #        if ((x_diff <= 3) & (y_diff <= 3)): 
    #            if self.ax_pri is not None: self.ax_pri.autoscale(enable=True, axis="x", tight=False) 
    #            if self.ax_pri_2 is not None: self.ax_pri_2.autoscale(enable=True, axis="x", tight=False) 
    #            if self.ax_pri is not None: self.ax_pri.autoscale(enable=True, axis="y", tight=False) 
    #            if self.ax_pri_2 is not None: self.ax_pri_2.autoscale(enable=True, axis="y", tight=False) 
    #        
    #    if x_diff > 3: 
    #        if self.ax_pri is not None: self.ax_pri.set_xlim(xlim)
    #        if self.ax_pri_2 is not None: self.ax_pri_2.set_xlim(xlim)
    #    else:
    #        if self.ax_pri is not None: self.ax_pri.autoscale(enable=True, axis="x", tight=False) 
    #        if self.ax_pri_2 is not None: self.ax_pri_2.autoscale(enable=True, axis="x", tight=False) 
    #    if y_diff > 3: 
    #       if self.ax_pri is not None: self.ax_pri.set_ylim(ylim)
    #    else:
    #        if self.ax_pri is not None: self.ax_pri.autoscale(enable=True, axis="y", tight=False) 
    #        if self.ax_pri_2 is not None: self.ax_pri_2.autoscale(enable=True, axis="y", tight=False) 
    #    event.canvas.draw()


if __name__ == '__main__':
    app = QtWidgets.QApplication(sys.argv)
    ex = cwind_central()
    
    sys.exit(app.exec_())
    
    
    
