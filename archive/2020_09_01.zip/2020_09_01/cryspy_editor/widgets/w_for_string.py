from .FUNCTIONS import make_qtablewidget_for_item_constr, show_info, get_layout_method_help, \
    get_layout_internal_attribute, get_layout_rciftab_obj

from PyQt5 import QtWidgets, QtGui, QtCore
from typing import NoReturn, Union

import numpy
from cryspy_editor.widgets.w_function import WFunction
from .w_dragtable import CDragTable

def w_for_string(obj: Union[str, numpy.ndarray, int, float, list], layout_11: QtWidgets.QBoxLayout, layout_12: QtWidgets.QBoxLayout, 
                 layout_13: QtWidgets.QBoxLayout, layout_2: QtWidgets.QBoxLayout, 
                 layout_3: QtWidgets.QBoxLayout, w_output: QtWidgets.QWidget, thread) -> NoReturn:

    if isinstance(obj, numpy.ndarray):
        widget = CDragTable()
        widget.set_numpy_ndarray(obj)
        layout_11.addWidget(widget)
    else:
        if isinstance(obj, str):
            s_label = obj.strip()
        else:
            s_label = obj.__repr__()

        widget = QtWidgets.QLabel(f"{s_label:}")
        widget.setStyleSheet("background-color:white;")
        widget.setSizePolicy(QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding,
                                                   QtWidgets.QSizePolicy.Expanding))
        widget.setFont(QtGui.QFont("Courier", 10, QtGui.QFont.Normal))
        widget.setTextInteractionFlags(QtCore.Qt.TextSelectableByMouse)
        widget.setAlignment(QtCore.Qt.AlignTop)
        widget.setWordWrap(True)

        area = QtWidgets.QScrollArea()
        area.setWidgetResizable(True)
        area.setWidget(widget)

        layout_11.addWidget(area)
