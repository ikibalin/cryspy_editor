import os
from typing import Union, List, Callable, Any, NoReturn
from PyQt5 import QtCore, QtGui, QtWidgets
from cryspy import GlobalConstr, DataConstr, LoopConstr, ItemConstr, Fitable
from pycifstar import Global, Data, Loop, Item
import numpy
import json
from cryspy_editor.b_rcif_to_cryspy import L_GLOBAL_CLASS, L_DATA_CLASS, L_LOOP_CLASS, L_ITEM_CLASS

class CDragTable(QtWidgets.QTableWidget):
    def __init__(self) -> NoReturn:
        super(CDragTable, self).__init__()

        self.setSizePolicy(QtWidgets.QSizePolicy(
                QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding))
        self.attached_object = None
        self.attributes = []
        self.setDragEnabled(True)

    def mouseMoveEvent(self, event):
        w_item = self.itemAt(event.pos())
        if w_item is None:
            return
        i_attribute = self.column(w_item)
        s_attribute = self.attributes[i_attribute]
        if isinstance(self.attached_object, numpy.ndarray):
            if isinstance(s_attribute, str):
                obj_to_send = self.attached_object[s_attribute]
            else:
                if (len(self.attached_object.shape) == 1):
                    obj_to_send = self.attached_object[:]
                else:
                    obj_to_send = self.attached_object[:, s_attribute]
        else:
            obj_to_send = [getattr(_item, s_attribute) for _item in self.attached_object]
            _item = self.attached_object[0]
            flag = True
            if isinstance(getattr(_item, s_attribute), int):
                dtype_ = int
            elif isinstance(getattr(_item, s_attribute), (float, Fitable)):
                dtype_ = float
            elif isinstance(getattr(_item, s_attribute), (float, complex)):
                dtype_ = complex
            elif isinstance(getattr(_item, s_attribute), str):
                dtype_ = str
            else:
                flag = False
            if flag:
                obj_to_send = numpy.array(obj_to_send, dtype = dtype_)

        drag = QtGui.QDrag(self)
        dragMimeData = QtCore.QMimeData()  
        dragMimeData.object_to_send = obj_to_send
        dragMimeData.setText(f"'{s_attribute:}'")
        drag.setMimeData(dragMimeData) 
        drag.exec_(QtCore.Qt.MoveAction)


    def set_loop_constr(self, loop_constr_object: LoopConstr)->NoReturn:
        mandatory_attributes = loop_constr_object.ITEM_CLASS.MANDATORY_ATTRIBUTE 
        optional_attributes = loop_constr_object.ITEM_CLASS.OPTIONAL_ATTRIBUTE 
        l_attr =  mandatory_attributes + optional_attributes 
        l_flag_mandatory = len(mandatory_attributes)*[True]+len(optional_attributes)*[False]
        l_item = loop_constr_object.item
        if len(l_item)==0:
            n_row, n_col = 0, len(l_attr)
            self.setRowCount(n_row)
            self.setColumnCount(n_col)
            for _i_attr, _attr in enumerate(l_attr):
                _item_header = QtWidgets.QTableWidgetItem(_attr)
                if l_flag_mandatory[_i_attr]:
                    _item_header.setBackground(QtGui.QColor(255, 255, 240))#Ivory
                else:
                    _item_header.setBackground(QtGui.QColor(255, 255, 255))#White
                self.setHorizontalHeaderItem(_i_attr, _item_header)
            return 

        l_ii, l_attr_sh = [], []
        l_flag_m_sh = []
        for _i, _attr in enumerate(l_attr):
            flag = any([getattr(_item, _attr) is not None for _item in l_item])
            if flag:
                l_ii.append(_i) 
                l_attr_sh.append(_attr)
                l_flag_m_sh.append(l_flag_mandatory[_i])

        if len(l_attr_sh) == 0:
            l_attr_sh = l_attr
            l_ii = [_i for _i in range(len(l_attr))]

        n_row, n_col = len(l_item), len(l_attr_sh)
        self.setRowCount(n_row)
        self.setColumnCount(n_col)

        for _i_attr, _attr in enumerate(l_attr_sh):
            _item_header = QtWidgets.QTableWidgetItem(_attr)
            if l_flag_m_sh[_i_attr]:
                _item_header.setBackground(QtGui.QColor(255, 255, 240))#Ivory
            else:
                _item_header.setBackground(QtGui.QColor(255, 255, 255))#White
            self.setHorizontalHeaderItem(_i_attr, _item_header)

        for _i_row, _item in enumerate(l_item):
            for _i, _attr in enumerate(l_attr_sh):
                _1 = getattr(_item, _attr)
                _w_ti_0 = QtWidgets.QTableWidgetItem()
                #_w_ti_0.setToolTip(get_help_for_attribute(_item, _attr))
                if isinstance(_1, float):
                    _w_ti_0.setText(str(round(_1, 5)))
                elif isinstance(_1, Fitable):
                    if _1.refinement:
                        _w_ti_0.setText(str(_1))
                    else:
                        _w_ti_0.setText(str(round(float(_1), 5)))
                else:
                    _w_ti_0.setText(str(_1))
                self.setItem(_i_row, _i, _w_ti_0)
        self.attached_object = l_item
        self.attributes = l_attr_sh
        self.cellChanged.connect(self.change_cell)

    def set_numpy_ndarray(self, obj: numpy.ndarray)->NoReturn:
        self.attached_object = obj
        shape_len = len(obj.shape)
        if not(shape_len in [1, 2]):
            return
        elif shape_len == 2: 
            n_row, n_col = obj.shape
            names = list(range(n_col))
        elif shape_len == 1:
            n_row = obj.shape[0]
            dtype = obj.dtype
            if dtype.names is None:
                n_col = 1
                names = list(range(n_col))
            else:
                names = dtype.names
                n_col = len(names)
        self.setRowCount(n_row)
        self.setColumnCount(n_col)
        for _i, _name in enumerate(names):
            if isinstance(_name, int):
                s_name = str(_name+1)
            else:
                s_name = str(_name)
            self.setHorizontalHeaderItem(_i, QtWidgets.QTableWidgetItem(s_name))
        for i_1 in range(n_row):
            _val1 = obj[i_1]
            for i_2, name_2 in enumerate(names):
                if ((shape_len == 1) & isinstance(name_2, int)):
                    _val12 = _val1
                else:
                    _val12 = _val1[name_2]
                if isinstance(_val12, (float)):
                    s_val12 = round(_val12, 5)
                else:
                    s_val12 = str(_val12)
                w_i = QtWidgets.QTableWidgetItem()
                w_i.setText(str(s_val12))
                self.setItem(i_1, i_2, w_i)
        self.attributes = names


    def change_cell(self, i_row:int, i_column:int) -> NoReturn:
        table_item = self.item(i_row, i_column)
        val = str(table_item.text())
        attr = self.attributes[i_column]
        item = self.attached_object[i_row]
        setattr(item, attr, val)



    def open_menu(self, position):
        w_item = self.itemAt(position)
        if w_item is not None:
            menu = QtWidgets.QMenu()
            test_action = QtWidgets.QAction('Test action', menu)
            menu.addAction(test_action)
            menu.exec_(self.viewport().mapToGlobal(position))
