"""
CrysPyEditor
======

"""
name = "cryspy_editor"
__version__ = "1.5.7"
from cryspy_editor.main_window import main_w


if __name__ == "__main__":
    main_w()
